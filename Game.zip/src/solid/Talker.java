package solid;

import java.awt.Color;
import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
/*
 * Talkers face you when you approach
 */
public class Talker extends CircularSolid{
	private BufferedImage img = null;
	private final Color color;
	private double direction;
	private Solid target;
	public static final int DETECTION_RADIUS_2 = 25;
	public Talker(Color color, double direction, Solid target) {
		super(0, 0, 0.99);
		this.color = color;
		this.target = target;
		this.direction = direction;
	}
	public BufferedImage getImage() {
		if (img == null) {
			img = ImageGenerator.getPerson(color);
		}
		return img;
	}
	@Override
	public void setDirection(double direction) {
		this.direction = direction;
	}
	@Override
	public double getDirection() {
		if (target != null) {
			double dx = target.getX() - getX();
			double dy = target.getY() - getY();
			if ((dx * dx) + (dy * dy) <= DETECTION_RADIUS_2) {
				face(target);
			}
		}
		return direction;
	}
}
