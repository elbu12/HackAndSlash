package solid;

import java.awt.image.BufferedImage;

import graphics.ImageGenerator;

public class Spider extends SolidActor{
	private static BufferedImage img;
	public Spider(Solid target, double direction) {
		super(0.9, 100);
		setBehavior(STAND, ATTACK_IMMEDIATELY);
		setMovementSpeed(0.1);
		setTarget(target);
		setDirection(direction);
	}
	public BufferedImage getImage() {
		if (img == null) {
			img = ImageGenerator.getImageFromFile("img/spider.png");
		}
		return img;
	}
	public int getAttackDamage() {
		return 100;
	}
	public double getAttackRange() {
		return 0.02;
	}
	@Override
	public void beginAttack() {
		attack(getTarget());
	}
}
