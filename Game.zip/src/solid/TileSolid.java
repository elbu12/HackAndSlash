package solid;

import tile.Tile;

/**
 * TileSolid is returned when getFirstSolidHit hits an obstructing tile.
 * 
 * The attacking solid's world should call the set and get methods here.
 */
public class TileSolid extends Solid{
	private Tile tile;
	public TileSolid() {
		super(0,0);
	}
	public void setTile(Tile tile) {
		this.tile = tile;
	}
	public Tile getTile() {
		return tile;
	}
	public String toString() {
		if (tile == null) {
			throw new RuntimeException("Calling toString on TileSolid without having set tile attribute.");
		}
		return tile.toString();
	}
}