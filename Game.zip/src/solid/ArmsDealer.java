package solid;

import java.awt.Color;
import java.awt.image.BufferedImage;

import commerce.DefaultMerchant;
import commerce.Merchant;
import graphics.ImageGenerator;
import main.DialogOption;

public class ArmsDealer extends Talker {
	private final Color color;
	private BufferedImage img = null;
	private final Merchant shop;
	public ArmsDealer(Color color, double direction, Solid target, String[] items, int[] buyPrices, int[] sellPrices, int[] inventory, int money) {
		super(color, direction, target);
		this.color = color;
		shop = new DefaultMerchant("Merchant", items, buyPrices, sellPrices, inventory, money);
	}
	DialogOption yes = new DialogOption("Yes") {
		@Override
		public void choose() {
			shop.createShopInterface(getGame());
		}
	};
	@Override
	public void interact() {
		getGame().say("You meet a merchant. Would you like to trade?",
				yes,
				 getGame().getOption("No"));
	}
	public BufferedImage getImage() {
		if (img == null) {
			img = ImageGenerator.getPerson(color);
		}
		return img;
	}
}
