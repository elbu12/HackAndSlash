package solid;

import main.Game;
import tile.Tile;

/**
 * Though projectiles are solid and actors, they are not SolidActors,
 * as the latter represent living individuals.
 * 
 * Note that projectiles are modeled as points and thus their image
 * scale methods entirely determine the drawn image size.
 */
public abstract class Projectile extends Solid implements Actor{
	public Projectile(double x, double y, double maxDistance, double dx, double dy, Solid source) {
		super(x, y);
		this.maxDistance = maxDistance;
		this.dx = dx;
		this.dy = dy;
		this.source = source;
		sourceX = source.getX();
		sourceY = source.getY();
		setWorld(source.getWorld());
		//Do not use moveIfCan because it will collide with source
		if (place()) {
			Game game = getWorld().getGame();
			if (game != null) {
				//Game will only be null for testing purposes
				game.addActor(this);
			}
			direction = Math.atan2(dx, dy);
		}
	}

	private double maxDistance;	//square of max distance
	private Solid source;
	private double dx;
	private double dy;
	private final double sourceX;
	private final double sourceY;
	private boolean done;
	private double direction;
	
	@Override
	public double getDirection() {
		return direction;
	}

	@Override
	public void act() {
		//Travel along (dx, dy) and look for collisions. Remove this from its
		//containing tile to prevent self-collisions.
		for (Tile t : getTiles()) {
			t.remove(this);
		}
		getTiles().clear();
		double totalDx = getX() + dx - sourceX;
		double totalDy = getY() + dy - sourceY;
		if ((totalDx * totalDx) + (totalDy * totalDy) >= maxDistance * maxDistance) {
			//Projectile only flies as far as allowed
			double l2 = (dx * dx) + (dy * dy);
			double l = Math.sqrt(l2);
			double x1 = sourceX + (dx * maxDistance / l);
			double y1 = sourceY + (dy * maxDistance / l);
			dx = x1 - getX();
			dy = y1 - getY();
			done = true;	//Clean up after this step
		}
		//Skip collisions with source
		Solid hit = source.getFirstSolidHit(getX(), getY(), dx, dy);
		if (hit == null) {
			if (!done) {
				setX(getX() + dx);
				setY(getY() + dy);
				place();
			}
		}
		else {
			collision(hit);
			done = true;
		}
	}
	
	@Override
	public int getShape() {
		return POINT;
	}
	protected abstract void collision(Solid target);
	@Override
	public boolean isDead() {
		return done;
	}
	@Override
	public boolean isMobile() {
		return true;
	}
	private boolean place() {
		Tile tile = getWorld().get((int) getX(), (int) getY());
		if (tile == null || tile.isObstruction()) {
			done = true;
			return false;
		}
		else {
			tile.add(this);
			add(tile);
			return true;
		}
	}
}
