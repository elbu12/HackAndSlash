package solid;

import java.awt.Color;
import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
import support.Geometry;

public class Wielder extends SolidActor{
	/**
	 * When wielders attack, they iterate through an animated sequence.
	 * actionStep increases until it reaches the maximum, then decreases
	 * back to zero.
	 */
	private int actionStepMaximum = 64;
	
	//WEAPONS
	//These need to be mentioned in the pause screen, for selection
	public static final String NONE = "none";
	public static final String SWORD = "sword";
	public static final String SPEAR = "spear";	//Currently not implemented
	public static final String AXE = "axe";		//Currently not implemented
	public static final String BOW = "bow";
	
	public static final String ARROW = "arrow";	//Not directly equippable
	
	public static final String SHIELD = "shield";
	
	private boolean hasShield = false;
	private String weapon = NONE;
	private int actionStep = 0;	//Where it is in whatever action is performed
	private boolean actionStepIncreasing = false;
	
	private int colorIndex;
	public int getColorIndex() {
		return colorIndex;
	}
	public void setColorIndex(int colorIndex) {
		this.colorIndex = colorIndex;
	}
	
	public static final int BLUE = 0;
	public static final int RED = 1;
	public static final int GREEN = 2;
	
	public static final Color[] COLORS = new Color[] {Color.BLUE, Color.RED, Color.GREEN};
	
	protected static BufferedImage[][][] imgs = new BufferedImage[3][][];

	public Wielder(double radius, int maxHealth, int colorIndex) {
		super(radius, maxHealth);
		this.colorIndex = colorIndex;
	}
	public boolean hasShield() {
		return hasShield;
	}
	public void setHasShield(boolean hasShield) {
		this.hasShield = hasShield;
	}
	public String getWeapon() {
		return weapon;
	}
	public void setWeapon(String weapon) {
		this.weapon = weapon;
	}
	public int getActionStep() {
		return actionStep;
	}
	protected void setActionStep(int actionStep) {
		this.actionStep = actionStep;
	}
	public double getAttackSourceX() {
		if (hasShield()) {
			//If it holds a shield, the sword is to the side
			double dy = getDirectionY();
			double px = dy;
			if (swordXY == null) {
				initializeSwordAndShield();
			}
			return getX() + (swordXY[actionStep][0] * px * 2 * getRadius());
		}
		else {
			return super.getAttackSourceX();
		}
	}
	public double getAttackSourceY() {
		if (hasShield()) {
			//If it holds a shield, the sword is to the side
			double dx = getDirectionX();
			double py = -dx;
			if (swordXY == null) {
				initializeSwordAndShield();
			}
			return getY() + (swordXY[actionStep][0] * py * 2 * getRadius());
		}
		else {
			return super.getAttackSourceY();
		}
	}
	public double getAttackVectorX() {
		if (hasShield()) {
			return (swordXY[actionStep][1] * getDirectionX() * 2 * getRadius());
		}
		else {
			//TO DO: account for spear (?)
			return getDirectionX() * (1.25 + (actionStep * 0.01)) * getRadius() * 2;
		}
	}
	public double getAttackVectorY() {
		if (hasShield()) {
			return (swordXY[actionStep][1] * getDirectionY() * 2 * getRadius());
		}
		else {
			//TO DO: Account for spear (?)
			return getDirectionY() * (1.25 + (actionStep * 0.01)) * getRadius() * 2;
		}
		
	}
	public void act() {
		if (actionStepIncreasing) {
			actionStep += getActionStepIncrement();
			if (actionStep >= actionStepMaximum) {
				actionStep = actionStepMaximum;
				actionStepIncreasing = false;
			}
		}
		else if (actionStep > 0) {
			actionStep = Math.max(0, actionStep - getActionStepIncrement());
		}
		super.act();
		if (getActionStep() != 0 && !BOW.equals(weapon)) {
			//Do we hit anything?
			Solid hit = getFirstSolidHit(getAttackSourceX(),
					getAttackSourceY(), getAttackVectorX(), getAttackVectorY());
			if (hit != null) {
				attack(hit);
			}
		}
	}
	protected boolean canBeginAttack() {
		return actionStep == 0;
	}
	protected void beginAttack() {
		actionStep += getActionStepIncrement();
		actionStepIncreasing = true;
		if (BOW.equals(weapon)) {
			//Need to decide on arrow speed, etc
			double directionX = getDirectionX();
			double directionY = getDirectionY();
			double dx = directionX * 2 * Arrow.SCALE;
			double dy = directionY * 2 * Arrow.SCALE;
			double px = directionY * getRadius() * 0.27;
			double py = (-directionX) * getRadius() * 0.27;
			new Arrow(getX() + dx + px, getY() + dy + py, 20, getDirectionX(), getDirectionY(), this, getAttackDamage());
		}
	}
	private int getActionStepIncrement() {
		switch (weapon) {
		case BOW:
			return 2;
		default:
			return 8;
		}
	}
	protected void attack(Solid target) {
		super.attack(target);
		actionStepIncreasing = false;
	}
	/**
	 * Shield is modeled as a line segment with two ends.
	 * The "end" parameter determines which end we get.
	 * 
	 * If end == false then we get the left corner.
	 * If end == true we get the vector pointing from
	 * 	the left corner to the right corner
	 */
	protected double getShieldX(boolean end) {
		//Which direction are we facing?
		double dx = getDirectionX();
		double dy = getDirectionY();
		//Get perpendicular vector
		double px = dy;
		if (end) {
			return 0.8 * getRadius() * 2 * px;
		}
		initializeSwordAndShield();
		/**
		 * corner0 = (x, y) + (radius * 2 * (shieldXY[actionStep][0] * px) + (radius * 2 * (shieldXY[actionStep][1] * dx))
		 * corner1 = corner0 + (0.65 * radius * 2 * (px))
		 */
		double corner0x = getX() + (getRadius() * 2 * shieldXY[0] * px) +
				(getRadius() * 2 * shieldXY[1] * dx);
		return corner0x;
	}
	//See getShieldX
	protected double getShieldY(boolean end) {
		//Which direction are we facing?
		double dx = getDirectionX();
		double dy = getDirectionY();
		//Get perpendicular vector
		double py = -dx;
		if (end) {
			return 0.8 * getRadius() * 2 * py;
		}
		initializeSwordAndShield();
		double corner0y = getY() + (getRadius() * 2 * shieldXY[0] * py) +
				(getRadius() * 2 * shieldXY[1] * dy);
		return corner0y;
	}
	
	public void receiveAttack(Solid attacker) {
		if ((!hasShield()) ||
				(isPlayer() && !getCombatMode())) { 
			//Get hit if not holding shield, or if the player
			//has the shield but is not currently holding it
			super.receiveAttack(attacker);
		}
		else {
			//Does the attack hit the shield?
			double attackX = attacker.getAttackVectorX();
			double attackY = attacker.getAttackVectorY();
			double directionX = getDirectionX();
			double directionY = getDirectionY();
			double dot = (attackX * directionX) + (attackY * directionY);
			if (dot >= 0) {
				//attack coming in from wrong angle. Shield irrelevant
				super.receiveAttack(attacker);
				return;
			}
			//Find intersection point
			double sourceX = attacker.getAttackSourceX();
			double sourceY = attacker.getAttackSourceY();
			/**
			 * When testing for collision with the shield, we treat the sword
			 * as a line, because we want the shield to block it, even if the
			 * shield is held back within the solid's circle and the sword
			 * only hits the edge of it.
			 */
			if (Geometry.lineSegmentIntersectLine(
					getShieldX(false), getShieldY(false), getShieldX(true), getShieldY(true),
					sourceX, sourceY, attackX, attackY)) {
				blockAttack(attacker);
			}
			else {
				super.receiveAttack(attacker);
			}
		}
	}
	protected void blockAttack(Solid attacker) {
		//TO DO
	}
	/**
	 * Sword tip relative to center of person, in game units
	 * ie how far the sword reaches beyond their top, and right of center:
	 */
  	private static double[][] swordXY;
  	/**
  		Shield upper-left corner relative to center of person, in game units
    	ie how far the shield corner reaches beyond their top, and right of center.
    	Shield is 0.65 game units wide:
    */
	private static double[] shieldXY;
	private static final void initializeSwordAndShield() {
		if (swordXY == null) {
			swordXY = new double[65][2];
			swordXY[0][0] = 0.44;
			swordXY[0][1] = 0.75;
			swordXY[1][0] = 0.44;
			swordXY[1][1] = 0.76;
			swordXY[2][0] = 0.44;
			swordXY[2][1] = 0.77;
			swordXY[3][0] = 0.44;
			swordXY[3][1] = 0.78;
			swordXY[4][0] = 0.44;
			swordXY[4][1] = 0.79;
			swordXY[5][0] = 0.44;
			swordXY[5][1] = 0.8;
			swordXY[6][0] = 0.44;
			swordXY[6][1] = 0.81;
			swordXY[7][0] = 0.44;
			swordXY[7][1] = 0.82;
			swordXY[8][0] = 0.44;
			swordXY[8][1] = 0.83;
			swordXY[9][0] = 0.44;
			swordXY[9][1] = 0.84;
			swordXY[10][0] = 0.44;
			swordXY[10][1] = 0.85;
			swordXY[11][0] = 0.44;
			swordXY[11][1] = 0.86;
			swordXY[12][0] = 0.44;
			swordXY[12][1] = 0.87;
			swordXY[13][0] = 0.44;
			swordXY[13][1] = 0.88;
			swordXY[14][0] = 0.44;
			swordXY[14][1] = 0.89;
			swordXY[15][0] = 0.44;
			swordXY[15][1] = 0.9;
			swordXY[16][0] = 0.44;
			swordXY[16][1] = 0.91;
			swordXY[17][0] = 0.44;
			swordXY[17][1] = 0.92;
			swordXY[18][0] = 0.44;
			swordXY[18][1] = 0.93;
			swordXY[19][0] = 0.44;
			swordXY[19][1] = 0.94;
			swordXY[20][0] = 0.44;
			swordXY[20][1] = 0.95;
			swordXY[21][0] = 0.44;
			swordXY[21][1] = 0.96;
			swordXY[22][0] = 0.44;
			swordXY[22][1] = 0.97;
			swordXY[23][0] = 0.44;
			swordXY[23][1] = 0.98;
			swordXY[24][0] = 0.44;
			swordXY[24][1] = 0.99;
			swordXY[25][0] = 0.44;
			swordXY[25][1] = 1.0;
			swordXY[26][0] = 0.44;
			swordXY[26][1] = 1.01;
			swordXY[27][0] = 0.44;
			swordXY[27][1] = 1.02;
			swordXY[28][0] = 0.44;
			swordXY[28][1] = 1.03;
			swordXY[29][0] = 0.44;
			swordXY[29][1] = 1.04;
			swordXY[30][0] = 0.44;
			swordXY[30][1] = 1.05;
			swordXY[31][0] = 0.44;
			swordXY[31][1] = 1.06;
			swordXY[32][0] = 0.44;
			swordXY[32][1] = 1.07;
			swordXY[33][0] = 0.44;
			swordXY[33][1] = 1.08;
			swordXY[34][0] = 0.44;
			swordXY[34][1] = 1.09;
			swordXY[35][0] = 0.44;
			swordXY[35][1] = 1.1;
			swordXY[36][0] = 0.44;
			swordXY[36][1] = 1.11;
			swordXY[37][0] = 0.44;
			swordXY[37][1] = 1.12;
			swordXY[38][0] = 0.44;
			swordXY[38][1] = 1.13;
			swordXY[39][0] = 0.44;
			swordXY[39][1] = 1.14;
			swordXY[40][0] = 0.44;
			swordXY[40][1] = 1.15;
			swordXY[41][0] = 0.44;
			swordXY[41][1] = 1.16;
			swordXY[42][0] = 0.44;
			swordXY[42][1] = 1.17;
			swordXY[43][0] = 0.44;
			swordXY[43][1] = 1.18;
			swordXY[44][0] = 0.44;
			swordXY[44][1] = 1.19;
			swordXY[45][0] = 0.44;
			swordXY[45][1] = 1.2;
			swordXY[46][0] = 0.44;
			swordXY[46][1] = 1.21;
			swordXY[47][0] = 0.44;
			swordXY[47][1] = 1.22;
			swordXY[48][0] = 0.44;
			swordXY[48][1] = 1.23;
			swordXY[49][0] = 0.44;
			swordXY[49][1] = 1.24;
			swordXY[50][0] = 0.44;
			swordXY[50][1] = 1.25;
			swordXY[51][0] = 0.44;
			swordXY[51][1] = 1.26;
			swordXY[52][0] = 0.44;
			swordXY[52][1] = 1.27;
			swordXY[53][0] = 0.44;
			swordXY[53][1] = 1.28;
			swordXY[54][0] = 0.44;
			swordXY[54][1] = 1.29;
			swordXY[55][0] = 0.44;
			swordXY[55][1] = 1.3;
			swordXY[56][0] = 0.44;
			swordXY[56][1] = 1.31;
			swordXY[57][0] = 0.44;
			swordXY[57][1] = 1.32;
			swordXY[58][0] = 0.44;
			swordXY[58][1] = 1.33;
			swordXY[59][0] = 0.44;
			swordXY[59][1] = 1.34;
			swordXY[60][0] = 0.44;
			swordXY[60][1] = 1.35;
			swordXY[61][0] = 0.44;
			swordXY[61][1] = 1.36;
			swordXY[62][0] = 0.44;
			swordXY[62][1] = 1.37;
			swordXY[63][0] = 0.44;
			swordXY[63][1] = 1.38;
			swordXY[64][0] = 0.44;
			swordXY[64][1] = 1.39;
		}
		if (shieldXY == null) {
			shieldXY = new double[2];
			shieldXY[0] = -0.55;
			shieldXY[1] = 0.34;
		}
	}
	protected void initializeImages() {
		Color color = COLORS[colorIndex];
		BufferedImage neutral = ImageGenerator.getPerson(color);
		BufferedImage sidewaysWithBow = ImageGenerator.getPersonSidewaysWithBow(color);
		BufferedImage[] swords = ImageGenerator.getPersonWithSword(color);
		BufferedImage[] swordsAndShields = ImageGenerator.getPersonWithSwordAndShieldNew(color, Player.SHIELD_COLOR);
		imgs[colorIndex] = new BufferedImage[3][];
		imgs[colorIndex][0] = new BufferedImage[] {neutral, sidewaysWithBow};
		imgs[colorIndex][1] = swords;
		imgs[colorIndex][2] = swordsAndShields;
	}
	public BufferedImage getImage() {
		if (imgs[colorIndex] == null) {
			initializeImages();
		}
		if (getBehavior() == STAND && !isPlayer()) {
			return imgs[colorIndex][0][0];
		}
		switch (getWeapon()) {
		case SWORD:
			if (hasShield()) {
				return imgs[colorIndex][2][getActionStep()];
			}
			else {
				return imgs[colorIndex][1][getActionStep()];
			}
		case BOW:
			return imgs[colorIndex][0][1];
		default:
			return imgs[colorIndex][0][0];
		}
	}
	/**
	 * Note: the logic for getImage must match the logic for getImageScale methods
	 */
	public double getImageScaleX() {
		if (getBehavior() == STAND && !isPlayer()) {
			return 1;
		}
		switch (getWeapon()) {
		case SWORD:
			if (hasShield()) {
				return 1.1;
			}
			else {
				return 1;
			}
		case BOW:
			return 2.28;
		default:
			return 1;
		}
	}
	/**
	 * See note about matching logic for getImage
	 */
	public double getImageScaleY() {
		if (imgs[getColorIndex()] == null) {
			initializeImages();
		}
		if (getBehavior() == STAND && !isPlayer()) {
			return 1;
		}
		switch (getWeapon()) {
		case SWORD:
			if (hasShield()) {
				return imgs[colorIndex][2][getActionStep()].getHeight() / 100.0;
			}
			else {
				return imgs[colorIndex][1][getActionStep()].getHeight() / 100.0;
			}
		case BOW:
			return 2.28;
		default:
			return 1;
		}
	}
	public boolean getCombatMode() {
		throw new RuntimeException("Trying to get combat mode on non-player solid.");
	}
}
