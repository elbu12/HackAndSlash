package solid;

import java.util.ArrayDeque;

import support.PathNode;

public class SolidActor extends CircularSolid implements Actor{
	/**
	 * SolidActor is the parent class for most people/creatures/etc.
	 * It has the ability to move and receive damage.
	 */
	private int maxHealth;
	private int health;
	private double direction;
	private boolean dead;
	private double movementSpeed;
	private ArrayDeque <PathNode> path;
	private double destinationX = Double.NaN;
	private double destinationY = Double.NaN;
	/**
	 * Behavior determines what a solidActor is currently doing.
	 * A solidActor also has set behaviors for different situations,
	 * i.e. they will adopt this behavior in this context and a
	 * different behavior in a different context.
	 * 
	 * A solidActor may have a "target" solid, which is the focus
	 * of their behavior. "targetBehavior" is the behavior they
	 * display when aware of their target; "defaultBehavior" is
	 * the behavior they display otherwise.
	 * 
	 * detectionRadius determines when they can detect their target
	 * and switch behaviors. detectionRadius2 is its square. We
	 * only need the squared value, which we save for optimization.
	 */
	private Solid target;
	private int behavior;	//current behavior
	private int defaultBehavior;	//STAND if unspecified
	private int targetBehavior;		//STAND if unspecified
	private double detectionRadius2 = 225;
	
	//Behaviors
	public static final int PLAYER = -1;	//For player only
	public static final int STAND = 0;
	public static final int FOLLOW = 1;
	public static final int WANDER = 2;
	public static final int ATTACK_IMMEDIATELY = 3;
	public static final int APPROACH_WAIT_ATTACK = 4;
	
	public SolidActor(double radius, int maxHealth) {
		super(0, 0, radius);
		dead = false;
		this.maxHealth = maxHealth;
		health = maxHealth;
		path = new ArrayDeque<>();
	}
	public boolean isMobile() {
		return true;
	}
	protected void moveToward(double x, double y) {
		double dx = x - getX();
		double dy = y - getY();
		double d2 = (dx * dx) + (dy * dy);
		if (d2 > movementSpeed * movementSpeed) {
			double s = movementSpeed / Math.sqrt(d2);
			dx *= s;
			dy *= s;
		}
		getWorld().moveAsMuchAsPossible(this, getX() + dx, getY() + dy);
	}
	protected void moveTowardDestination() {
		if (!(Double.isNaN(destinationX) || Double.isNaN(destinationY))) {
			if (path.isEmpty()) {
				//Face destination
				face(destinationX, destinationY);
				//Move directly toward destination
				moveToward(destinationX, destinationY);
				if (getX() == destinationX && getY() == destinationY) {
					setX(Double.NaN);
					setY(Double.NaN);
				}
			}
			else {
				PathNode node = path.peek();
				double angle = Math.atan2(node.x - getX(), node.y - getY());
				setDirection(angle);
				moveToward(node.x, node.y);
				if (getX() == node.x && getY() == node.y) {
					path.pop();
				}
			}
		}
	}
	protected void moveTowardTarget() {
		if (target != null) {
			if (destinationX != target.getX() || destinationY != target.getY()) {
				//Old path invalidated; need to rebuild it
				getWorld().setPath(this, target.getX(), target.getY());
			}
			moveTowardDestination();
		}
		else {
			destinationX = Double.NaN;
			destinationY = Double.NaN;
			path.clear();
		}
	}
	protected void chooseBehavior() {
		if (target != null) {
			double dx = target.getX() - getX();
			double dy = target.getY() - getY();
			if ((dx * dx) + (dy * dy) <= detectionRadius2) {
				//target detected
				behavior = targetBehavior;
			}
			else {
				behavior = defaultBehavior;
			}
		}
	}
	public void act() {
		chooseBehavior();
		switch (behavior) {
		case STAND:
			destinationX = Double.NaN;
			destinationY = Double.NaN;
			path.clear();
			break;
		case FOLLOW:
			moveTowardTarget();
			break;
		case ATTACK_IMMEDIATELY:
			moveTowardTarget();
			//How close is the target?
			if (canBeginAttack() && target != null) {
				double dx = target.getX() - getX();
				double dy = target.getY() - getY();
				double d2 = (dx * dx) + (dy * dy);
				double r = getRadius() + target.getRadius() + getAttackRange();
				if (d2 <= r * r) {
					//Within range
					beginAttack();
				}
			}
			break;
		}
	}
	protected boolean canBeginAttack() {
		//returns false if already attacking
		return true;
	}
	protected void receiveAttack(Solid attacker) {
		receiveDamage(attacker.getAttackDamage());
	}
	protected void receiveDamage(int damage) {
		health -= damage;
		if (health <= 0) {
			die();
		}
	}
	protected void die() {
		dead = true;
	}
	public final boolean isDead() {
		return dead;
	}
	public double getMovementSpeed() {
		return 0.2;
	}
	public double getDirection() {
		return direction;
	}
	public void setDirection(double direction) {
		this.direction = direction;
		if (direction > 2 * Math.PI) {
			direction -= 2 * Math.PI;
		}
		else if (direction < 0) {
			direction += 2 * Math.PI;
		}
	}
	public void setDestination(double destinationX, double destinationY) {
		this.destinationX = destinationX;
		this.destinationY = destinationY;
	}
	public void clearPath() {
		path.clear();
	}
	public void push(PathNode node) {
		path.push(node);
	}
	public Solid getTarget() {
		return target;
	}
	public void setTarget(Solid target) {
		this.target = target;
	}
	public int getBehavior() {
		return behavior;
	}
	public void setBehavior(int defaultBehavior, int targetBehavior) {
		this.defaultBehavior = defaultBehavior;
		this.targetBehavior = targetBehavior;
		behavior = defaultBehavior;
	}
	public void setDetectionRadius(double detectionRadius) {
		detectionRadius2 = detectionRadius * detectionRadius;
	}
	public void setMovementSpeed(double movementSpeed) {
		this.movementSpeed = movementSpeed;
	}
	//Measured from the solidActor's edge
	public double getAttackRange() {
		return 0;
	}
	public int getHealth() {
		return health;
	}
	public int getMaxHealth() {
		return maxHealth;
	}
	protected void beginAttack() {}
	//For testing
	public ArrayDeque <PathNode> getPath() {
		return path;
	}
	//For testing
	public double getDestination(boolean x) {
		return (x ? destinationX : destinationY);
	}
}
