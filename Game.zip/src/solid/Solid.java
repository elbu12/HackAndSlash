package solid;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import main.Game;
import support.Geometry;
import tile.Tile;
import tile.World;

public abstract class Solid {
	public static final int CIRCLE = 0;
	public static final int RECTANGLE = 1;
	public static final int POINT = 2;
	private double x;
	private double y;
	private final List <Tile> tiles = new ArrayList<>();
	private World world;
	public Solid(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public int getShape() {
		return CIRCLE;
	}
	public final double getX() {
		return x;
	}
	public final void setX(double x) {
		this.x = x;
	}
	public final double getY() {
		return y;
	}
	public final void setY(double y) {
		this.y = y;
	}
	public final void setXY(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public double getWidth() {
		return 0;
	}
	public double getHeight() {
		return 0;
	}
	/**
	 * The two getImageScale methods designate how to scale
	 * the image beyond the size indicated by its official
	 * width/height/radius.
	 * 
	 * Use it if a solid's image should extend beyond its
	 * physical limits
	 */
	public double getImageScaleX() {
		return 1;
	}
	public double getImageScaleY() {
		return 1;
	}
	public double getRadius() {
		return 0;
	}
	public double getDirection() {
		return 0;
	}
	public void setDirection(double direction) {}
	public void face(double x, double y) {
		double angle = Math.atan2(x - this.x, y - this.y);
		setDirection(angle);
	}
	public void face(Solid solid) {
		face(solid.getX(), solid.getY());
	}
	public boolean isMobile() {
		return false;
	}
	public boolean walks() {
		return true;
	}
	public int getAttackDamage() {
		return 0;
	}
	public final double getDirectionX() {
		return Math.sin(getDirection());
	}
	public final double getDirectionY() {
		return Math.cos(getDirection());
	}
	public double getAttackSourceX() {
		return getX();
	}
	public double getAttackSourceY() {
		return getY();
	}
	public double getAttackVectorX() {
		return getDirectionX();
	}
	public double getAttackVectorY() {
		return getDirectionY();
	}
	protected void attack(Solid target) {
		target.receiveAttack(this);
	}
	protected void receiveAttack(Solid attacker) {
		//To be replaced in subclasses
	}
	protected void receiveDamage(int damage) {
		//To be replaced in subclasses
	}
	public void interact() {
		//Can be called by player
	}
	public final boolean intersectSolid(Solid solid) {
		return wouldIntersectSolid(x, y, solid, false);
	}
	//Determines if this would intersect solid if this is at (x,y)
	public final boolean wouldIntersectSolid(double x, double y, Solid solid, boolean ignoreMobileSolids) {
		if (ignoreMobileSolids && solid.isMobile()) {
			return false;
		}
		switch (getShape()) {
		case CIRCLE:
			switch (solid.getShape()) {
			case CIRCLE:
				return Geometry.circleIntersectCircle(x, y, getRadius(),
						solid.getX(), solid.getY(), solid.getRadius());
			case RECTANGLE:
				return Geometry.circleIntersectRectangle(x, y, getRadius(),
						solid.getX(), solid.getY(), solid.getWidth(), solid.getHeight());
			default:	//assume point
				return Geometry.circleIntersectPoint(x, y, getRadius(), solid.getX(), solid.getY());
			}
		case RECTANGLE:
			switch (solid.getShape()) {
			case CIRCLE:
				return Geometry.circleIntersectRectangle(solid.getX(), solid.getY(), solid.getRadius(),
						x, y, getWidth(), getHeight());
			case RECTANGLE:
				return Geometry.rectangleIntersectRectangle(x, y, getWidth(), getHeight(),
						solid.getX(), solid.getY(), solid.getWidth(), solid.getHeight());
			default:	//assume point
				return Geometry.rectangleIntersectPoint(x, y, getWidth(), getHeight(), solid.getX(), solid.getY());
			}
		case POINT:
			switch (solid.getShape()) {
			case CIRCLE:
				return Geometry.circleIntersectPoint(solid.getX(), solid.getY(), solid.getRadius(),
						x, y);
			case RECTANGLE:
				return Geometry.rectangleIntersectPoint(solid.getX(), solid.getY(), getWidth(), getHeight(), x, y);
			default:	//assume point
				return Geometry.pointIntersectPoint(x, y, solid.getX(), solid.getY());
			}
		}
		return false;
	}
	public final boolean intersects(Tile tile) {
		return Geometry.circleIntersectRectangle(x, y, getRadius(), tile.getX(), tile.getY(), 1, 1);
	}
	public final List <Tile> getTiles(){
		return tiles;
	}
	public final World getWorld(){
		if (world == null) {
			for (Tile tile : getTiles()) {
				if ((world = tile.getWorld()) != null) {
					break;
				}
			}
		}
		return world;
	}
	public final void setWorld(World world) {
		this.world = world;
	}
	public Game getGame() {
		return getWorld().getGame();
	}
	//returns false if tile is already contained
	public final boolean add(Tile tile) {
		if (tiles.contains(tile)) {
			return false;
		}
		tiles.add(tile);
		return true;
	}
	//returns false if tile is not already contained
	public final boolean remove(Tile tile) {
		for (int i=0; i<tiles.size(); i++) {
			if (tiles.get(i) == tile) {
				if (i == tiles.size() - 1) {
					tiles.remove(i);
				}
				else {
					//Replace with last element
					tiles.set(i, tiles.remove(tiles.size() - 1));
				}
				return true;
			}
		}
		return false;
	}
	//Gets tiles that would be intersected by moving to designated location
	public final List<Tile> getIntersectedTiles(double x, double y, World world) {
		return getIntersectedTiles(x, y, world, new ArrayList<>());
	}

	public final List<Tile> getIntersectedTiles(double x, double y, World world, List<Tile> tiles) {
		tiles.clear();
		int xStart;
		int xEnd;
		int yStart;
		int yEnd;
		switch (getShape()) {
		case CIRCLE:
			xStart = (int) (x - getRadius());
			xEnd = (int) (x + getRadius());
			yStart = (int) (y - getRadius());
			yEnd = (int) (y + getRadius());
			for (int i = xStart; i <= xEnd; i++) {
				for (int j = yStart; j <= yEnd; j++) {
					if (Geometry.circleIntersectRectangle(x, y, getRadius(), i, j, 1, 1)) {
						addTileIfNotNull(tiles, world.get(i, j));
					}
				}
			}
			break;
		case RECTANGLE:
			xStart = (int) x;
			xEnd = (int) (x + getWidth());
			yStart = (int) y;
			yEnd = (int) (y + getHeight());
			for (int i = xStart; i <= xEnd; i++) {
				for (int j = yStart; j <= yEnd; j++) {
					if (Geometry.rectangleIntersectRectangle(x, y, getWidth(), getHeight(), i, j, 1, 1)) {
						addTileIfNotNull(tiles, world.get(i, j));
					}
				}
			}
			break;
		default: // Assume just a point
			addTileIfNotNull(tiles, world.get((int) x, (int) y));
			break;
		}

		return tiles;
	}
	private static void addTileIfNotNull(List<Tile> tiles, Tile tile) {
		if (tile != null) {
			tiles.add(tile);
		}
	}
	/**
	 * Finds the first solid hit by the vector from (x,y) to (x+dx,y+dy)
	 * 
	 * Will exclude collisions with this solid itself. If nothing is hit,
	 * it returns null. If an obstructing tile is hit, it returns the
	 * world's TileSolid, containing that tile.
	 */
	public final Solid getFirstSolidHit(double x, double y, double dx, double dy) {
		World world = getWorld();
		Geometry.Intersection intersection = new Geometry.Intersection(false);
		final double x0 = x;
		final double y0 = y;
		while (x >= 0 && y >= 0) {
			//Look at everything in this tile
			Tile tile = world.get((int)x, (int)y);
			if (tile == null) {
				return null;
			}
			else if (tile.isObstruction()) {
				//Exceeded world or obstructed by tile itself
				return getWorld().getTileSolid(tile);
			}
			Solid result = null;
			double bestT = Double.MAX_VALUE;
			for (Solid solid : tile.getSolids()) {
				if (solid == this) {
					continue;
				}
				intersection = Geometry.lineSegmentIntersectSolid(x0, y0, dx, dy, solid, intersection);
				if (intersection.isIntersection() && intersection.getWhere() < bestT) {
					result = solid;
					bestT = intersection.getWhere();
				}
			}
			if (result != null) {
				//Found it
				return result;
			}
			/**
			 * No intersections. Proceed to next tile.
			 * Compare step that takes us into next column
			 * and step that takes us into next row.
			 * 
			 * Choose smaller step.
			 */
			double tx = Double.MAX_VALUE;
			double ty = Double.MAX_VALUE;
			double newx = 0;
			double newy = 0;
			if (dx > 0) {
				newx = (int)(x) + 1;
				tx = (newx - x0) / dx;
			}
			else if (dx < 0) {
				newx = (int)(x) - 0.0001;
				tx = (newx - x0) / dx;
			}
			if (dy > 0) {
				newy = (int)(y) + 1;
				ty = (newy - y0) / dy;
			}
			else if (dy < 0) {
				newy = (int)(y) - 0.0001;
				ty = (newy - y0) / dy;
			}
			
			if (tx < ty && tx <= 1) {
				x = newx;
				y = y0 + (tx * dy);
			}
			else if (ty <= 1) {
				y = newy;
				x = x0 + (ty * dx);
			}
			else {
				//Reached end of line segment
				return null;
			}
		}
		return null;
	}
	public final Solid getFirstSolidHit(double dx, double dy) {
		return getFirstSolidHit(getX(), getY(), dx, dy);
	}
	public final boolean canMove(double x, double y) {
		return getWorld().canMove(this, x, y);
	}
	public final boolean moveIfCan(double x, double y) {
		return getWorld().moveIfCan(this, x, y);
	}
	public final boolean moveAsMuchAsPossible(double x, double y) {
		return getWorld().moveAsMuchAsPossible(this, x, y);
	}
	public String toString() {
		return "Solid at (" + x +", " + y + ")";
	}
	public BufferedImage getImage() {
		/**
		 * The image's dimensions do not matter, as they will be scaled
		 * during drawing
		 */
		return null;
	}
	public boolean isPlayer() {
		return false;
	}
}
