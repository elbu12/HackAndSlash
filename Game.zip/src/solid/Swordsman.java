package solid;

import loot.Gold;

public class Swordsman extends Wielder{
	private final int gold;
	public Swordsman(int colorIndex, Solid target, boolean hasShield, int gold, double direction) {
		super(0.99, 100, colorIndex);
		setHasShield(hasShield);
		setTarget(target);
		setBehavior(STAND, ATTACK_IMMEDIATELY);
		setMovementSpeed(0.06);
		this.gold = gold;
		setDirection(direction);
	}
	public int getAttackDamage() {
		return 100;
	}
	public double getAttackRange() {
		return 1.39;
	}
	public void die() {
		super.die();
		if (gold > 0) {
			Gold loot = new Gold(gold);
			getWorld().place(loot, getX(), getY());
		}
	}
}
