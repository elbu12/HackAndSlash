package solid;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Arrow extends Projectile{
	private static BufferedImage img = null;
	public static final double SCALE = 0.8;
	/*
	 * Note that some arrow constants (speed, maxDistance) are set in Wielder
	 */

	private final int damage;
	public Arrow(double x, double y, double maxDistance, double dx, double dy, Solid source, int damage) {
		super(x, y, maxDistance, dx, dy, source);
		this.damage = damage;
	}
	@Override
	protected void collision(Solid target) {
		target.receiveAttack(this);
	}
	@Override
	public int getAttackDamage() {
		return damage;
	}
	@Override
	public BufferedImage getImage() {
		if (img == null) {
			final int head = 6;
			final int fletching = 12;
			img = new BufferedImage(90, 90, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = img.createGraphics();
			g.setColor(Color.BLACK);
			g.fillRect(45, 0, 2, head);
			g.setColor(new Color(128, 128, 0));
			g.fillRect(45, head, 2, img.getHeight() - (head + fletching));
			g.setColor(Color.WHITE);
			g.fillRect(45, img.getHeight() - fletching, 2, fletching);
			g.dispose();
		}
		return img;
	}
	@Override
	public double getImageScaleX() {
		return SCALE;
	}
	@Override
	public double getImageScaleY() {
		return SCALE;
	}
}
