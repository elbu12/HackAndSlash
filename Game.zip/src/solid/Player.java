package solid;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import loot.TriggeredInteraction;
import main.Game;
import support.Geometry;
import tile.Tile;

public class Player extends Wielder{
	/**
	 * Player.keys represents which keys are pressed.
	 * Index numbers are unrelated to actual key codes.
	 * Thus, Player.keys != Game.keys
	 */
	protected byte[] keys;
	
	public static final double ROTATION_SPEED = Math.PI / 48.0;
	
	private boolean combatMode = false;
	
	public static final Color SHIELD_COLOR = Color.black;	//Should this change?
	
	private int money;
	private Map <String, Integer> inventory;
	private Set <TriggeredInteraction> triggeredInteractions = new LinkedHashSet <>();
	public Player() {
		this(0.99, 100);
	}
	public Player(double radius, int maxHealth) {
		//for testing
		this(radius, maxHealth, BLUE);
	}
	public Player(double radius, int maxHealth, int colorIndex) {
		super(radius, maxHealth, colorIndex);
		keys = new byte[8];
		money = 0;
		inventory = new LinkedHashMap <> ();
	}
	public void act() {
		int dx = 0;
		int dy = 0;
		int da = 0;	//angle
		//Movement
		if (keys[Game.MOVE_UP] != Game.UNPRESSED) {
			dy = 1;
		}
		if (keys[Game.MOVE_DOWN] != Game.UNPRESSED) {
			dy -= 1;
		}
		if (keys[Game.TURN_RIGHT] != Game.UNPRESSED) {
			da = 1;
		}
		if (keys[Game.TURN_LEFT] != Game.UNPRESSED) {
			da -= 1;
		}
		if (keys[Game.MOVE_RIGHT] != Game.UNPRESSED) {
			dx += 1;
		}
		if (keys[Game.MOVE_LEFT] != Game.UNPRESSED) {
			dx += -1;
		}
		if (keys[Game.TOGGLE_COMBAT_MODE] == Game.JUST_PRESSED ||
				keys[Game.TOGGLE_COMBAT_MODE] == Game.PRESSED_AND_RELEASED) {
			if (!getWeapon().equals(NONE)) {
				toggleCombatMode();
			}
		}
		if (keys[Game.INTERACT_ATTACK] != Game.UNPRESSED) {
			if (combatMode) {
				if (canBeginAttack()) {
					beginAttack();
				}
			}
			else if (keys[Game.INTERACT_ATTACK] == Game.JUST_PRESSED ||
					keys[Game.INTERACT_ATTACK] == Game.PRESSED_AND_RELEASED){
				//Try to interact
				double idx = getDirectionX() * (getRadius() + 0.1);
				double idy = getDirectionY() * (getRadius() + 0.1);
				Solid target = getFirstSolidHit(idx, idy);
				if (target != null) {
					target.interact();
				}
			}
		}
		if (da != 0) {
			rotate(ROTATION_SPEED * (combatMode ? 2 : 1) * da);
		}
		if (dx != 0 || dy != 0) {
			double scalar = (dx != 0 && dy != 0 ? Geometry.INVERSE_ROOT_2 : 1) *
					getMovementSpeed();
			//Which direction are we facing? Scale movement by that
			double newDx = (Math.sin(getDirection()) * scalar * dy) +
					(Math.cos(getDirection()) * scalar * dx);
			double newDy = (Math.cos(getDirection()) * scalar * dy) -
					(Math.sin(getDirection()) * scalar * dx);
			moveAsMuchAsPossible(getX() + newDx, getY() + newDy);
			checkForTriggeredInteractions();
		}
		super.act();
	}
	public void checkForTriggeredInteractions() {
		triggeredInteractions.clear();
		for (Tile tile : getTiles()) {
			for (TriggeredInteraction i : tile.getTriggeredInteractions()) {
				triggeredInteractions.add(i);
			}
		}
		for (TriggeredInteraction i : triggeredInteractions) {
			boolean intersect;
			switch (i.getShape()) {
			case Solid.CIRCLE:
				intersect = Geometry.circleIntersectCircle(getX(), getY(), getRadius(), i.getX(), i.getY(), i.getRadius());
				break;
			case Solid.RECTANGLE:
				intersect = Geometry.circleIntersectRectangle(getX(), getY(), getRadius(), i.getX(), i.getY(), i.getWidth(), i.getHeight());
				break;
			default:
				intersect = Geometry.circleIntersectPoint(getX(), getY(), getRadius(), i.getX(), i.getY());
				break;
			}
			if (intersect) {
				i.interact();
			}
		}
	}
	public void setKeys(byte moveUp, byte moveDown, byte turnRight, byte turnLeft,
			byte moveRight, byte moveLeft, byte toggleCombatMode, byte interactAttack) {
		keys[Game.MOVE_UP] = moveUp;
		keys[Game.MOVE_DOWN] = moveDown;
		keys[Game.TURN_RIGHT] = turnRight;
		keys[Game.TURN_LEFT] = turnLeft;
		keys[Game.MOVE_RIGHT] = moveRight;
		keys[Game.MOVE_LEFT] = moveLeft;
		keys[Game.TOGGLE_COMBAT_MODE] = toggleCombatMode;
		keys[Game.INTERACT_ATTACK] = interactAttack;
	}
	final public boolean isPlayer() {
		return true;
	}
	public void rotate(double angle) {
		setDirection(getDirection() + angle);
		if (Math.abs(getDirection()) < 0.03141592653589793) {
			setDirection(0);
		}
	}
	public int getBehavior() {
		return PLAYER;
	}
	public String getEquipped() {
		//For writing to screen
		String weapon = (getWeapon().equals(NONE) ? null : getWeapon());
		if (hasShield()) {
			if (weapon == null) {
				return "shield";
			}
			else {
				return weapon + " and shield";
			}
		}
		else {
			return weapon;
		}
	}
	public int getMoney() {
		return money;
	}
	public void changeMoney(int change) {
		money += change;
	}
	public boolean getCombatMode() {
		return combatMode;
	}
	protected void toggleCombatMode() {
		//TO DO: Anything else happens when combat mode ends?
		combatMode = !combatMode;
	}
	public BufferedImage getImage() {
		if (combatMode) {
			return super.getImage();
		}
		if (imgs[getColorIndex()] == null) {
			initializeImages();
		}
		return imgs[getColorIndex()][0][0];
	}
	public double getImageScaleX() {
		return (combatMode ? super.getImageScaleX() : 1);
	}
	public double getImageScaleY() {
		return (combatMode ? super.getImageScaleY() : 1);
	}
	public Map <String, Integer> getInventory(){
		return inventory;
	}
	@Override
	protected boolean canBeginAttack() {
		if (BOW.equals(getWeapon()) && inventory.getOrDefault(ARROW, 0) == 0) {
			return false;
		}
		return super.canBeginAttack();
	}
	@Override
	protected void beginAttack() {
		if (BOW.equals(getWeapon())) {
			//Hopefully "get" does not return null
			inventory.put(ARROW, inventory.get(ARROW) - 1);
		}
		super.beginAttack();
	}
	public boolean isEquipped(String item) {
		//TO DO: check for armor here?
		return getWeapon().equals(item) || (SHIELD.equals(item) && hasShield());
	}
	@Override
	protected void blockAttack(Solid attacker) {
		receiveDamage(attacker.getAttackDamage() / 100);
	}
	@Override
	public int getAttackDamage() {
		return 100;
	}
}
