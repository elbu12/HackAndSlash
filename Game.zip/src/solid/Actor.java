package solid;

public interface Actor {
	public void act();
	public boolean isDead();
}
