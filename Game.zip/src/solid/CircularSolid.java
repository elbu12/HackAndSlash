package solid;

public class CircularSolid extends Solid{
	private double radius;
	public CircularSolid(double x, double y, double radius) {
		super(x, y);
		this.radius = radius;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
}
