package graphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import testing.IndividualImageTester;

public class ImageGenerator {
	public static BufferedImage getImageFromFile(String name) {
		try {
			return ImageIO.read(new File(name));
		}
		catch (IOException e) {
			if (name.indexOf("img/") < 0) {
				System.out.println("Could not find file " + name);
				System.out.println("Did you forget to look in the img folder?");
			}
			else {
				e.printStackTrace();
			}
			return null;
		}
	}
	public static BufferedImage getTree(int diameter) {
		//Generates a circular image with given diameter (in pixels)
		BufferedImage img = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();
		for (int i=Math.max(diameter * diameter / 9, 10); i>0; i--) {
			//Generate random leaves
			g.setColor(new Color(0, 50 + (int)(Math.random() * 121), 0));
			//Which orientation is this? 
			int width;
			int height;
			double orientation = Math.random();
			if (orientation < 0.4) {
				width = 10;
				height = 5;
			}
			else if (orientation < 0.8){
				width = 5;
				height = 10;
			}
			else {
				width = 5;
				height = 5;
			}
			//Pick a random spot, but do not exceed image bounds
			double angle = Math.PI * 2.0 * Math.random();
			int radius = diameter / 2;
			double r = radius * Math.sqrt(Math.random());
			int x = radius + (int)(Math.cos(angle) * r);
			int y = radius + (int)(Math.sin(angle) * r);
			//This represents the center of a leaf. Adjust to get corner
			x -= width / 2;
			y -= height / 2;
			//Adjust to stay in bounds
			x = Math.min(Math.max(x, 0), diameter - width);
			y = Math.min(Math.max(y, 0), diameter - height);
			g.fillOval(x, y, width, height);
		}
		g.dispose();
		return img;
	}
	//Constants for generating images of people
	public static final int THICKNESS = 40;
	public static final int BRIDGE_WIDTH = 20;
	public static final int HEAD_WIDTH = 36;
	public static final int HEAD_LENGTH = 40;
	public static final int PROTRUSION = 10;
	public static BufferedImage getHeadlessPerson(Color color) {
		BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();
		g.setColor(Color.YELLOW);
		g.drawOval(0, 0, 99, 99);
		g.drawOval(1, 1, 97, 97);
		g.setColor(color);
		g.fillOval(0, 50 - (THICKNESS / 2), 100 - BRIDGE_WIDTH, THICKNESS);
		g.fillOval(BRIDGE_WIDTH, 50 - (THICKNESS / 2), 100 - BRIDGE_WIDTH, THICKNESS);
		g.fillRect(50 - (BRIDGE_WIDTH / 2), 50 - (THICKNESS / 2), BRIDGE_WIDTH, THICKNESS);
		g.dispose();
		return img;
	}
	public static BufferedImage getPerson(Color color) {
		BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();
		g.drawImage(getHeadlessPerson(color), 0, 0, null);
		g.setColor(Color.BLACK);
		g.fillOval(50 - (HEAD_WIDTH / 2), 50 - PROTRUSION - (THICKNESS / 2), HEAD_WIDTH, HEAD_LENGTH);
		g.dispose();
		return img;
	}
	public static BufferedImage getPersonSideways(Color color) {
		BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();
		g.setColor(Color.YELLOW);
		g.drawOval(0, 0, 99, 99);
		g.drawOval(1, 1, 97, 97);
		g.setColor(color);
		g.fillOval(50 - (THICKNESS / 2), 0, THICKNESS, 100 - BRIDGE_WIDTH);
		g.fillOval(50 - (THICKNESS / 2), BRIDGE_WIDTH, THICKNESS, 100 - BRIDGE_WIDTH);
		g.fillRect(50 - (THICKNESS / 2), 50 - (BRIDGE_WIDTH / 2), THICKNESS, BRIDGE_WIDTH);
		g.setColor(Color.BLACK);
		g.fillOval(50 - (HEAD_WIDTH / 2) - (PROTRUSION / 2), 50 - PROTRUSION - (THICKNESS / 2), HEAD_WIDTH, HEAD_LENGTH);
		g.dispose();
		return img;
	}
	public static final Color BOW_COLOR = new Color(100, 100, 0);
	public static BufferedImage getPersonSidewaysWithBow(Color color) {
		BufferedImage sideways = getPersonSideways(color);
		BufferedImage nonRotated = new BufferedImage(100, 228, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = nonRotated.createGraphics();
		g.setColor(color);
		g.fillRect(52 - (THICKNESS / 6), THICKNESS / 6, THICKNESS / 3, 64 - (THICKNESS / 6));
		g.fillOval(52 - (THICKNESS / 6), 0, THICKNESS / 3, THICKNESS / 3);
		AffineTransform transform = new AffineTransform(-1, 0, 0, 1, 100, 64);
		g.drawImage(sideways, transform, null);
		g.dispose();
		double a = Math.PI * 2.0 * 5.0 / 360.0;
		BufferedImage img = new BufferedImage(228, 228, BufferedImage.TYPE_INT_ARGB);
		g = img.createGraphics();
		g.setColor(color);
		//back arm
		g.fillRect(114, 114, 21, 52);
		transform.setToRotation(a, 50, 114);
		transform.translate(64, -5);
		g.drawImage(nonRotated, transform, null);
		g.setColor(BOW_COLOR);
		int bowLength = 50;
		g.fillRect(125, 10, 5, bowLength);
		g.setColor(Color.WHITE);
		g.fillRect(126, 10 + bowLength, 3, 88 - (10 + bowLength));
		g.dispose();
		return img;
	}
	public static BufferedImage[] getPersonWithSword(Color color) {
		BufferedImage baseImg = getPersonSideways(color);
		BufferedImage[] imgs = new BufferedImage[65];
		for (int i=0; i<imgs.length; i++) {
			imgs[i] = new BufferedImage(100, 250 + (i * 2), BufferedImage.TYPE_INT_ARGB);
			int topEdge = 75 + i;
			Graphics g = imgs[i].getGraphics();
			//Draw arm
			g.setColor(color);
			g.fillRect(50 - (THICKNESS / 6), topEdge - i, (THICKNESS / 3), i + 4);
			//Draw sword
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect(38, topEdge - (i + 3), 24, 3);
			g.drawLine(48, topEdge - (i+1), 48, 4);
			g.drawLine(49, topEdge - (i+1), 49, 2);
			g.drawLine(50, topEdge - (i+1), 50, 0);
			g.drawLine(51, topEdge - (i+1), 51, 2);
			g.drawLine(52, topEdge - (i+1), 52, 4);
			g.drawImage(baseImg, 0, topEdge, null);
			g.dispose();
		}
		return imgs;
	}
	public static BufferedImage getHeadlessPersonWithShield(Color personColor, Color shieldColor) {
		BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = img.createGraphics();
		AffineTransform transform = new AffineTransform();
		transform.setToRotation(Math.PI * 0.25, 50, 50);
		g.drawImage(getHeadlessPerson(personColor), transform, null);
		//shield
		g.setColor(shieldColor);
		g.fillRect(10, 2, 66, 7);
		//arm
		final int armWidth = THICKNESS / 3;
		final int handEdge = 40;
		g.setColor(personColor);
		g.fillOval(12, 8, armWidth, armWidth);
		g.fillOval(handEdge, 8, armWidth, armWidth);
		g.fillRect(12 + (armWidth / 2), 8, (handEdge - 11), armWidth);
		g.fillRect(12, 8 + (armWidth / 2), armWidth, 16);
		g.dispose();
		return img;
	}
	public static BufferedImage[] getPersonWithSwordAndShieldOld(Color personColor, Color shieldColor) {
		BufferedImage[] imgs = new BufferedImage[65];
		AffineTransform transform = new AffineTransform();
		for (int i=0; i<imgs.length; i++) {
			int height = 346;
			int width = 124;
			imgs[i] = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
			/**
			 * centerY is at height/2
			 * right shoulder is at (width/2,centerY)+(50cos(angle),50sin(angle))
			 * 		angle goes -pi/4 to pi/4
			 * 
			 * angle is (-pi / 4) + (i * pi / 128)
			 */
			Graphics2D g = imgs[i].createGraphics();
			transform.setToTranslation((width - 100) / 2, (height - 100)/2);
			transform.rotate(-Math.PI * i / 128.0, 50, 50);
			g.drawImage(getHeadlessPersonWithShield(personColor, shieldColor), transform, null);
			double angle = (-Math.PI * 0.25) + (i * Math.PI / 128.0);
			int shoulderX = (int)((width*0.5)+(49*Math.cos(angle)));
			int shoulderY = (int)((height*0.5)-(49*Math.sin(angle)));
			//Draw arm
			g.setColor(personColor);
			int wrist = shoulderY - (48 + (i * 1 / 4));
			int armLength = shoulderY + 1 - wrist;
			int extraX = Math.abs(i + 1 - 32) / 11;
			g.fillRect(shoulderX - (THICKNESS / 3) + extraX, wrist,
					THICKNESS / 3, armLength);
			//Draw sword
			g.setColor(Color.LIGHT_GRAY);
			int swordX = shoulderX + extraX - (THICKNESS / 6);
			g.fillRect(swordX- 12, wrist, 24, 3);
			g.drawLine(swordX - 2, wrist - 1, swordX - 2, wrist - 70);
			g.drawLine(swordX - 1, wrist - 1, swordX - 1, wrist - 72);
			g.drawLine(swordX + 0, wrist - 1, swordX + 0, wrist - 74);
			g.drawLine(swordX + 1, wrist - 1, swordX + 1, wrist - 72);
			g.drawLine(swordX + 2, wrist - 1, swordX + 2, wrist - 70);
			g.setColor(Color.BLACK);
			g.fillOval((width / 2) - (HEAD_WIDTH / 2) - (PROTRUSION / 2), (height / 2) - PROTRUSION - (THICKNESS / 2), HEAD_WIDTH, HEAD_LENGTH);
			g.dispose();
		}
		return imgs;
	}
	public static BufferedImage getShieldAndArm(Color personColor, Color shieldColor) {
		BufferedImage img = new BufferedImage(66, 30, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = img.createGraphics();
		g.setColor(shieldColor);
		g.fillRect(0, 2, 65, 7);
		//arm
		final int armWidth = THICKNESS / 3;
		final int handEdge = 30;
		g.setColor(personColor);
		g.fillOval(2, 8, armWidth, armWidth);
		//Center of elbow at 2+(THICKNESS/6), 8+(THICKNESS/6)
		g.fillOval(handEdge, 8, armWidth, armWidth);
		g.fillRect(2 + (armWidth / 2), 8, (handEdge - 3), armWidth);
		g.dispose();
		return img;
	}
	public static BufferedImage[] getPersonWithSwordAndShield(Color personColor, Color shieldColor) {
		BufferedImage[] imgs = new BufferedImage[65];
		AffineTransform transform = new AffineTransform();
//		System.out.print("double[][] swordXY = new double[");
//		System.out.print(imgs.length);
//		System.out.println("][2];");
//		System.out.print("double[][] shieldXY = new double[");
//		System.out.print(imgs.length);
//		System.out.println("][2];");
		for (int i=0; i<imgs.length; i++) {
			int height = 346;
			int width = 124;
			imgs[i] = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
			/**
			 * centerY is at height/2
			 * right shoulder is at (width/2,centerY)+(50cos(angle),50sin(angle))
			 * 		angle goes -pi/4 to pi/4
			 * 
			 * angle is (-pi / 4) + (i * pi / 128)
			 */
			Graphics2D g = imgs[i].createGraphics();
			transform.setToTranslation((width - 100) / 2, (height - 100)/2);
			transform.rotate(Math.PI * (0.25 - i/256.0), 50, 50);
			g.drawImage(getHeadlessPerson(personColor), transform, null);
			double angle = (-Math.PI * 0.25) + (i * Math.PI / 256.0);
			int shoulderX = (int)((width*0.5)+(49*Math.cos(angle)));
			int shoulderY = (int)((height*0.5)-(49*Math.sin(angle)));
			//Draw arm
			g.setColor(personColor);
			int wrist = shoulderY - (48 + (i * 1 / 4));
			int armLength = shoulderY + 1 - wrist;
			int extraX = (2 - i/32);
			g.fillRect(shoulderX - (THICKNESS / 3) + extraX, wrist,
					THICKNESS / 3, armLength);
			//Draw sword
			g.setColor(Color.LIGHT_GRAY);
			int swordX = shoulderX + extraX - (THICKNESS / 6);
			g.fillRect(swordX- 12, wrist, 24, 3);
			g.drawLine(swordX - 2, wrist - 1, swordX - 2, wrist - 70);
			g.drawLine(swordX - 1, wrist - 1, swordX - 1, wrist - 72);
			g.drawLine(swordX + 0, wrist - 1, swordX + 0, wrist - 74);
			//Record sword tip
//			double sx = swordX - (width * 0.5);
//			double sy = (wrist - 74) - (height * 0.5);
//			sx /= 100.0;
//			sy /= -100.0;
//			System.out.println("swordXY[" + i + "][0] = " + sx + ";");
//			System.out.println("swordXY[" + i + "][1] = " + sy + ";");
			g.drawLine(swordX + 1, wrist - 1, swordX + 1, wrist - 72);
			g.drawLine(swordX + 2, wrist - 1, swordX + 2, wrist - 70);
			shoulderX = (int)((width*0.5)-(49*Math.cos(angle)));
			shoulderY = (int)((height*0.5)+(49*Math.sin(angle)));
			int minShoulderY = (int)((height*0.5)+(49*Math.sin(-0.25 * Math.PI )));
			int shieldY = (minShoulderY + (9 * (shoulderY - minShoulderY) / 24));
			g.drawImage(getShieldAndArm(personColor, shieldColor), shoulderX-3, shieldY-17,  null);
//			System.out.println("shieldXY[" + i + "][0] = " + (((shoulderX-3) - width*0.5)*0.01) + ";");
//			System.out.println("shieldXY[" + i + "][1] = " + (((shieldY-17) - height*0.5)*(-0.01)) + ";");
			g.setColor(personColor);
			armLength = shoulderY - shieldY;
			g.fillRect(shoulderX, shieldY, (5 * THICKNESS / 12), armLength);
			g.setColor(Color.BLACK);
			g.fillOval((width / 2) - (HEAD_WIDTH / 2), (height / 2) - PROTRUSION - (THICKNESS / 2), HEAD_WIDTH, HEAD_LENGTH);
			g.dispose();
		}
		return imgs;
	}
	public static BufferedImage[] getPersonWithSwordAndShieldNew(Color personColor, Color shieldColor) {
		BufferedImage[] imgs = new BufferedImage[65];
		BufferedImage personImg = getPerson(personColor);
		int extraX = 5;
		BufferedImage baseImg = new BufferedImage(100 + (extraX * 2), 100, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = baseImg.createGraphics();
		g.setColor(shieldColor);
		g.fillRect(0, 15, 80, 7);
		g.drawImage(personImg, extraX, 0, null);
		g.dispose();
//		System.out.println("swordXY = new double[65][2];");
//		System.out.println("shieldXY = new double[65][2];");
		for (int i=0; i<imgs.length; i++) {
			imgs[i] = new BufferedImage(baseImg.getWidth(), 150 + i + i, BufferedImage.TYPE_INT_ARGB);
			int verticalCenter = 75 + i;
			g = imgs[i].createGraphics();
			g.setColor(personColor);
			g.fillRect(100 + extraX - (THICKNESS / 3), verticalCenter - i, THICKNESS / 3, i);
			g.setColor(Color.LIGHT_GRAY);
			int swordX = 100 + extraX - (THICKNESS / 6);
			g.drawLine(swordX - 2, verticalCenter - (i + 1), swordX - 2, 4);
			g.drawLine(swordX - 1, verticalCenter - (i + 1), swordX - 1, 2);
			g.drawLine(swordX - 0, verticalCenter - (i + 1), swordX - 0, 0);
			g.drawLine(swordX + 1, verticalCenter - (i + 1), swordX + 1, 2);
			g.drawLine(swordX + 2, verticalCenter - (i + 1), swordX + 2, 4);
			g.drawImage(baseImg, 0, verticalCenter - (baseImg.getHeight() / 2), null);
			g.dispose();
//			System.out.println("swordXY["+i+"][0] = " + ((swordX - (50 + extraX)) / 100.0) + ";");
//			System.out.println("swordXY["+i+"][1] = " + ((imgs[i].getHeight()) / 200.0) + ";");
		//	System.out.println("shieldXY["+i+"][0] = " + (-(50+extraX)/100.0) + ";");
		//	System.out.println("shieldXY["+i+"][1] = " + (0.34) + ";");
		}
		return imgs;
	}
	/**
	 * Draws a tilted rectangle from (x0,y0) to (x1,1).
	 * That vector runs through the center of the rectangle.
	 * It has thickness of "thickness"
	 * 
	 * If the booleans are true, it will round the edges with disks.
	 
	private static void drawTiltedOval(Graphics2D g, int x0, int y0, int x1, int y1, boolean oval0, boolean oval1, int thickness) {
		int dx = x1 - x0;
		int dy = y1 - y0;
		double px = dy;
		double py = -dx;
		double l = Math.sqrt((px * px) + (py * py));
		int ux = (int) (px * thickness / (2.0 * l));
		int uy = (int) (py * thickness / (2.0 * l));
		g.fillPolygon(new int[] {x0 + ux, x1 + ux, x1 - ux, x0 - ux},
				new int[] {y0 + uy, y1 + uy, y1 - uy, y0 - uy}, 4);
		if (oval0) {
			g.fillOval(x0 - (thickness / 2), y0 - (thickness / 2), thickness, thickness);
		}
		if (oval1) {
			g.fillOval(x1 - (thickness / 2), y1 - (thickness / 2), thickness, thickness);
		}
	}**/
	/**
	 * Sword tip relative to center of person, in game units
	 * ie how far the sword reaches beyond their top, and right of center:
	 * 
	  	double[][] swordXY = new double[65][2];
swordXY[0][0] = 0.44;
swordXY[0][1] = 0.75;
swordXY[1][0] = 0.44;
swordXY[1][1] = 0.76;
swordXY[2][0] = 0.44;
swordXY[2][1] = 0.77;
swordXY[3][0] = 0.44;
swordXY[3][1] = 0.78;
swordXY[4][0] = 0.44;
swordXY[4][1] = 0.79;
swordXY[5][0] = 0.44;
swordXY[5][1] = 0.8;
swordXY[6][0] = 0.44;
swordXY[6][1] = 0.81;
swordXY[7][0] = 0.44;
swordXY[7][1] = 0.82;
swordXY[8][0] = 0.44;
swordXY[8][1] = 0.83;
swordXY[9][0] = 0.44;
swordXY[9][1] = 0.84;
swordXY[10][0] = 0.44;
swordXY[10][1] = 0.85;
swordXY[11][0] = 0.44;
swordXY[11][1] = 0.86;
swordXY[12][0] = 0.44;
swordXY[12][1] = 0.87;
swordXY[13][0] = 0.44;
swordXY[13][1] = 0.88;
swordXY[14][0] = 0.44;
swordXY[14][1] = 0.89;
swordXY[15][0] = 0.44;
swordXY[15][1] = 0.9;
swordXY[16][0] = 0.44;
swordXY[16][1] = 0.91;
swordXY[17][0] = 0.44;
swordXY[17][1] = 0.92;
swordXY[18][0] = 0.44;
swordXY[18][1] = 0.93;
swordXY[19][0] = 0.44;
swordXY[19][1] = 0.94;
swordXY[20][0] = 0.44;
swordXY[20][1] = 0.95;
swordXY[21][0] = 0.44;
swordXY[21][1] = 0.96;
swordXY[22][0] = 0.44;
swordXY[22][1] = 0.97;
swordXY[23][0] = 0.44;
swordXY[23][1] = 0.98;
swordXY[24][0] = 0.44;
swordXY[24][1] = 0.99;
swordXY[25][0] = 0.44;
swordXY[25][1] = 1.0;
swordXY[26][0] = 0.44;
swordXY[26][1] = 1.01;
swordXY[27][0] = 0.44;
swordXY[27][1] = 1.02;
swordXY[28][0] = 0.44;
swordXY[28][1] = 1.03;
swordXY[29][0] = 0.44;
swordXY[29][1] = 1.04;
swordXY[30][0] = 0.44;
swordXY[30][1] = 1.05;
swordXY[31][0] = 0.44;
swordXY[31][1] = 1.06;
swordXY[32][0] = 0.44;
swordXY[32][1] = 1.07;
swordXY[33][0] = 0.44;
swordXY[33][1] = 1.08;
swordXY[34][0] = 0.44;
swordXY[34][1] = 1.09;
swordXY[35][0] = 0.44;
swordXY[35][1] = 1.1;
swordXY[36][0] = 0.44;
swordXY[36][1] = 1.11;
swordXY[37][0] = 0.44;
swordXY[37][1] = 1.12;
swordXY[38][0] = 0.44;
swordXY[38][1] = 1.13;
swordXY[39][0] = 0.44;
swordXY[39][1] = 1.14;
swordXY[40][0] = 0.44;
swordXY[40][1] = 1.15;
swordXY[41][0] = 0.44;
swordXY[41][1] = 1.16;
swordXY[42][0] = 0.44;
swordXY[42][1] = 1.17;
swordXY[43][0] = 0.44;
swordXY[43][1] = 1.18;
swordXY[44][0] = 0.44;
swordXY[44][1] = 1.19;
swordXY[45][0] = 0.44;
swordXY[45][1] = 1.2;
swordXY[46][0] = 0.44;
swordXY[46][1] = 1.21;
swordXY[47][0] = 0.44;
swordXY[47][1] = 1.22;
swordXY[48][0] = 0.44;
swordXY[48][1] = 1.23;
swordXY[49][0] = 0.44;
swordXY[49][1] = 1.24;
swordXY[50][0] = 0.44;
swordXY[50][1] = 1.25;
swordXY[51][0] = 0.44;
swordXY[51][1] = 1.26;
swordXY[52][0] = 0.44;
swordXY[52][1] = 1.27;
swordXY[53][0] = 0.44;
swordXY[53][1] = 1.28;
swordXY[54][0] = 0.44;
swordXY[54][1] = 1.29;
swordXY[55][0] = 0.44;
swordXY[55][1] = 1.3;
swordXY[56][0] = 0.44;
swordXY[56][1] = 1.31;
swordXY[57][0] = 0.44;
swordXY[57][1] = 1.32;
swordXY[58][0] = 0.44;
swordXY[58][1] = 1.33;
swordXY[59][0] = 0.44;
swordXY[59][1] = 1.34;
swordXY[60][0] = 0.44;
swordXY[60][1] = 1.35;
swordXY[61][0] = 0.44;
swordXY[61][1] = 1.36;
swordXY[62][0] = 0.44;
swordXY[62][1] = 1.37;
swordXY[63][0] = 0.44;
swordXY[63][1] = 1.38;
swordXY[64][0] = 0.44;
swordXY[64][1] = 1.39;
		
		Shield upper-left corner relative to center of person, in game units
	    ie how far the shield corner reaches beyond their top, and right of center.
	    Shield is 0.8 game units wide:
		double[][] shieldXY = new double[65][2];
shieldXY[0][0] = -0.55;
shieldXY[0][1] = 0.15;
shieldXY[1][0] = -0.55;
shieldXY[1][1] = 0.15;
shieldXY[2][0] = -0.55;
shieldXY[2][1] = 0.15;
shieldXY[3][0] = -0.55;
shieldXY[3][1] = 0.15;
shieldXY[4][0] = -0.55;
shieldXY[4][1] = 0.15;
shieldXY[5][0] = -0.55;
shieldXY[5][1] = 0.15;
shieldXY[6][0] = -0.55;
shieldXY[6][1] = 0.15;
shieldXY[7][0] = -0.55;
shieldXY[7][1] = 0.15;
shieldXY[8][0] = -0.55;
shieldXY[8][1] = 0.15;
shieldXY[9][0] = -0.55;
shieldXY[9][1] = 0.15;
shieldXY[10][0] = -0.55;
shieldXY[10][1] = 0.15;
shieldXY[11][0] = -0.55;
shieldXY[11][1] = 0.15;
shieldXY[12][0] = -0.55;
shieldXY[12][1] = 0.15;
shieldXY[13][0] = -0.55;
shieldXY[13][1] = 0.15;
shieldXY[14][0] = -0.55;
shieldXY[14][1] = 0.15;
shieldXY[15][0] = -0.55;
shieldXY[15][1] = 0.15;
shieldXY[16][0] = -0.55;
shieldXY[16][1] = 0.15;
shieldXY[17][0] = -0.55;
shieldXY[17][1] = 0.15;
shieldXY[18][0] = -0.55;
shieldXY[18][1] = 0.15;
shieldXY[19][0] = -0.55;
shieldXY[19][1] = 0.15;
shieldXY[20][0] = -0.55;
shieldXY[20][1] = 0.15;
shieldXY[21][0] = -0.55;
shieldXY[21][1] = 0.15;
shieldXY[22][0] = -0.55;
shieldXY[22][1] = 0.15;
shieldXY[23][0] = -0.55;
shieldXY[23][1] = 0.15;
shieldXY[24][0] = -0.55;
shieldXY[24][1] = 0.15;
shieldXY[25][0] = -0.55;
shieldXY[25][1] = 0.15;
shieldXY[26][0] = -0.55;
shieldXY[26][1] = 0.15;
shieldXY[27][0] = -0.55;
shieldXY[27][1] = 0.15;
shieldXY[28][0] = -0.55;
shieldXY[28][1] = 0.15;
shieldXY[29][0] = -0.55;
shieldXY[29][1] = 0.15;
shieldXY[30][0] = -0.55;
shieldXY[30][1] = 0.15;
shieldXY[31][0] = -0.55;
shieldXY[31][1] = 0.15;
shieldXY[32][0] = -0.55;
shieldXY[32][1] = 0.15;
shieldXY[33][0] = -0.55;
shieldXY[33][1] = 0.15;
shieldXY[34][0] = -0.55;
shieldXY[34][1] = 0.15;
shieldXY[35][0] = -0.55;
shieldXY[35][1] = 0.15;
shieldXY[36][0] = -0.55;
shieldXY[36][1] = 0.15;
shieldXY[37][0] = -0.55;
shieldXY[37][1] = 0.15;
shieldXY[38][0] = -0.55;
shieldXY[38][1] = 0.15;
shieldXY[39][0] = -0.55;
shieldXY[39][1] = 0.15;
shieldXY[40][0] = -0.55;
shieldXY[40][1] = 0.15;
shieldXY[41][0] = -0.55;
shieldXY[41][1] = 0.15;
shieldXY[42][0] = -0.55;
shieldXY[42][1] = 0.15;
shieldXY[43][0] = -0.55;
shieldXY[43][1] = 0.15;
shieldXY[44][0] = -0.55;
shieldXY[44][1] = 0.15;
shieldXY[45][0] = -0.55;
shieldXY[45][1] = 0.15;
shieldXY[46][0] = -0.55;
shieldXY[46][1] = 0.15;
shieldXY[47][0] = -0.55;
shieldXY[47][1] = 0.15;
shieldXY[48][0] = -0.55;
shieldXY[48][1] = 0.15;
shieldXY[49][0] = -0.55;
shieldXY[49][1] = 0.15;
shieldXY[50][0] = -0.55;
shieldXY[50][1] = 0.15;
shieldXY[51][0] = -0.55;
shieldXY[51][1] = 0.15;
shieldXY[52][0] = -0.55;
shieldXY[52][1] = 0.15;
shieldXY[53][0] = -0.55;
shieldXY[53][1] = 0.15;
shieldXY[54][0] = -0.55;
shieldXY[54][1] = 0.15;
shieldXY[55][0] = -0.55;
shieldXY[55][1] = 0.15;
shieldXY[56][0] = -0.55;
shieldXY[56][1] = 0.15;
shieldXY[57][0] = -0.55;
shieldXY[57][1] = 0.15;
shieldXY[58][0] = -0.55;
shieldXY[58][1] = 0.15;
shieldXY[59][0] = -0.55;
shieldXY[59][1] = 0.15;
shieldXY[60][0] = -0.55;
shieldXY[60][1] = 0.15;
shieldXY[61][0] = -0.55;
shieldXY[61][1] = 0.15;
shieldXY[62][0] = -0.55;
shieldXY[62][1] = 0.15;
shieldXY[63][0] = -0.55;
shieldXY[63][1] = 0.15;
shieldXY[64][0] = -0.55;
shieldXY[64][1] = 0.15;
	 */
	public static void main(String[] args) {
		IndividualImageTester.main(args);
	}
}
