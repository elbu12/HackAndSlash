package graphics;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import main.Game;
import solid.Player;
import solid.Wielder;

@SuppressWarnings("serial")
public class GameFrame extends JFrame{
	private final Game game;
	private final JPanel mainPanel = new JPanel(){
		public void paintComponent(Graphics g) {
			//We want a square image
			int length = Math.min(getWidth(), getHeight());
			g.drawImage(game.getImage(length, length), 0, 0, null);
		}
	};
	private JLabel healthLabel;
	private JLabel equippedLabel;
	private JLabel moneyLabel;
	private JLabel ammunitionLabel;
	public GameFrame(Game game) {
		super("Game");
		this.game = game;
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(screenSize);
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weighty = 0;
		gbc.weightx = 1;
		gbc.gridwidth = 1;
		gbc.fill = GridBagConstraints.BOTH;
		healthLabel = new JLabel("Health: 100/100");
		equippedLabel = new JLabel("Equipped: none");
		moneyLabel = new JLabel("Money: 0");
		ammunitionLabel = new JLabel("");
		add(healthLabel, gbc);
		gbc.gridx++;
		add(equippedLabel, gbc);
		gbc.gridx++;
		add(moneyLabel, gbc);
		gbc.gridx++;
		add(ammunitionLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.gridwidth = 4;
		gbc.weighty = 1;
		add(mainPanel, gbc);
		addKeyListener(game);
		setVisible(true);
	}
	public void repaint() {
		super.repaint();
		Player player = game.getPlayer();
		int health = Math.max(player.getHealth(), 0);
		healthLabel.setText("Health: " + health + "/" + player.getMaxHealth());
		equippedLabel.setText("Equipped: " + player.getEquipped());
		moneyLabel.setText("Money: " + player.getMoney());
		if (Wielder.BOW.equals(player.getWeapon())) {
			ammunitionLabel.setText("Arrows: " + player.getInventory().getOrDefault(Wielder.ARROW, 0));
		}
		else {
			ammunitionLabel.setText("");
		}
	}
	
	//for testing
	public static void main(String[] args) {
		new GameFrame(null);
	}
}
