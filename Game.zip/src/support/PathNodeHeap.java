package support;

import java.util.ArrayList;

public class PathNodeHeap {
	private ArrayList <PathNode> nodes;
	public PathNodeHeap() {
		nodes = new ArrayList<>();
	}
	public boolean isEmpty() {
		return nodes.isEmpty();
	}
	public void push(PathNode node) {
		int size = nodes.size();
		node.setIndexNumber(size);
		nodes.add(node);
		siftUp(size);
	}
	public PathNode pop() {
		if (nodes.size() == 1) {
			return nodes.remove(0);
		}
		else {
			PathNode popped = nodes.get(0);
			PathNode last = nodes.remove(nodes.size() - 1);
			nodes.set(0, last);
			last.setIndexNumber(0);
			siftDown(0);
			return popped;
		}
	}
	public void resift(PathNode node) {
		/**
		 * For when a node's info changes. We only expect nodes'
		 * distanceThrough values to decrease as we find better
		 * paths, so we only resift up.
		 */
		siftUp(node.getIndexNumber());
	}
	/**
	 * node i's children are (2i+1) and (2i+2)
	 * node i's parent is (i-1)/2
	 */
	private void siftUp(int i) {
		if (i == 0) {
			return;
		}
		PathNode node = nodes.get(i);
		PathNode parent = nodes.get((i - 1) / 2);
		if (node.getDistanceThrough() < parent.getDistanceThrough()) {
			set((i - 1) / 2, node);
			set(i, parent);
			siftUp((i - 1) / 2);
		}
	}
	private void siftDown(int i) {
		if (i + i + 1 >= nodes.size()) {
			return;
		}
		PathNode leastChild;
		if (i + i + 2 >= nodes.size()) {
			leastChild = nodes.get(i + i + 1);
		}
		else {
			PathNode child1 = nodes.get(i + i + 1);
			PathNode child2 = nodes.get(i + i + 2);
			if (child1.getDistanceThrough() < child2.getDistanceThrough()) {
				leastChild = child1;
			}
			else {
				leastChild = child2;
			}
		}
		int leastChildIndex = leastChild.getIndexNumber();
		PathNode node = nodes.get(i);
		if (leastChild.getDistanceThrough() < node.getDistanceThrough()) {
			//sift down
			set(leastChildIndex, node);
			set(i, leastChild);
			siftDown(leastChildIndex);
		}
	}
	private void set(int i, PathNode node) {
		nodes.set(i, node);
		node.setIndexNumber(i);
	}
}
