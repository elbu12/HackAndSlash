package support;

import solid.Solid;

public class Geometry {
	public static final double INVERSE_ROOT_2 = 1.0 / Math.sqrt(2);
	public static final double POINT_RADIUS = 0.0001;	//For rounding error
	/**
	 * Note: Shape intersection tests use "<" not "<=" for most comparisons
	 * This means two shapes can share an edge yet not intersect
	 */
	//Circles are defined by centers and radii
	public static boolean circleIntersectCircle(double c0x, double c0y, double c0r, double c1x, double c1y, double c1r) {
		double r = c0r + c1r;
		double dx = c0x - c1x;
		double dy = c0y - c1y;
		return (dx * dx) + (dy * dy) < r * r;
	}
	//Rectangles are defined by corners and width/height
	public static boolean rectangleIntersectRectangle(double r0x, double r0y, double r0w, double r0h,
			double r1x, double r1y, double r1w, double r1h) {
		double dx = (r0x + (r0w * 0.5)) - (r1x + (r1w * 0.5));
		double dy = (r0y + (r0h * 0.5)) - (r1y + (r1h * 0.5));
		double w = (r0w + r1w) * 0.5;
		double h = (r0h + r1h) * 0.5;
		return Math.abs(dx) < w && Math.abs(dy) < h;
	}
	//Check intersections at four sides and four corners
	public static boolean circleIntersectRectangle(double cx, double cy, double cr,
			double rx, double ry, double rw, double rh) {
		//check if rectangle contains circle
		if (rectangleIntersectPoint(rx, ry, rw, rh, cx, cy)) {
			return true;
		}
		else if (cx < rx) {
			//Circle left of rectangle
			double dx = cx - rx;
			if (cy < ry) {
				//Circle down and left of rectangle
				double dy = cy - ry;
				return (dx * dx) + (dy * dy) < cr * cr;
			}
			else if (cy > ry + rh) {
				//Circle up and left of rectangle
				double dy = cy - (ry + rh);
				return (dx * dx) + (dy * dy) < cr * cr;
			}
			else {
				//Circle directly left of rectangle
				return dx + cr > 0;
			}
		}
		else if (cx > rx + rw){
			//Circle right of rectangle
			double dx = cx - (rx + rw);
			if (cy < ry) {
				//Circle down and right of rectangle
				double dy = cy - ry;
				return (dx * dx) + (dy * dy) < cr * cr;
			}
			else if (cy > ry + rh) {
				//Circle up and right of rectangle
				double dy = cy - (ry + rh);
				return (dx * dx) + (dy * dy) < cr * cr;
			}
			else {
				//Circle directly right of rectangle
				return dx < cr;
			}
		}
		else {
			//Circle above/below rectangle
			double rc = ry + (rh * 0.5);
			return Math.abs(cy - rc) < cr + (rh * 0.5);
		}
	}
	public static boolean circleIntersectPoint(double cx, double cy, double cr, double px, double py) {
		double dx = cx - px;
		double dy = cy - py;
		return (dx * dx) + (dy * dy) < cr * cr;
	}
	public static boolean rectangleIntersectPoint(double rx, double ry, double rw, double rh, double px, double py) {
		return px >= rx && py >= ry && px < rx + rw && py < ry + rh;
	}
	public static boolean pointIntersectPoint(double p0x, double p0y, double p1x, double p1y) {
		return circleIntersectPoint(p0x, p0y, POINT_RADIUS, p1x, p1y);
	}
	public static boolean lineSegmentIntersectCircle(double lx, double ly, double dx, double dy,
			double cx, double cy, double cr) {
		/**
		 * Check the line segment ends. If neither of those intersect the circle,
		 * Find the point on the line closest to the circle and check if it intersects
		 * the circle.
		 */
		if (circleIntersectPoint(cx, cy, cr, lx, ly)) {
			return true;
		}
		if (circleIntersectPoint(cx, cy, cr, lx + dx, ly + dy)) {
			return true;
		}
		else {
			/**
			 * Distance^2 = ( (lx+tdx-cx)^2 + (ly+tdy-cy)^2 )
			 * Derivative = ( 2(lx+tdx-cx)dx + 2(ly+tdy-cy)dy )
			 * Derivative = 0 implies: t(dx^2 + dy^2) = dx(cx-lx) + dy(cy-ly)
			 */
			double t = ((dx * (cx-lx)) + (dy * (cy-ly))) / ((dx*dx) + (dy*dy));
			if (t < 0 || t > 1) {
				//Not on the line segment
				return false;
			}
			return circleIntersectPoint(cx, cy, cr, lx + (t * dx), ly + (t * dy));
		}
	}
	public static boolean lineSegmentIntersectRectangle(double lx, double ly, double dx, double dy,
			double rx, double ry, double rw, double rh) {
		//Is line segment inside rectangle?
		if (rectangleIntersectPoint(rx, ry, rw, rh, lx, ly)) {
			return true;
		}
		if (rectangleIntersectPoint(rx, ry, rw, rh, lx+dx, ly+dy)) {
			return true;
		}
		//Check for intersections with each edge
		if (dx == 0) {
			if (Math.min(ly, ly + dy) >= ry + rh) {
				//Too high
				return false;
			}
			else if (Math.max(ly, ly + dy) < ry) {
				//Too low
				return false;
			}
			//Check for horizontal alignment
			return lx >= rx && lx < rx + rw;
		}
		else if (dy == 0) {
			if (Math.min(lx, lx + dx) >= rx + rw) {
				//Too high
				return false;
			}
			else if (Math.max(lx, lx + dx) < rx) {
				//Too low
				return false;
			}
			//Check for vertical alignment
			return ly >= ry && ly < ry + rh;
		}
		else {
			//lx + tdx = rx
			double t = (rx - lx) / dx;
			double y = ly + (t * dy);
			if (t >= 0 && t <= 1 && y >= ry && y < ry + rh) {
				//intersection with left edge
				return true;
			}
			t = (rx + rw - lx) / dx;
			y = ly + (t * dy);
			if (t >= 0 && t <= 1 && y >= ry && y < ry + rh) {
				//intersection with right edge
				return true;
			}
			//ly + tdy = ry
			t = (ry - ly) / dy;
			double x = lx + (t * dx);
			if (t >= 0 && t <= 1 && x >= rx && x < rx + rw) {
				//intersection with bottom edge
				return true;
			}
			t = (ry + rh - ly) / dy;
			dx = lx + (t * dx);
			if (t >= 0 && t <= 1 && x >= rx && x < rx + rw) {
				//intersection with top edge
				return true;
			}
			return false;
		}
	}
	/**
	 * Line segment spans from (x0,y0) to (x0+dx0,y0+dy0)
	 * Line is (x1+tdx1,y1+tdy1) for all real t
	 */
	public static boolean lineSegmentIntersectLine(double x0, double y0, double dx0, double dy0,
		double x1, double y1, double dx1, double dy1){
		//Get vector perpendicular to line
		double px = dy1;
		double py = -dx1;
		//What vector goes from line to line segment?
		double dx2 = x0 - x1;
		double dy2 = y0 - y1;
		//On which side of the line is this?
		double sideDot0 = (px * dx2) + (py * dy2);
		//On which side is the line segment's other end?
		double dx3 = x0 + dx0 - x1;
		double dy3 = y0 + dy0 - y1;
		double sideDot1 = (px * dx3) + (py * dy3);
		if (sideDot0 == 0 || sideDot1 == 0) {
			//Line segment ends on line
			return true;
		}
		else {
			/**
			 * Tests have opposite values if line segment ends
			 * on opposite sides of line
			 */
			return (sideDot0 > 0) != (sideDot1 > 0);
		}
	}
	public static boolean lineSegmentIntersectPoint(double lx, double ly, double dx, double dy,
			double px, double py) {
		/**
		 * lx + tdx = px
		 * ly + tdy = py
		 */
		double t = (px - lx) / dx;
		if (Math.abs(ly + (t * dy) - py) > POINT_RADIUS) {
			//No intersection
			return false;
		}
		return t >= 0 && t <= 1;
	}
	public static boolean lineSegmentIntersectSolid(double lx, double ly, double dx, double dy,
			Solid solid) {
		switch (solid.getShape()) {
		case Solid.CIRCLE:
			return lineSegmentIntersectCircle(lx, ly, dx, dy, solid.getX(), solid.getY(), solid.getRadius());
		case Solid.RECTANGLE:
			return lineSegmentIntersectRectangle(lx, ly, dx, dy,
				solid.getX(), solid.getY(), solid.getWidth(), solid.getHeight());
		default:	//assume a point
			return lineSegmentIntersectPoint(lx, ly, dx, dy, solid.getX(), solid.getY());
		}
	}
	/**
	 * parallelogramIntersectSolid is used to determine if a particular solid
	 * will intersect the path taken by another solid moving along a straight
	 * line. The parallelogram represents the area traversed by the moving
	 * solid.
	 * 
	 * (x0,y0) is one corner of the parallelogram (presumably lower-left corner)
	 * (x1,y1) is another corner, presumably upper-left
	 * (dx,dy) points from each left corner to its corresponding right corner
	 */
	public static boolean parallelogramIntersectSolid(double x0, double y0,
			double x1, double y1, double dx, double dy, Solid solid) {
		//Is the solid inside the rectangle?
		double sdx = solid.getX() - x0;
		double sdy = solid.getY() - y0;
		//Which vector is perpendicular to the edge connecting (x0,y0) and (x1,y1)?
		double px = y1 - y0;
		double py = x0 - x1;
		if (dx < 0 != px < 0) {
			px = 0 - px;
			py = 0 - py;
		}
		if ((sdx * px) + (sdy * py) >= 0) {
			//Passes first edge test
			sdx = solid.getX() - (x0 + dx);
			sdy = solid.getY() - (y0 + dy);
			if ((sdx * px) + (sdy * py) <= 0) {
				//Inside second edge; now consider edge along (dx,dy) vector
				px = dy;
				py = -dx;
				if (y1 - y0 < 0 != py < 0) {
					px = 0 - px;
					py = 0 - py;
				}
				if ((sdx * px) + (sdy * py) >= 0) {
					//Inside third edge
					sdx = solid.getX() - x1;
					sdy = solid.getY() - y1;
					if ((sdx * px) + (sdy * py) <= 0){
						//Fully inside parallelogram
						return true;
					}
				}
			}
		}
		//Check for intersections with edges
		return lineSegmentIntersectSolid(x0, y0, x1 - x0, y1 - y0, solid) || 
				lineSegmentIntersectSolid(x0, y0, dx, dy, solid) || 
				lineSegmentIntersectSolid(x1, y1, dx, dy, solid) || 
				lineSegmentIntersectSolid(x0 + dx, y0 + dy, x1 - x0, y1 - y0, solid);
	}
	
	public static class Intersection{
		/**
		 * Represents the intersection of a line segment and a shape.
		 * If an intersection occurs, the boolean will be true and
		 * the double will represent how far down the line segment
		 * the intersection is.
		 * 
		 * If the line segment is represented as (x0+tdx, y0+tdy) then
		 * returning a double value of 0.4 means the intersection
		 * happens when t=0.4
		 */
		private boolean intersection;
		private double where;
		public Intersection(boolean intersection) {
			where = 0;
			this.intersection = intersection;
		}
		public void set(double where) {
			this.where = where;
			intersection = where >= 0 && where <= 1;
		}
		public void set(boolean intersection) {
			this.intersection = intersection;
		}
		public boolean isIntersection() {
			return intersection;
		}
		public double getWhere() {
			return where;
		}
	}
	//Determines where a line segment intersects a circle
	public static Intersection lineSegmentIntersectCircle(double lx, double ly, double dx, double dy,
			double cx, double cy, double cr, Intersection intersection) {
		if (circleIntersectPoint(cx, cy, cr, lx, ly)) {
			intersection.set(0);
		}
		else {
			/**
			 * Line segment enters circle from outside. Where?
			 * (lx+tdx-cx)^2 + (ly+tdy-cy)^2 = cr^2
			 * let lcx = lx - cx and lcy = ly - cy
			 * (lcx+tdx)^2 + (lcy+tdy)^2 = cr^2
			 * (tdx)^2 + (lcx)^2 + 2(lcx)(tdx) +
			 * (tdy)^2 + (lcy)^2 + 2(lcy)(tdy) = cr^2
			 * (dx^2+dy^2)(t^2) + 2(lcx(dx) + lcy(dy))t + lcx^2+lcy^2-cr^2 = 0
			 */
			double lcx = lx - cx;
			double lcy = ly - cy;
			double a = ((dx*dx) + (dy*dy));
			double b = 2*((dx*lcx) + (dy*lcy));
			double c = ((lcx*lcx) + (lcy*lcy) - (cr*cr));
			double rad = Math.sqrt((b*b) - (4 * a * c));
			if (Double.isNaN(rad)) {
				//Rounding error! Just give up
				intersection.set(false);
				return intersection;
			}
			double t0 = (-b - rad) / (2.0 * a);
			double t1 = (-b + rad) / (2.0 * a);
			if (t0 >= 0 && t0 <= 1) {
				if (t1 >= 0 && t1 <= 1) {
					intersection.set(Math.min(t0, t1));
				}
				else {
					intersection.set(t0);
				}
			}
			else if (t1 >= 0 && t1 <= 1) {
				intersection.set(1);
			}
			else {
				intersection.set(false);
			}
		}
		return intersection;
	}
	public static Intersection lineSegmentIntersectRectangle(double lx, double ly, double dx, double dy,
			double rx, double ry, double rw, double rh, Intersection intersection) {
		if (rectangleIntersectPoint(rx, ry, rw, rh, lx, ly)) {
			intersection.set(0);
		}
		else if (dx == 0){
			if (ly < ry) {
				if (ly + dy >= ry) {
					intersection.set((ry - ly) / dy);
				}
				else {
					intersection.set(false);
				}
			}
			else {
				if (ly + dy < ry + rh) {
					intersection.set((ry + rh - (ly + dy)) / dy);
				}
				else {
					intersection.set(false);
				}
			}
		}
		else if (dy == 0) {
			if (lx < rx) {
				if (lx + dx >= rx) {
					intersection.set((rx - lx) / dx);
				}
				else {
					intersection.set(false);
				}
			}
			else {
				if (lx + dx < rx + rw) {
					intersection.set((rx + rw - (lx + dx)) / dx);
				}
				else {
					intersection.set(false);
				}
			}
		}
		else {
			//Look for intersections with each side
			double t = Double.MAX_VALUE;
			double tempT = (rx - lx) / dx;
			double tempY = ly + (dy * tempT);
			if (tempY >= ry && tempY < ry + rh && tempT >= 0 && tempT <= 1) {
				t = tempT;
			}
			tempT = (rx + rw - lx) / dx;
			tempY = ly + (dy * tempT);
			if (tempY >= ry && tempY < ry + rh && tempT >= 0 && tempT <= 1 && tempT < t) {
				t = tempT;
			}
			tempT = (ry - ly) / dy;
			double tempX = lx + (dx * tempT);
			if (tempX >= rx && tempX < rx + rw && tempT >= 0 && tempT <= 1 && tempT < t) {
				t = tempT;
			}
			tempT = (ry + rh - ly) / dy;
			tempX = lx + (dx * tempT);
			if (tempX >= rx && tempX < rx + rw && tempT >= 0 && tempT <= 1 && tempT < t) {
				t = tempT;
			}
			if (t <= 1) {
				intersection.set(t);
			}
			else {
				intersection.set(false);
			}
		}
		return intersection;
	}
	public static Intersection lineSegmentIntersectPoint(double lx, double ly, double dx, double dy,
			double px, double py, Intersection intersection) {
		double t;
		if (dx == 0) {
			if (lx != px) {
				intersection.set(false);
			}
			else {
				t = (py - ly) / dy;
				if (t >= 0 && t <= 1) {
					intersection.set(t);
				}
				else {
					intersection.set(false);
				}
			}
		}
		else {
			t = (px - lx) / dx;
			if (t >= 0 && t <= 1 && Math.abs(ly + (t * dy) - py) <= POINT_RADIUS) {
				intersection.set(t);
			}
			else {
				intersection.set(false);
			}
		}
		return intersection;
	}
	public static Intersection lineSegmentIntersectSolid(double lx, double ly, double dx, double dy,
			Solid solid, Intersection intersection) {
		switch (solid.getShape()){
		case Solid.CIRCLE:
			intersection = lineSegmentIntersectCircle(lx, ly, dx, dy, 
					solid.getX(), solid.getY(), solid.getRadius(), intersection);
			break;
		case Solid.RECTANGLE:
			intersection = lineSegmentIntersectRectangle(lx, ly, dx, dy,
					solid.getX(), solid.getY(), solid.getWidth(), solid.getHeight(), intersection);
			break;
		default:	//assumed point
			intersection = lineSegmentIntersectPoint(lx, ly, dx, dy,
					solid.getX(), solid.getY(), intersection);
			break;
		}
		return intersection;
	}
	public static double getDistance(double x0, double y0, double x1, double y1) {
		double dx = x1 - x0;
		double dy = y1 - y0;
		return Math.sqrt((dx * dx) + (dy * dy));
	}
}
