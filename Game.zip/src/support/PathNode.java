package support;

public class PathNode {
	static final PathNode[] EMPTY_ARRAY = new PathNode[0];
	
	public final double x;
	public final double y;
	PathNode[] connected = null;
	/**
	 * distanceTo and distanceThrough are used for path finding via the A-Star
	 * algorithm. destinationX and Y are used to track if the distance
	 * variables are from this instance of path finding or left over from the
	 * previous instance.
	 * 
	 * Note that, as the nodes store their own data, we cannot do concurrent
	 * path finding to two distinct destinations via the same node map.
	 * 
	 * indexNumber represents this node's index number within the heap.
	 */
	private double distanceTo;
	private double distanceThrough;
	private double distanceFrom;
	private int indexNumber;
	private int pathFindingNumber;
	private PathNode parent;
	public PathNode(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public PathNode[] getConnected() {
		return (connected == null ? EMPTY_ARRAY : connected);
	}
	public double getDistanceTo() {
		return distanceTo;
	}
	//call setDistanceTo AFTER calling initialize
	public void setDistanceTo(double distanceTo) {
		this.distanceTo = distanceTo;
		distanceThrough = distanceTo + distanceFrom;
	}
	public double getDistanceThrough() {
		return distanceThrough;
	}
	public double getDistanceFrom() {
		return distanceFrom;
	}
	//call setDistanceTo AFTER calling initialize
	public void initialize(double destinationX, double destinationY, int pathFindingNumber) {
		distanceFrom = Geometry.getDistance(destinationX, destinationY, x, y);
		this.pathFindingNumber = pathFindingNumber;
	}
	int getIndexNumber() {
		return indexNumber;
	}
	void setIndexNumber(int indexNumber) {
		this.indexNumber = indexNumber;
	}
	public int getPathFindingNumber() {
		return pathFindingNumber;
	}
	public double getDistanceBetween(PathNode node) {
		return Geometry.getDistance(node.x, node.y, x, y);
	}
	public void setParent(PathNode parent) {
		this.parent = parent;
	}
	public PathNode getParent() {
		return parent;
	}
	public String toString() {
		return "PathNode at (" + x + ", " + y + ") connected to " +
		getConnected().length + " other nodes";
	}
}
