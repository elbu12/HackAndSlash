package support;

import solid.Solid;
import tile.Tile;
import tile.World;
/**
 * This represents a map of pathfinding nodes for a world.
 * They are particular to solids of the given radius and walkability.
 *
 */

public class NodeMap {
	//Represent a circle as a polygon
	public static final double[][] CIRCLE_CORNERS = new double[16][2];
	
	public final double solidRadius;
	public final boolean walks;
	private PathNode[][][] nodes;
	public PathNode[] getNodes(int x, int y) {
		if (x < 0 || y < 0 || x >= nodes.length || y >= nodes[x].length || nodes[x][y] == null) {
			return PathNode.EMPTY_ARRAY;
		}
		else {
			return nodes[x][y];
		}
	}
	public NodeMap(World world, Solid representative) {
		this.solidRadius = representative.getRadius();
		this.walks = representative.walks();
		nodes = new PathNode[world.width][world.height][];
		for (int i=0; i<world.width; i++) {
			nodes[i] = new PathNode[world.height][];
		}
		/**
		 * Initialize circle corners if not already done. Values represent
		 * points around the circle, to be scaled by an object's actual
		 * radius.
		 */
		if (CIRCLE_CORNERS[0][0] == 0 && CIRCLE_CORNERS[0][1] == 0) {
			initializeCircleCorners();
		}
		/**
		 * Go through the tiles and build nodes accordingly.
		 * First we add nodes for solids' corners
		 */
		for (int i=0; i<world.width; i++) {
			for (int j=0; j<world.height; j++) {
				Tile tile = world.get(i, j);
				if (tile.isObstruction()) {
					placeNodesAroundRectangle(world, representative, i, j, 1, 1);
				}
				for (Solid solid : tile.getSolids()) {
					if (solid == representative || solid.isMobile() || solid.getX() < tile.getX() || solid.getY() < tile.getY() ||
							solid.getX() >= tile.getX() + 1 || solid.getY() >= tile.getY() + 1) {
						//Do not navigate around mobile solids.
						//Solids only need to be processed once, so we wait
						//until we encounter them in the tile containing their center
						continue;
					}
					switch (solid.getShape()) {
					case Solid.CIRCLE:
						placeNodesAroundCircle(world, representative, solid.getX(), solid.getY(), solid.getRadius());
						break;
					case Solid.RECTANGLE:
						placeNodesAroundRectangle(world, representative, solid.getX(), solid.getY(),
								solid.getWidth(), solid.getHeight());
						break;
					}
				}
			}
		}
		//Empty tiles get central nodes
		for (int i=0; i<world.width; i++) {
			for (int j=0; j<world.height; j++) {
				PathNode[] arr = nodes[i][j];
				if (arr == null || arr.length == 0) {
					placeNodeIfSolidCanMove(world, representative, i+0.5, j+0.5);
				}
			}
		}
		//Test for connections between nodes
		for (int i=0; i<world.width; i++) {
			for (int j=0; j<world.height; j++) {
				PathNode[] arr0 = nodes[i][j];
				if (arr0 == null) {
					continue;
				}
				drawConnections(world, representative, arr0, arr0);
				if (i < world.width - 1) {
					//Look right
					PathNode[] arr1 = nodes[i + 1][j];
					drawConnections(world, representative, arr0, arr1);
					if (j < world.height - 1) {
						//Look down/right
						arr1 = nodes[i + 1][j + 1];
						drawConnections(world, representative, arr0, arr1);
					}
				}
				if (j < world.height - 1) {
					//Look down
					PathNode[] arr1 = nodes[i][j + 1];
					drawConnections(world, representative, arr0, arr1);
				}
			}
		}
	}
	private void placeNodesAroundRectangle(World world, Solid representative,
			double x, double y, double width, double height) {
		//TO DO: Do we place more nodes around the corners to allow one to circle around them?
		//Place nodes at corners and along edges
		double cx0 = x - (solidRadius + Geometry.POINT_RADIUS);
		double cx1 = x + (width + solidRadius + Geometry.POINT_RADIUS);
		double cy0 = y - (solidRadius + Geometry.POINT_RADIUS);
		double cy1 = y + (height + solidRadius + Geometry.POINT_RADIUS);
		placeNodeIfSolidCanMove(world, representative, cx0, cy0);
		placeNodeIfSolidCanMove(world, representative, cx1, cy0);
		placeNodeIfSolidCanMove(world, representative, cx0, cy1);
		placeNodeIfSolidCanMove(world, representative, cx1, cy1);
		//Do edges
		for (int i = 1 + (int)(cx0); i < (int)(cx1); i++) {
			double cx = i + 0.5;
			double cy = y - (solidRadius + Geometry.POINT_RADIUS);
			placeNodeIfSolidCanMove(world, representative, cx, cy);
			cy = y + height + solidRadius + Geometry.POINT_RADIUS;
			placeNodeIfSolidCanMove(world, representative, cx, cy);
		}
		for (int i = 1 + (int)(cy0); i < (int)(cy1); i++) {
			double cx = x - (solidRadius + Geometry.POINT_RADIUS);
			double cy = i + 0.5;
			placeNodeIfSolidCanMove(world, representative, cx, cy);
			cx = x + width + solidRadius + Geometry.POINT_RADIUS;
			placeNodeIfSolidCanMove(world, representative, cx, cy);
		}
	}
	private void placeNodesAroundCircle(World world, Solid representative,
			double x, double y, double radius) {
		//Try at each "corner"
		for (double[] pair : CIRCLE_CORNERS) {
			double cx = x + (pair[0] * (radius + solidRadius));
			double cy = y + (pair[1] * (radius + solidRadius));
			placeNodeIfSolidCanMove(world, representative, cx, cy);
		}
		
	}
	private void placeNodeIfSolidCanMove(World world, Solid representative, double x, double y) {
		if (world.canMove(representative, x, y, true)) {
			//Valid node
			PathNode[] arr = nodes[(int)(x)][(int)(y)];
			PathNode node = new PathNode(x, y);
			if (arr == null) {
				nodes[(int)(x)][(int)(y)] = new PathNode[] {node};
			}
			else {
				PathNode[] temp = new PathNode[arr.length + 1];
				System.arraycopy(arr, 0, temp, 0, arr.length);
				temp[temp.length - 1] = node;
				nodes[(int)(x)][(int)(y)] = temp;
			}
		}
	}
	private void drawConnections(World world, Solid representative, PathNode[] arr0, PathNode[] arr1) {
		if (arr0 == null) {
			return;
		}
		if (arr0 == arr1) {
			for (PathNode node0 : arr0) {
				for (PathNode node1 : arr0) {
					if (node0 == node1) {
						continue;
					}
					if (world.canMove(representative, node0.x, node0.y, node1.x - node0.x, node1.y - node0.y)) {
						drawConnection(node0, node1);
					}
				}
			}
		}
		else {
			if (arr1 == null) {
				return;
			}
			for (PathNode node0 : arr0) {
				for (PathNode node1 : arr1) {
					if (world.canMove(representative, node0.x, node0.y, node1.x - node0.x, node1.y - node0.y)) {
						drawConnection(node0, node1);
					}
				}
			}
		}
	}
	private void drawConnection(PathNode node0, PathNode node1) {
		PathNode[] con0 = node0.connected;
		PathNode[] con1 = node1.connected;
		if (con0 == null) {
			node0.connected = new PathNode[] {node1};
		}
		else {
			PathNode[] temp = new PathNode[con0.length + 1];
			System.arraycopy(con0, 0, temp, 0, con0.length);
			temp[temp.length - 1] = node1;
			node0.connected = temp;
		}
		if (con1 == null) {
			node1.connected = new PathNode[] {node0};
		}
		else {
			PathNode[] temp = new PathNode[con1.length + 1];
			System.arraycopy(con1, 0, temp, 0, con1.length);
			temp[temp.length - 1] = node0;
			node1.connected = temp;
		}
	}
	private static void initializeCircleCorners() {
		/**
		 * Need to scale this such that an object does not enter within
		 * the circle while moving between points
		 */
		double x1 = Math.cos(Math.PI * 2.0 / 16.0);
		double y1 = Math.sin(Math.PI * 2.0 / 16.0);
		//Find halfway point
		double x2 = (1 + x1) * 0.5;
		double y2 = (y1) * 0.5;
		//What is the distance?
		double d = Math.sqrt( (x2 * x2) + (y2 * y2) );
		for (int i=0; i<CIRCLE_CORNERS.length; i++) {
			double[] pair = CIRCLE_CORNERS[i];
			//Assume an angle of zero points up
			double angle = Math.PI * 2.0 * i / CIRCLE_CORNERS.length;
			double scalar = (1 + Geometry.POINT_RADIUS) / d;
			pair[0] = Math.sin(angle) * scalar;
			pair[1] = Math.cos(angle) * scalar;
		}
	}
	/**
	 * compareTo acts like subtraction.
	 * if (this.compareTo(r) == -1) then this precedes r
	 * if (this.compareTo(r) == 1) then this follows r
	 * if (this.compareTo(r) == 0) then this matches r
	 */
	public int compareTo(Solid representative) {
		double rad = representative.getRadius();
		if (rad < solidRadius) {
			return 1;
		}
		else if (rad > solidRadius) {
			return -1;
		}
		else {
			boolean w = representative.walks();
			if (w && !walks) {
				return 1;
			}
			else if (walks && !w) {
				return -1;
			}
			else {
				return 0;
			}
		}
	}
}
