package main;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import loot.Gold;
import loot.TriggeredInteraction;
import solid.ArmsDealer;
import solid.Player;
import solid.Solid;
import solid.Spider;
import solid.Wielder;
import tile.Dirt;
import tile.Stone;
import tile.Tile;
import tile.TiledFloor;
import tile.World;

/*
 * First, create the tiles. Solids are added to the list of solids.
 * Then this will iterate through the list to place the solids.
 */

public class WorldGenerator {
	public static final int NORTH = 0;
	public static final int EAST = 1;
	public static final int SOUTH = 2;
	public static final int WEST = 3;
	private List <Solid> solids = new ArrayList <> ();
	private List <TriggeredInteraction> interactions = new ArrayList <> ();
	private Tile[][] tiles;
	private Player player;
	public WorldGenerator(int width, int height) {
		tiles = new Tile[width][height];
		player = new Player();
		player.setXY(width * 0.5, height * 0.5);
		solids.add(player);
	}
	public void randomize() {
		createMerchantShop((tiles.length / 2) - 3, (tiles[0].length / 2) + 10, SOUTH,
				new String[] {Wielder.SHIELD, Wielder.BOW, Wielder.ARROW},
				new int[] {100, 100, 4},
				new int[] {60, 60, 3},
				new int[] {2, 2, 100},
				300);
		createSpiderDungeon((tiles.length / 2) + 11, (tiles[0].length / 2) - 30, 40, 40,
				new int[][] {new int[] {(tiles.length / 2) + 11, (tiles[0].length / 2) - 1}},
				100, 11);
	}
	public Player get() {
		//All unspecified tiles become dirt
		for (int i = 0; i < tiles.length; i++) {
			for (int j = 0; j < tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new Dirt(i, j);
				}
			}
		}
		World world = new World(tiles);
		for (Solid solid : solids) {
			world.moveIfCan(solid, solid.getX(), solid.getY());
		}
		for (TriggeredInteraction interaction : interactions) {
			world.place(interaction, interaction.getX(), interaction.getY());
		}
		return player;
	}
	/*
	 * Creates a 7x7 merchant shop with designated inventory.
	 * door can be NORTH, EAST, SOUTH, or WEST
	 */
	private static final Color DARK_GREEN = new Color(0, 150, 0);
	public void createMerchantShop(int x, int y, int door,
			String[] items, int[] buyPrices, int[] sellPrices,
			int[] inventory, int money) {
		for (int i=1; i<6; i++) {
			for (int j=1; j<6; j++) {
				tiles[x + i][y + j] = new TiledFloor(x + i, y + j);
			}
		}
		ArmsDealer merchant = new ArmsDealer(DARK_GREEN, Math.PI * 0.5 * door,
				player, items, buyPrices, sellPrices, inventory, money);
		switch (door) {
		case NORTH:
			for (int i=2; i<5; i++) {
				tiles[x + i][y + 6] = new TiledFloor(x + i, y + 6);
			}
			merchant.setXY(x + 3.5, y + 2);
			break;
		case EAST:
			for (int j=2; j<5; j++) {
				tiles[x + 6][y + j] = new TiledFloor(x + 6, y + j);
			}
			merchant.setXY(x + 2, y + 3.5);
			break;
		case SOUTH:
			for (int i=2; i<5; i++) {
				tiles[x + i][y] = new TiledFloor(x + i, y);
			}
			merchant.setXY(x + 3.5, y + 5);
			break;
		case WEST:
			for (int j=2; j<5; j++) {
				tiles[x][y + j] = new TiledFloor(x, y + j);
			}
			merchant.setXY(x + 5, y + 3.5);
			break;
		}
		solids.add(merchant);
		for (int i=0; i<7; i++) {
			if (tiles[x + i][y] == null) {
				tiles[x + i][y] = new Stone(x + i, y);
			}
			if (tiles[x + i][y + 6] == null) {
				tiles[x + i][y + 6] = new Stone(x + i, y + 6);
			}
		}
		for (int j=1; j<6; j++) {
			if (tiles[x][y + j] == null) {
				tiles[x][y + j] = new Stone(x, y + j);
			}
			if (tiles[x + 6][y + j] == null) {
				tiles[x + 6][y + j] = new Stone(x, y + j);
			}
		}
	}
	/*
	 * createCompoundBuilding creates a building consisting of multiple rooms.
	 * The dimensions specify the total size, including the walls.
	 * The int array specifies exits to the outside. It should consist of
	 * 2-element arrays, specifying x- and y-coordinates. If the array is empty,
	 * then the building will be impenetrable.
	 */
	public void createCompoundBuilding(int x, int y, int w, int h, int[][] exits) {
		final int defaultWidth = 8;
		final int defaultHeight = 8;
		if (x < 0 || x + w > tiles.length || y < 0 || y + h > tiles[0].length) {
			throw new RuntimeException("Trying to create compound building that extends beyond world limits.");
		}
		//Place outer walls
		for (int i=x; i < x + w; i++) {
			int j = y;
			if (!isNearExit(i, j, exits)) {
				tiles[i][j] = new Stone(i, j);
			}
			j = y + h - 1;
			if (!isNearExit(i, j, exits)) {
				tiles[i][j] = new Stone(i, j);
			}
		}
		for (int j=y; j < y + h; j++) {
			int i = x;
			if (!isNearExit(i, j, exits)) {
				tiles[i][j] = new Stone(i, j);
			}
			i = x + w - 1;
			if (!isNearExit(i, j, exits)) {
				tiles[i][j] = new Stone(i, j);
			}
		}
		/*
		 * Break up space into rooms that are each 8x8
		 * 7x7 space plus 1 unit for walls
		 * The remainder space goes into a random row or column
		 */
		class Room {
			int x;
			int y;
			int w;
			int h;
			int i;
			int j;
			int colWidth = 1;	//in terms of room blocks
			int rowHeight = 1;	//in terms of room blocks
			boolean uncombined = true;
			int connections = 0;
			public Room(int x, int y, int w, int h, int i, int j) {
				this.x = x;
				this.y = y;
				this.w = w;
				this.h = h;
				this.i = i;
				this.j = j;
			}
		}
		int width = w - 1;
		int height = h - 1;
		int extraW = width % defaultWidth;
		int extraH = height % defaultHeight;
		int bigColumn;
		int bigRow;
		Room[][] rooms = new Room[width / defaultWidth][height / defaultHeight];
		if (extraW > 0) {
			bigColumn = (int)(Math.random() * rooms.length);
		}
		else {
			bigColumn = Integer.MAX_VALUE;
		}
		if (extraH > 0) {
			bigRow = (int)(Math.random() * rooms[0].length);
		}
		else {
			bigRow = Integer.MAX_VALUE;
		}
		for (int i=0; i<rooms.length; i++) {
			for (int j=0; j<rooms[i].length; j++) {
				int roomx = x + (defaultWidth * i);
				int roomy = y + (defaultHeight * j);
				int roomw = defaultWidth;
				int roomh = defaultHeight;
				if (i == bigColumn) {
					//This column has the remainder width
					roomw += extraW;
				}
				else if (i > bigColumn) {
					roomx += extraW;
					//extra width already added, which pushes this over
				}
				if (j == bigRow) {
					//This row has the remainder height
					roomh += extraH;
				}
				else if (j > bigRow) {
					roomy += extraH;
					//extra height already added, which pushes this up
				}
				rooms[i][j] = new Room(roomx, roomy, roomw, roomh, i, j);
			}
		}
		//Try to combine rooms into larger ones
		for (int t = rooms.length * rooms[0].length / 2; t>0; t--) {
			int newWidth = 1 + (int)(Math.random() * 3);
			int newHeight;
			if (newWidth == 1) {
				newHeight = 2 + (int)(Math.random() * 2);
			}
			else {
				newHeight = 1 + (int)(Math.random() * 3);
			}
			int newx = (int)(Math.random() * (rooms.length + 1 - newWidth));
			int newy = (int)(Math.random() * (rooms[0].length + 1 - newHeight));
			//Only combine rooms that have not already been combined
			boolean uncombined = true;
			for (int i=newx; i<newx+newWidth; i++) {
				for (int j=newy; j<newy+newHeight; j++) {
					if (!rooms[i][j].uncombined) {
						uncombined = false;
						break;
					}
				}
				if (!uncombined) {
					break;
				}
			}
			if (uncombined) {
				Room newRoom = rooms[newx][newy];
				for (int i=newx; i<newx+newWidth; i++) {
					if (i > newx) {
						newRoom.w += rooms[i][newy].w;
					}
					for (int j=newy; j<newy+newHeight; j++) {
						if (i == newx && j > newy) {
							newRoom.h += rooms[i][j].h;
						}
						rooms[i][j] = newRoom;
					}
				}
				newRoom.uncombined = false;
				newRoom.rowHeight = newHeight;
				newRoom.colWidth = newWidth;
			}
		}
		class RoomConnection {
			/*
			 * Represents a possible connection between two rooms.
			 * verticalBarrier determines whether the wall between them
			 * is vertical.
			 * 
			 * Room1 is always the one with lesser x/y value.
			 */
			final Room room1;
			final Room room2;
			final boolean verticalBarrier;
			final int barrierStart;
			final int barrierLength;
			public RoomConnection(Room room1, Room room2, boolean verticalBarrier, int barrierStart,
					int barrierLength) {
				super();
				this.room1 = room1;
				this.room2 = room2;
				this.verticalBarrier = verticalBarrier;
				this.barrierStart = barrierStart;
				this.barrierLength = barrierLength;
			}
		}
		//Make a list of possible connections
		List <RoomConnection> connectionList = new ArrayList <> ();
		connectionList.add(new RoomConnection(null, rooms[0][0], true, 0, 0));
		//Track which rooms have already been processed
		boolean[][] roomsProcessed = new boolean[tiles.length][tiles[0].length];
		while (!connectionList.isEmpty()) {
			//Pick a random possible connection
			int r = (int)(Math.random() * connectionList.size());
			RoomConnection con;
			if (r == connectionList.size() - 1) {
				con = connectionList.remove(r);
			}
			else {
				con = connectionList.get(r);
				connectionList.set(r, connectionList.remove(connectionList.size() - 1));
			}
			/*
			 * If the second room already connects to something, then possibly
			 * create this connection. If not, definitely apply it.
			 */
			Room room2 = con.room2;
			Room room1 = con.room1;
			if (room1 != null) {
				//Build a wall between these rooms, possibly with a door
				int door;
				//Here we determine whether a door is created.
				//This also determines how many cycles the graph gets
				//TESTING
				if (room2.connections == 0 || Math.random() < 0.25) {
					door = con.barrierStart + (con.barrierLength / 2);
					room1.connections++;
					room2.connections++;
				}
				else {
					door = -99;
				}
				for (int k=con.barrierStart; k<con.barrierStart+con.barrierLength; k++) {
					int tilex;
					int tiley;
					if (con.verticalBarrier) {
						tilex = Math.max(con.room2.x, con.room1.x);
						tiley = k;
					}
					else {
						tilex = k;
						tiley = Math.max(con.room1.y, con.room2.y);
					}
					if (tilex > x && tilex < x + w - 1 && tiley > y && tiley < y + h - 1) {
						Tile newTile;
						if (Math.abs(k - door) < 2) {
							newTile = new TiledFloor(tilex, tiley);
						}
						else {
							newTile = new Stone(tilex, tiley);
						}
						tiles[tilex][tiley] = newTile;
					}
				}
			}
			if (!roomsProcessed[room2.i][room2.j]) {
				roomsProcessed[room2.i][room2.j] = true;
				//Consider potential connections to other adjacent rooms
				//Right edge
				int i = room2.i + room2.colWidth - 1;
				int j = room2.j;
				if (i < rooms.length - 1) {
					while (j < rooms[i].length && rooms[i][j] == room2) {
						//What room is just right of this?
						Room adj = rooms[i+1][j];
						if (!roomsProcessed[adj.i][adj.j]) {
							int barrierStart = Math.max(room2.y, adj.y);
							int barrierLength = Math.min(room2.y + room2.h, adj.y + adj.h) - barrierStart;
							connectionList.add(new RoomConnection(room2, adj, true, barrierStart, barrierLength));
						}
						//What is the next distinct room, going up, on the right edge?
						j = adj.j + adj.rowHeight;
					}
				}
				//Left edge
				i = room2.i;
				j = room2.j;
				if (i > 0) {
					while (j < rooms[i].length && rooms[i][j] == room2) {
						//What room is just left of this?
						Room adj = rooms[i-1][j];
						if (!roomsProcessed[adj.i][adj.j]) {
							int barrierStart = Math.max(room2.y, adj.y);
							int barrierLength = Math.min(room2.y + room2.h, adj.y + adj.h) - barrierStart;
							connectionList.add(new RoomConnection(room2, adj, true, barrierStart, barrierLength));
						}
						//What is the next distinct room, going up, on the left edge?
						j = adj.j + adj.rowHeight;
					}
				}
				//Upper edge
				i = room2.i;
				j = room2.j + room2.rowHeight - 1;
				if (j < rooms[i].length - 1) {
					while (i < rooms.length && rooms[i][j] == room2) {
						//What room is just above this?
						Room adj = rooms[i][j+1];
						if (!roomsProcessed[adj.i][adj.j]) {
							int barrierStart = Math.max(room2.x, adj.x);
							int barrierLength = Math.min(room2.x + room2.w, adj.x + adj.w) - barrierStart;
							connectionList.add(new RoomConnection(room2, adj, false, barrierStart, barrierLength));
						}
						//What is the next distinct room, going right, on the top edge?
						i = adj.i + adj.colWidth;
					}
				}
				//Lower edge
				i = room2.i;
				j = room2.j;
				if (j > 0) {
					while (i < rooms.length && rooms[i][j] == room2) {
						//What room is just below this?
						Room adj = rooms[i][j-1];
						if (!roomsProcessed[adj.i][adj.j]) {
							int barrierStart = Math.max(room2.x, adj.x);
							int barrierLength = Math.min(room2.x + room2.w, adj.x + adj.w) - barrierStart;
							connectionList.add(new RoomConnection(room2, adj, false, barrierStart, barrierLength));
						}
						//What is the next distinct room, going right, on the bottom edge?
						i = adj.i + adj.colWidth;
					}
				}
			}
		}
		//Finally, remaining tiles become tiled floor
		for (int i=x; i<x+w; i++) {
			for (int j=y; j<y+h; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new TiledFloor(i, j);
				}
			}
		}
	}
	private boolean isNearExit(int x, int y, int[][] exits) {
		for (int[] exit : exits) {
			if (Math.abs(x - exit[0]) < 2 && Math.abs(y - exit[1]) < 2) {
				return true;
			}
		}
		return false;
	}
	/*
	 * createSpiderDungeon creates a compound building with gold loot and spiders.
	 * Will not place gold if gold <= 0. Will not place spiders if spiders <= 0.
	 */
	private void createSpiderDungeon(int x, int y, int w, int h, int[][] exits, int gold, int spiders) {
		createCompoundBuilding(x,y, w, h, exits);
		//Get a list of 2x2 squares that might contain something
		Tile2x2Provider provider = new Tile2x2Provider(tiles, x + 1, y + 1, w - 2, h - 2);
		while ((gold > 0 || spiders > 0)) {
			//Get the next spot
			Tile tile = provider.getRandom();
			if (tile == null) {
				//Nowhere left to place anything
				return;
			}
			if (gold > 0) {
				Gold loot = new Gold(gold);
				//Place somewhere in 2x2 square
				loot.setX(tile.getX() + 0.5 + Math.random());
				loot.setY(tile.getY() + 0.5 + Math.random());
				interactions.add(loot);
				gold = 0;
			}
			else {
				Spider spider = new Spider(player, Math.random() * Math.PI * 2.0);
				//Place in center of 2x2 square
				spider.setXY(tile.getX() + 1, tile.getY() + 1);
				solids.add(spider);
				spiders--;
			}
		}
	}
	/*
	 * The TileProvider class is used for randomly placing objects.
	 * Given a 2-D tile array, it will generate a list and 2-D array
	 * representing unoccupied 2x2 squares where something could be
	 * placed. Calling getRandom() will return a random tile, representing
	 * the lower-left tile in a 2x2 square. This tile is then removed from
	 * the list, preventing the same square from being returned twice.
	 * 
	 * Note that x, y, w, and h should represent the corner, width, and
	 * height of the actual space where you want things placed. If this
	 * corresponds with a building, x and y should not be the building's
	 * corner, because that is guaranteed to be a wall.
	 */
	private static class Tile2x2Provider{
		boolean[][] arr;
		List <Tile> list;
		final int x;
		final int y;
		private Tile2x2Provider(Tile[][] tiles, int x, int y, int w, int h) {
			this.x = x;
			this.y = y;
			arr = new boolean[w][h];
			list = new ArrayList <> ();
			for (int i=x; i<x+w; i++) {
				for (int j=y; j<y+h; j++) {
					boolean canPlace = true;
					for (int dx = 0; dx < 2 && canPlace; dx++) {
						for (int dy = 0; dy < 2; dy ++) {
							Tile tile = tiles[i + dx][j + dy];
							if (!tile.isWalkable()) {
								//Cannot place here
								canPlace = false;
								break;
							}
						}
					}
					if (canPlace) {
						arr[i - x][j - y] = true;
						list.add(tiles[i][j]);
					}
				}
			}
		}
		private Tile getRandom() {
			while (!list.isEmpty()) {
				//Pick a random spot
				int r = (int)(Math.random() * list.size());
				Tile tile;
				if (r == list.size() - 1) {
					tile = list.remove(r);
				}
				else {
					tile = list.get(r);
					list.set(r, list.remove(list.size() - 1));
				}
				//Can we place something here, or was it already invalidated?
				int arrx = tile.getX() - x;
				int arry = tile.getY() - y;
				if (!arr[arrx][arry]) {
					//Already invalidated. Try again.
					continue;
				}
				//If not invalidated, we will return it
				//But first, invalidate it
				arr[arrx][arry] = false;
				if (arrx + 1 < arr.length) {
					arr[arrx + 1][arry] = false;
					if (arry + 1 < arr[arrx].length) {
						arr[arrx + 1][arry + 1] = false;
					}
				}
				if (arry + 1 < arr[arrx].length) {
					arr[arrx][arry + 1] = false;
				}
				return tile;
			}
			return null;
		}
	}
}
