package commerce;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import main.Game;
import solid.Player;

public abstract class Merchant {
	/**
	 * Merchants buy and sell items.
	 * They are matched by index number.
	 * A buy/sell price of Integer.MIN_VALUE designates
	 * something cannot be bought/sold.
	 */
	private String name;
	private String[] items;
	private int[] buyPrices;
	private int[] sellPrices;
	private int[] inventory;
	private int money;
	private JFrame shopInterface;
	
	/**
	 * tradeButtons refers to the buttons and labels used for buying
	 * and selling. If an item can be bought/sold, it will display a
	 * corresponding button with a price. If the item is temporarily
	 * sold out/unbuyable, the button will be deactivated. If the
	 * item can never be bought/sold at that merchant, it will have
	 * a label saying as much.
	 * 
	 * The first element in a subarray is for buying
	 */
	private TradeButton[][] tradeButtons;
	private JLabel playerMoneyLabel;
	private JLabel[] playerInventory;
	
	public Merchant(String name, String[] items, int[] buyPrices, int[] sellPrices, int[] inventory, int money) {
		this.name = name;
		this.items = items;
		this.buyPrices = buyPrices;
		this.sellPrices = sellPrices;
		this.inventory = inventory;
		this.money = money;
		shopInterface = null;
		tradeButtons = null;
		playerMoneyLabel = null;
		playerInventory = null;
	}
	public String getName() {
		return name;
	}
	public String[] getItems() {
		return items;
	}
	public int getPrice(int index, boolean buy) {
		if (buy) {
			return buyPrices[index];
		}
		else {
			return sellPrices[index];
		}
	}
	public int getInventory(int index) {
		return inventory[index];
	}
	public int getMoney() {
		return money;
	}
	//This method should go back to the regular dialog screen
	public abstract void closeShopInterface();
	
	//Returns whether the trade was successful
	public boolean trade(Player player, int index, boolean buy) {
		Integer oldPlayerInventory = player.getInventory().getOrDefault(items[index], 0);		
		if (buy) {
			if (buyPrices[index] == Integer.MIN_VALUE || inventory[index] < 1 ||
					player.getMoney() < buyPrices[index]) {
				return false;
			}
			else {
				inventory[index]--;
				money += buyPrices[index];
				player.getInventory().put(items[index], oldPlayerInventory + 1);
				player.changeMoney(-buyPrices[index]);
			}
		}
		else {
			if (sellPrices[index] == Integer.MIN_VALUE || money < sellPrices[index] ||
					oldPlayerInventory < 1 || (oldPlayerInventory == 1 && player.isEquipped(items[index]))) {
				return false;
			}
			else {
				inventory[index]++;
				money -= sellPrices[index];
				player.getInventory().put(items[index], oldPlayerInventory - 1);
				player.changeMoney(sellPrices[index]);
			}
		}
		return true;
	}
	public void createShopInterface(Game game) {
		game.pause();
		game.incrementDialogFramesOpen();
		game.hideDialogFrame();
		if (shopInterface == null) {
			shopInterface = new JFrame(name);
			shopInterface.setLayout(new GridBagLayout());
			GridBagConstraints gbc = new GridBagConstraints();
			shopInterface.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			gbc.gridx = 0;
			gbc.gridy = 0;
			gbc.gridwidth = 4;
			playerMoneyLabel = new JLabel();
			shopInterface.add(playerMoneyLabel, gbc);
			gbc.gridy++;
			gbc.gridwidth = 1;
			tradeButtons = new TradeButton[items.length][2];
			playerInventory = new JLabel[items.length];
			for (int i=0; i<items.length; i++) {
				String item = items[i];
				JLabel itemLabel = new JLabel(item);
				shopInterface.add(itemLabel, gbc);
				gbc.gridx++;
				if (buyPrices[i] == Integer.MIN_VALUE) {
					shopInterface.add(new JLabel("(Not for sale)"), gbc);
				}
				else {
					TradeButton buyButton = new TradeButton(i, true, game);
					shopInterface.add(buyButton, gbc);
					tradeButtons[i][0] = buyButton;
				}
				gbc.gridx++;
				if (sellPrices[i] == Integer.MIN_VALUE) {
					shopInterface.add(new JLabel("(Cannot be sold here)"), gbc);
				}
				else {
					TradeButton sellButton = new TradeButton(i, false, game);
					shopInterface.add(sellButton, gbc);
					tradeButtons[i][1] = sellButton;
				}
				gbc.gridx++;
				playerInventory[i] = new JLabel();
				shopInterface.add(playerInventory[i], gbc);
				gbc.gridy++;
				gbc.gridx = 0;
			}
			gbc.gridwidth = 4;
			CloseButton closeButton = new CloseButton(game);
			shopInterface.add(closeButton, gbc);
			shopInterface.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		}
		refresh(game);
		shopInterface.setVisible(true);
	}
	private void refresh(Game game) {
		Player player = game.getPlayer();
		for (int i=0; i<tradeButtons.length; i++) {
			TradeButton[] buttons = tradeButtons[i];
			TradeButton button = buttons[0];
			if (button != null) {
				if (inventory[i] == 0) {
					button.setText("(Sold out)");
					button.setEnabled(false);
				}
				else if (game.getPlayer().getMoney() < buyPrices[i]) {
					button.setText("(Price is " + buyPrices[i] + ")");
					button.setEnabled(false);
				}
				else {
					button.setText("Buy for " + buyPrices[i]);
					button.setEnabled(true);
				}
			}
			button = buttons[1];
			if (button != null) {
				Integer playerInventory = player.getInventory().get(items[i]);
				if (playerInventory == null) {
					playerInventory = 0;
				}
				if (playerInventory < 1) {
					button.setText("(You have none to sell)");
					button.setEnabled(false);
				}
				else if (playerInventory == 1 && player.isEquipped(items[i])) {
					button.setText("(You cannot sell equipped items)");
					button.setEnabled(false);
				}
				else if (money >= sellPrices[i]) {
					button.setText("Sell for " + sellPrices[i]);
					button.setEnabled(true);
				}
				else {
					button.setText("(Not accepting more)");
					button.setEnabled(false);
				}
			}
			playerInventory[i].setText("(You have " + player.getInventory().getOrDefault(items[i], 0) + ")");
		}
		playerMoneyLabel.setText("Your money: " + player.getMoney());
	}
	private class CloseButton extends JButton implements ActionListener{
		private static final long serialVersionUID = 1L;
		private Game game;
		private CloseButton(Game game) {
			super("Close");
			this.game = game;
			addActionListener(this);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			shopInterface.setVisible(false);
			game.decrementDialogFramesOpen();
			closeShopInterface();
		}
	}
	private class TradeButton extends JButton implements ActionListener {
		private static final long serialVersionUID = 1L;
		private Game game;
		private final int index;
		private final boolean buy;
		private TradeButton(int index, boolean buy, Game game) {
			super("");
			this.index = index;
			this.buy = buy;
			this.game = game;
			addActionListener(this);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			if (trade(game.getPlayer(), index, buy)) {
				refresh(game);
			}
		}
	}
}
