package commerce;

public class DefaultMerchant extends Merchant{
	public DefaultMerchant(String name, String[] items, int[] buyPrices, int[] sellPrices, int[] inventory, int money) {
		super(name, items, buyPrices, sellPrices, inventory, money);
	}
	@Override
	public void closeShopInterface() {}
}
