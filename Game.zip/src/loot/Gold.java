package loot;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import solid.Solid;

public class Gold extends TriggeredInteraction{
	private int amount;
	private BufferedImage img;
	
	public Gold(int amount) {
		this.amount = amount;
		img = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = img.createGraphics();
		for (int i=0; i<40; i++) {
			int shade = 125 + (int)(Math.random() * 125);
			g.setColor(new Color(
					shade, shade, 0));
			double r = 20 * Math.sqrt(Math.random());
			double a = Math.random() * Math.PI * 2.0;
			g.fillOval(25 + (int)(r * Math.cos(a)), 25 + (int)(r * Math.sin(a)), 10, 10);
		}
		g.dispose();
	}
	
	public void interact() {
		getGame().getPlayer().changeMoney(amount);
		super.interact();
	}

	@Override
	public int getShape() {
		return Solid.CIRCLE;
	}

	@Override
	public double getWidth() {
		return 0;
	}

	@Override
	public double getHeight() {
		return 0;
	}

	@Override
	public double getRadius() {
		return 0.5;
	}
	
	@Override
	public BufferedImage getImage() {
		return img;
	}

}
