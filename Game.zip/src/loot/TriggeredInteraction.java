package loot;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import main.Game;
import tile.Tile;

public abstract class TriggeredInteraction {
	private double x;
	private double y;
	public abstract int getShape();
	private List <Tile> tiles = new ArrayList <> ();
	private Game game = null;
	public final double getX() {
		return x;
	}
	public final void setX(double x) {
		this.x = x;
	}
	public final double getY() {
		return y;
	}
	public final void setY(double y) {
		this.y = y;
	}
	public abstract double getWidth();
	public abstract double getHeight();
	public abstract double getRadius();
	public void interact() {
		if (tiles == null) {
			throw new RuntimeException("Triggered interaction occurring with null tiles.");
		}
		for (Tile tile : tiles) {
			tile.remove(this);
		}
		tiles = null;
	}
	public double getDirection() {
		return 0;
	}
	public void add(Tile tile) {
		Game game = tile.getWorld().getGame();
		if (game != null) {
			this.game = game;
		}
		tiles.add(tile);
	}
	public BufferedImage getImage() {
		return null;
	}
	protected Game getGame() {
		if (game == null) {
			for (Tile tile : tiles) {
				Game game = tile.getWorld().getGame();
				if (game != null) {
					this.game = game;
					break;
				}
			}
		}
		return game;
	}
}
