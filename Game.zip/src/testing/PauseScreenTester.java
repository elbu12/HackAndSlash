package testing;

import java.util.Map;

import main.Game;
import solid.Player;
import solid.Wielder;
import tile.Dirt;
import tile.Tile;
import tile.World;

public class PauseScreenTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[1][1];
		tiles[0][0] = new Dirt(0,0);
		World world = new World(tiles);
		Player player = new Player(0.5, 1);
		Map<String, Integer> inventory = player.getInventory();
		inventory.put("Three", 3);
		inventory.put("Two", 2);
		inventory.put(Wielder.SWORD, 1);
		inventory.put("Zero", 0);
		world.moveIfCan(player, 0.5, 0.5);
		Game game = new Game(player);
		game.createPauseFrame();
	}
}
