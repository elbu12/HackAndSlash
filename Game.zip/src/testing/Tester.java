package testing;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;

import commerce.Merchant;
import loot.TriggeredInteraction;
import main.WorldGenerator;
import solid.Arrow;
import solid.CircularSolid;
import solid.Player;
import solid.RectangularSolid;
import solid.Solid;
import solid.SolidActor;
import solid.TileSolid;
import solid.Wielder;
import support.Geometry;
import support.Geometry.Intersection;
import support.NodeMap;
import support.PathNode;
import support.PathNodeHeap;
import tile.Dirt;
import tile.Land;
import tile.Stone;
import tile.Tile;
import tile.TiledFloor;
import tile.Water;
import tile.World;

public class Tester {
	/**
	 * Automated testing class.
	 * 
	 * Tests should be written as static methods with return-type of string.
	 * If a test returns null, it passed. If it returns a string, the string
	 * is interpreted to be a failure message.
	 */
	@SuppressWarnings("rawtypes")
	public static final Class[] NO_CLASSES = new Class[0];
	public static final Object[] NO_ARGS = new Object[0];
	public static void main(String[] args) {
		//Write tests here
		String[] tests = new String []{
			"circleCircle",
			"rectangleRectangle",
			"circleRectangle",
			"intersectedTilesStill",
			"lineSegmentCircle",
			"lineSegmentRectangle",
			"lineSegmentPoint",
			"lineSegmentLine",
			"firstSolidHit",
			"canMove",
			"moveIfCan",
			"parallelogramSolid",
			"canMoveLinearly",
			"nodeMap",
			"getNodeMap",
			"pathNodeHeap",
			"setPath",
			"merchant",
			"projectile",
			"triggeredInteraction",
			"shieldBug",
			"compoundBuilding",
			"imageCaching"
		};
		for (String test : tests) {
			try {
				Method method = Tester.class.getDeclaredMethod(test, NO_CLASSES);
				Object result = method.invoke(null, NO_ARGS);
				if (result != null) {
					System.out.println(test + " failed: " + result);
				}
				else {
					System.out.println("Pass: "+ test);
				}
			} catch (NoSuchMethodException e) {
				System.out.println("No such test: " + test);
			} catch (SecurityException e) {
				System.out.println("Error with " + test + ": " + e.getMessage());
			} catch (IllegalAccessException e) {
				System.out.println("Error with " + test + ": " + e.getMessage());
			} catch (IllegalArgumentException e) {
				System.out.println("Error with " + test + ": " + e.getMessage());
			} catch (InvocationTargetException e) {
				System.out.println("Error with " + test + ": " + e.getMessage());
				e.printStackTrace();
			}
		}
	}
	public static String circleCircle() {
		double[][] c = new double[][] {
				new double[] {1, 1, 2},
				new double[] {4, 5, 2}
		};
		if (Geometry.circleIntersectCircle(c[0][0], c[0][1], c[0][2], c[1][0], c[1][1], c[1][2])) {
			return "Expected no intersection but got one: " + Arrays.toString(c);
		}
		c[0][2] = 3;
		if (Geometry.circleIntersectCircle(c[0][0], c[0][1], c[0][2], c[1][0], c[1][1], c[1][2])) {
			return "Expected no intersection but got one: " + Arrays.toString(c);
		}
		c[1][2] = 2.001;
		if (!Geometry.circleIntersectCircle(c[0][0], c[0][1], c[0][2], c[1][0], c[1][1], c[1][2])) {
			return "Expected an intersection but got none: " + Arrays.toString(c);
		}
		c[1][2] = 30;
		if (!Geometry.circleIntersectCircle(c[0][0], c[0][1], c[0][2], c[1][0], c[1][1], c[1][2])) {
			return "Expected an intersection but got none: " + Arrays.toString(c);
		}
		return null;
	}
	public static String rectangleRectangle() {
		if (!Geometry.rectangleIntersectRectangle(0, 0, 1, 2, 0, 0, 1, 2)) {
			return "Expected an intersection but got none: identical rectangles";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, 1, 0, 1, 2)) {
			return "Expected no intersection but got one: side-by-side (1)";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, -1, 0, 1, 2)) {
			return "Expected no intersection but got one: side-by-side (2)";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, 0, 2, 1, 2)) {
			return "Expected no intersection but got one: below/above";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, 0, -2, 1, 2)) {
			return "Expected no intersection but got one: above/below";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, -1, -2, 1, 2)) {
			return "Expected no intersection but got one: corner (1)";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, 1, -2, 1, 2)) {
			return "Expected no intersection but got one: corner (2)";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, -1, 2, 1, 2)) {
			return "Expected no intersection but got one: corner (3)";
		}
		if (Geometry.rectangleIntersectRectangle(0, 0, 1, 2, 1, 2, 1, 2)) {
			return "Expected no intersection but got one: corner (4)";
		}
		return null;
	}
	public static String circleRectangle() {
		double[][] s = new double[][] {
			new double[] {0, 0, 1, 2},
			new double[] {5, 5}
		};
		double[] r = new double[] {4, 5, 5.001, 10};
		for (int i=0; i<r.length; i++) {
			boolean exptd = i > 1;
			boolean result = Geometry.circleIntersectRectangle(s[1][0], s[1][1], r[i],
					s[0][0], s[0][1], s[0][2], s[0][3]);
			if (exptd != result) {
				if (exptd) {
					return "Expected an intersection but got none: " + Arrays.toString(s);
				}
				else {
					return "Expected no intersection but got one: " + Arrays.toString(s);
				}
			}
		}
		s[1][1] = -3;
		for (int i=0; i<r.length; i++) {
			boolean exptd = i > 1;
			boolean result = Geometry.circleIntersectRectangle(s[1][0], s[1][1], r[i],
					s[0][0], s[0][1], s[0][2], s[0][3]);
			if (exptd != result) {
				if (exptd) {
					return "Expected an intersection but got none: " + Arrays.toString(s);
				}
				else {
					return "Expected no intersection but got one: " + Arrays.toString(s);
				}
			}
		}
		s[1][0] = -4;
		for (int i=0; i<r.length; i++) {
			boolean exptd = i > 1;
			boolean result = Geometry.circleIntersectRectangle(s[1][0], s[1][1], r[i],
					s[0][0], s[0][1], s[0][2], s[0][3]);
			if (exptd != result) {
				if (exptd) {
					return "Expected an intersection but got none: " + Arrays.toString(s);
				}
				else {
					return "Expected no intersection but got one: " + Arrays.toString(s);
				}
			}
		}
		s[1][1] = 5;
		for (int i=0; i<r.length; i++) {
			boolean exptd = i > 1;
			boolean result = Geometry.circleIntersectRectangle(s[1][0], s[1][1], r[i],
					s[0][0], s[0][1], s[0][2], s[0][3]);
			if (exptd != result) {
				if (exptd) {
					return "Expected an intersection but got none: " + Arrays.toString(s);
				}
				else {
					return "Expected no intersection but got one: " + Arrays.toString(s);
				}
			}
		}
		return null;
	}
	public static String intersectedTilesStill() {
		Tile[][] tiles = new Tile[3][3];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		World world = new World(tiles);
		Solid solid = new RectangularSolid(0.5, 0.5, 1, 1);
		List <Tile> intersectedTiles = solid.getIntersectedTiles(solid.getX(), solid.getY(), world);
		if (intersectedTiles.size() != 4) {
			return "Intersected wrong number of tiles. Should be 4 but is instead " + intersectedTiles.size();
		}
		Tile tile = tiles[0][0];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[0][1];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[1][0];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[1][1];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		solid.setX(1);
		solid.setY(1);
		intersectedTiles = solid.getIntersectedTiles(solid.getX(), solid.getY(), world, intersectedTiles);
		if (intersectedTiles.size() != 1) {
			return "Intersected wrong number of tiles. Should be 1 but is instead " + intersectedTiles.size();
		}
		tile = tiles[1][1];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		solid = new CircularSolid(1.5, 1.5, 0.6);
		intersectedTiles = solid.getIntersectedTiles(solid.getX(), solid.getY(), world, intersectedTiles);
		if (intersectedTiles.size() != 5) {
			return "Intersected wrong number of tiles. Should be 1 but is instead " + intersectedTiles.size();
		}
		tile = tiles[1][1];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[0][1];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[1][0];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[2][1];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		tile = tiles[1][2];
		if (!intersectedTiles.contains(tile)) {
			return "Does not contain tile " + tile;
		}
		return null;
	}
	public static String lineSegmentCircle() {
		if (!Geometry.lineSegmentIntersectCircle(0.9, 0.9, -10, -10, 1, 1, 1)) {
			return "Found no intersection, despite line segment starting in circle";
		}
		if (!Geometry.lineSegmentIntersectCircle(10, 10, -9.1, -9.1, 1, 1, 1)) {
			return "Found no intersection, despite line segment ending in circle";
		}
		if (!Geometry.lineSegmentIntersectCircle(0.9, 0.9, 0.2, 0, 1, 1, 1)) {
			return "Found no intersection, despite line segment entirely in circle";
		}
		if (Geometry.lineSegmentIntersectCircle(1, 2.42, 1.42, -1.42, 1, 1, 1)) {
			return "Expected no intersection but found one";
		}
		if (!Geometry.lineSegmentIntersectCircle(1, 2.41, 1.42, -1.42, 1, 1, 1)) {
			return "Expected an intersection but found none";
		}
		return null;
	}
	public static String lineSegmentRectangle() {
		if (!Geometry.lineSegmentIntersectRectangle(1, 1, 1000, 1000, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment starting in rectangle";
		}
		if (!Geometry.lineSegmentIntersectRectangle(1000, 1000, -999, -999, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment ending in rectangle";
		}
		if (!Geometry.lineSegmentIntersectRectangle(-8, 0.2, 100, 0.6, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment going through rectangle, left-to-right";
		}
		if (!Geometry.lineSegmentIntersectRectangle(0.2, -8, 0.6, 100, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment going upward through rectangle";
		}
		if (!Geometry.lineSegmentIntersectRectangle(-0.9, 0.9, 2, 2, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment going through rectangle's upper left corner";
		}
		if (!Geometry.lineSegmentIntersectRectangle(-0.9, 1.1, 2, -2, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment going through rectangle's lower left corner";
		}
		if (!Geometry.lineSegmentIntersectRectangle(0.9, 2.9, 2, -2, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment going through rectangle's upper right corner";
		}
		if (!Geometry.lineSegmentIntersectRectangle(0.9, -0.9, 2, 2, 0, 0, 2, 2)) {
			return "Found no intersection, despite line segment going through rectangle's upper right corner";
		}
		if (Geometry.lineSegmentIntersectRectangle(-5, 2.1, 100, 0, 0, 0, 2, 2)) {
			return "Found an intersection, despite line segment being too high";
		}
		if (Geometry.lineSegmentIntersectRectangle(-5, -0.1, 100, 0, 0.05, 0, 2, 2)) {
			return "Found an intersection, despite line segment being too low";
		}
		if (Geometry.lineSegmentIntersectRectangle(-1.1, 1.1, 2, 2, 0, 0, 2, 2)) {
			return "Found an intersection, despite line segment being beyond rectangle's upper left corner";
		}
		if (Geometry.lineSegmentIntersectRectangle(-1.1, 0.9, 2, -2, 0, 0, 2, 2)) {
			return "Found an intersection, despite line segment being beyond rectangle's lower left corner";
		}
		if (Geometry.lineSegmentIntersectRectangle(3.1, 1.1, -2, 2, 0, 0, 2, 2)) {
			return "Found an intersection, despite line segment being beyond rectangle's upper right corner";
		}
		if (Geometry.lineSegmentIntersectRectangle(3.1, 0.9, -2, -2, 0, 0, 2, 2)) {
			return "Found an intersection, despite line segment being beyond rectangle's lower right corner";
		}
		//Regression test
		Intersection intersection = new Intersection(false);
		intersection = Geometry.lineSegmentIntersectRectangle(0.5, -0.1, 1, 0.19, 0, 0, 1, 1, intersection);
		if (intersection.isIntersection()) {
			return "Intersected rectangle it should have missed (1)";
		}
		intersection = Geometry.lineSegmentIntersectRectangle(0.5, 1.1, 1, -0.19, 0, 0, 1, 1, intersection);
		if (intersection.isIntersection()) {
			return "Intersected rectangle it should have missed (2)";
		}
		intersection = Geometry.lineSegmentIntersectRectangle(-0.1, 0.5, 0.19, 1, 0, 0, 1, 1, intersection);
		if (intersection.isIntersection()) {
			return "Intersected rectangle it should have missed (3)";
		}
		intersection = Geometry.lineSegmentIntersectRectangle(1.1, 0.5, -0.19, 1, 0, 0, 1, 1, intersection);
		if (intersection.isIntersection()) {
			return "Intersected rectangle it should have missed (4)";
		}
		return null;
	}
	public static String lineSegmentPoint() {
		double dx = 4;
		double dy = 5;
		if (!Geometry.lineSegmentIntersectPoint(2, 8, dx, dy, 2+(dx*0.3), 8+(dy*0.3))) {
			return "No intersection despite point being on line segment";
		}
		if (Geometry.lineSegmentIntersectPoint(2, 8, dx, dy, 2+(dx*1.1), 8+(dy*1.1))) {
			return "Found intersection despite point being beyond line segment's end";
		}
		if (Geometry.lineSegmentIntersectPoint(2, 8, dx, dy, 2-(dx*0.1), 8-(dy*0.1))) {
			return "Found intersection despite point being before line segment's beginning";
		}
		if (Geometry.lineSegmentIntersectPoint(2, 8, dx, dy, 18, 27)) {
			return "Found intersection despite point being far from line segment";
		}
		return null;
	}
	public static String lineSegmentLine() {
		for (double i=2; i>=-2; i-=0.01) {
			boolean shouldIntersect = (i<=0 && i>=-1);
			boolean foundIntersection = Geometry.lineSegmentIntersectLine(i, i, 1, 1, -3, 3, 3, -3);
			if (shouldIntersect != foundIntersection) {
				if (shouldIntersect) {
					return "Should have found intersection but did not.";
				}
				else {
					return "Should not have found intersection but did.";
				}
			}
		}
		return null;
	}
	public static String firstSolidHit() {
		Tile[][] tiles = new Tile[10][10];
		for (int x=0; x<10; x++) {
			for (int y=0; y<10; y++) {
				tiles[x][y] = new Land(x, y);
			}
		}
		World world = new World(tiles);
		Solid attacker = new CircularSolid(4.5, 4.5, 0.5);
		world.moveIfCan(attacker, attacker.getX(), attacker.getY());
		Solid circle = new CircularSolid(0, 0, 0.25);
		Solid square = new RectangularSolid(0, 0, 0.25, 0.25);
		for (int i=0; i<8; i++) {
			double angle = 2.0 * Math.PI * i * 0.125;
			for (int j=0; j<2; j++) {
				Solid closer = (j == 0 ? circle : square);
				Solid farther = (j == 0 ? square : circle);
				for (int k=0; k<4; k++) {
					List <Tile> tileList = circle.getTiles();
					for (Tile tile : tileList) {
						tile.remove(circle);
					}
					tileList.clear();
					tileList = square.getTiles();
					for (Tile tile : tileList) {
						tile.remove(square);
					}
					tileList.clear();
					if (k == 0) {
						//Both are colinear
						closer.setX(attacker.getX() + (1.5*Math.cos(angle)));
						closer.setY(attacker.getY() + (1.5*Math.sin(angle)));
						farther.setX(attacker.getX() + (2.5*Math.cos(angle)));
						farther.setY(attacker.getY() + (2.5*Math.sin(angle)));
					}
					else if (k == 1) {
						//Only one is hittable
						closer.setX(attacker.getX() + (1.5*Math.cos(angle)));
						closer.setY(attacker.getY() + (1.5*Math.sin(angle)));
						farther.setX(attacker.getX() - (2.5*Math.sin(angle)));
						farther.setY(attacker.getY() + (2.5*Math.cos(angle)));
					}
					else if (k == 2) {
						//Neither hittable; not on attack line
						closer.setX(attacker.getX() + (1.5*Math.sin(angle)));
						closer.setY(attacker.getY() - (1.5*Math.cos(angle)));
						farther.setX(attacker.getX() - (2.5*Math.sin(angle)));
						farther.setY(attacker.getY() + (2.5*Math.cos(angle)));
					}
					else {
						//Neither hittable; too far away
						closer.setX(attacker.getX() + (3.5*Math.cos(angle)));
						closer.setY(attacker.getY() + (3.5*Math.sin(angle)));
						farther.setX(attacker.getX() + (4.5*Math.cos(angle)));
						farther.setY(attacker.getY() + (4.5*Math.sin(angle)));
					}
					world.moveIfCan(closer, closer.getX(), closer.getY());
					world.moveIfCan(farther, farther.getX(), farther.getY());
					Solid hit = attacker.getFirstSolidHit(2.5*Math.cos(angle), 2.5*Math.sin(angle));
					switch (k) {
					case 0:
						if (hit == null) {
							return attacker + " could not hit " + closer + " with reach of 2.5";
						}
						break;
					case 1:
						if (hit != closer) {
							return attacker + " hit " + hit + " instead of " + closer;
						}
						break;
					default:
						if (hit != null) {
							return attacker + " hit " + hit + " when no hit should occur";
						}
						break;
					}
				}
			}
		}
		tiles = new Tile[3][3];
		tiles[1][1] = new Stone(1, 1);
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (i != 1 || j != 1) {
					tiles[i][j] = new Land(i, j);
				}
			}
		}
		world = new World(tiles);
		for (int j=0; j<2; j++) {
			for (int i=0; i<3; i++) {
				List <Tile> tileList = attacker.getTiles();
				for (Tile tile : tileList) {
					tile.remove(attacker);
				}
				tileList.clear();
				tileList = circle.getTiles();
				for (Tile tile : tileList) {
					tile.remove(circle);
				}
				tileList.clear();
				if (j == 0) {
					attacker.setX(0.5);
					attacker.setY(0.5 + i);
					circle.setX(2.5);
					circle.setY(0.5 + i);
				}
				else {
					attacker.setX(0.5 + i);
					attacker.setY(0.5);
					circle.setX(0.5 + i);
					circle.setY(2.5);
				}
				world.moveIfCan(circle, circle.getX(), circle.getY());
				world.moveIfCan(attacker, attacker.getX(), attacker.getY());
				Solid target = attacker.getFirstSolidHit(5 * (1 - j), 5 * j);
				if ((target == null || target instanceof TileSolid) != (i == 1)) {
					return "Incorrectly determined target to be " + target;
				}
			}
		}
		for (int j=0; j<2; j++) {
			for (int i=0; i<4; i++) {
				List <Tile> tileList = attacker.getTiles();
				for (Tile tile : tileList) {
					tile.remove(attacker);
				}
				tileList.clear();
				tileList = circle.getTiles();
				for (Tile tile : tileList) {
					tile.remove(circle);
				}
				tileList.clear();
				double angle = Math.PI * 0.5 * i;
				double extra = 0.9 + (0.2 * j);
				attacker.setX(1.5 + (extra*Math.cos(angle)));
				attacker.setY(1.5 + (extra*Math.sin(angle)));
				circle.setX(1.5 - (extra*Math.sin(angle)));
				circle.setY(1.5 + (extra*Math.cos(angle)));
				world.moveIfCan(circle, circle.getX(), circle.getY());
				world.moveIfCan(attacker, attacker.getX(), attacker.getY());
				double dx = (i < 2 ? -1.5 : 1.5);
				double dy = (i == 0 || i == 3 ? 1.5 : -1.5);
				Solid target = attacker.getFirstSolidHit(dx, dy);
				if ((target == null || target instanceof TileSolid) == (j == 1)) {
					return "Incorrectly determined target to be " + target;
				}
			}
		}
		tiles = new Tile[3][3];
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		world = new World(tiles);
		Solid target = new RectangularSolid(1, 1, 1, 1);
		attacker = new CircularSolid(0.5, 0.5, 0.4);
		if (!world.moveIfCan(attacker, attacker.getX(), attacker.getY())) {
			return "Could not place attacker at (0.5, 0.5)";
		}
		if (!world.moveIfCan(target, target.getX(), target.getY())) {
			return "Could not place target at (1, 1)";
		}
		for (double k = 0; k<3; k += 0.01) {
			boolean hit = attacker.getFirstSolidHit(k, 0.5, 0, 1) != null;
			if (hit && (k < 1 || k > 2)) {
				return "Hit target spanning 1-2 despite striking at x of " + k;
			}
			else if ((!hit) && k > 1 && k < 2) {
				return "Did not hit target spanning 1-2 despite striking at x of " + k;
			}
		}
		if (attacker.getFirstSolidHit(2.5, 2.5, -1.5, -1.5) == null) {
			return "Attacker did not hit target when attacking from position out of body";
		}
		return null;
	}
	public static String canMove() {
		Tile[][] tiles = new Tile[3][3];
		tiles[0][0] = new Stone(0, 0);
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (i==0 & j == 0) {
					continue;
				}
				tiles[i][j] = new Land(i, j);
			}
		}
		World world = new World(tiles);
		Solid mover = new CircularSolid(1.5, 1.5, 0.1);
		if (!world.moveIfCan(mover, 1.5, 1.5)) {
			return "Unable to place " + mover + " at (1.5, 1.5)";
		}
		for (double x=0.5; x<3; x+=0.5) {
			for (double y=0.5; y<3; y+=0.5) {
				boolean can = world.canMove(mover, x, y);
				boolean should = (x >= 1.5 || y >= 1.5);
				if (can != should) {
					return "Test without other solid failed at (x, y) = (" + x + ", "+ y + ")";
				}
			}
		}
		Solid blocker = new RectangularSolid(0, 0, 0.8, 0.8);
		if (!world.moveIfCan(blocker, 2.15, 2.15)) {
			return "Unable to place blocker at (2.15, 2.15)";
		}
		for (double x=0.5; x<3; x+=0.5) {
			for (double y=0.5; y<3; y+=0.5) {
				boolean can = world.canMove(mover, x, y);
				boolean should = (x >= 1.5 || y >= 1.5) && (x < 2.5 || y < 2.5);
				if (can != should) {
					return "Test with other solid failed at (x, y) = (" + x + ", "+ y + ")";
				}
			}
		}
		return null;
	}
	public static String moveIfCan() {
		Tile[][] tiles = new Tile[3][3];
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		World world = new World(tiles);
		Solid solid = new CircularSolid(1.5, 1.5, 0.5);
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				double x = i+0.5;
				double y = j+0.5;
				world.moveIfCan(solid, x, y);
				if (!checkTiles(tiles, new Tile[] {tiles[i][j]}, solid)) {
					return "First check failed for (x,y)=("+x+","+y+")";
				}
			}
		}
		for (int i=1; i<3; i++) {
			for (int j=0; j<3; j++) {
				double x = i;
				double y = j+0.5;
				world.moveIfCan(solid, x, y);
				if (!checkTiles(tiles, new Tile[] {tiles[i][j], tiles[i-1][j]}, solid)) {
					return "Second check failed for (x,y)=("+x+","+y+")";
				}
			}
		}
		for (int i=0; i<3; i++) {
			for (int j=1; j<3; j++) {
				double x = i+0.5;
				double y = j;
				world.moveIfCan(solid, x, y);
				if (!checkTiles(tiles, new Tile[] {tiles[i][j], tiles[i][j-1]}, solid)) {
					return "Third check failed for (x,y)=("+x+","+y+")";
				}
			}
		}
		for (int i=1; i<3; i++) {
			for (int j=1; j<3; j++) {
				double x = i;
				double y = j;
				world.moveIfCan(solid, x, y);
				if (!checkTiles(tiles, new Tile[] {
						tiles[i][j], tiles[i-1][j], tiles[i][j-1], tiles[i-1][j-1]
								}, solid)) {
					return "Fourth check failed for (x,y)=("+x+","+y+")";
				}
			}
		}
		return null;
	}
	private static boolean checkTiles(Tile[][] tiles, Tile[] correctTiles, Solid solid) {
		//Checks if the tiles in correctTiles are the only ones containing
		//and contained by the solid
		List <Tile> occupiedTiles = solid.getTiles();
		if (occupiedTiles.size() != correctTiles.length) {
			return false;
		}
		for (Tile tile : correctTiles) {
			if (!occupiedTiles.contains(tile)) {
				return false;
			}
		}
		int count = 0;
		for (Tile[] column : tiles) {
			for (Tile tile : column) {
				if (tile.getSolids().contains(solid)) {
					boolean matches = false;
					for (Tile t : correctTiles) {
						if (t == tile) {
							matches = true;
							break;
						}
					}
					if (!matches) {
						return false;
					}
					count++;
				}
			}
		}
		return count == correctTiles.length;
	}
	public static String parallelogramSolid() {
		Solid solid = new CircularSolid(3.5, 3.6, 0.5);
		for (int i=-2; i<20; i++) {
			if (Geometry.parallelogramIntersectSolid(0, 0, 1, 3, 5, i, solid)) {
				if (i >= 1 && i <= 6) {
					//Fine
				}
				else {
					return "Failure at i=" + i + "; no intersection yet one expected";
				}
			}
			else {
				if (i >= 1 && i <= 6) {
					return "Failure at i=" + i + "; intersection yet none expected";
				}
				else {
					//Fine
				}
			}
		}
		for (int i=-4; i<20; i++) {
			solid.setX(i);
			for (int j=-4; j<20; j++) {
				solid.setY(j);
				if (Geometry.parallelogramIntersectSolid(1, 1, 1, 3, 4, 0, solid) !=
						Geometry.circleIntersectRectangle(i, j, 0.5, 1, 1, 4, 2)) {
					return "Failure when (i, j) = (" + i + ", " + j + ")";
				}
			}
		}
		return null;
	}
	public static String canMoveLinearly() {
		Tile[][] tiles = new Tile[9][9];
		tiles[1][1] = new Stone(1, 1);
		tiles[3][1] = new Water(3, 1);
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new Land(i, j);
				}
			}
		}
		SolidActor agent = new SolidActor(0.49, 1);
		//Test obstructing tiles
		World world = new World(tiles);
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (i == 1 && j==1) {
					continue;
				}
				if (!world.moveIfCan(agent, i + 0.5, j + 0.5)) {
					return "Unable to move agent to (" + i + ", " + j + ")";
				}
				if (j != 1) {
					for (int x=0; x<3; x++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								x + 0.5 - agent.getX(), 0)) {
							return "Unable to move agent horizontally despite no obstruction";
						}
					}
					
				}
				if (i != 1) {
					for (int y=0; y<3; y++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								0, y + 0.5 - agent.getY())) {
							return "Unable to move agent vertically despite no obstruction";
						}
					}
					
				}
				double dx;
				double dy;
				switch (i) {
				case 0:
					dx = 2;
					break;
				case 1:
					dx = 0;
					break;
				default:
					dx = -2;
					break;
				}
				switch (j) {
				case 0:
					dy = 2;
					break;
				case 1:
					dy = 0;
					break;
				default:
					dy = -2;
					break;
				}
				if (world.canMove(agent, agent.getX(), agent.getY(), dx, dy)) {
					return "Agent moved through solid obstruction";
				}
			}
		}
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (i == 1 && j==1) {
					continue;
				}
				if (!world.moveIfCan(agent, i + 2.5, j + 0.5)) {
					return "Unable to move agent to (" + i + ", " + j + ")";
				}
				if (j != 1) {
					for (int x=0; x<3; x++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								x + 2.5 - agent.getX(), 0)) {
							return "Unable to move agent horizontally despite no obstruction";
						}
					}
					
				}
				if (i != 1) {
					for (int y=0; y<3; y++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								0, y + 0.5 - agent.getY())) {
							return "Unable to move agent vertically despite no obstruction";
						}
					}
					
				}
				double dx;
				double dy;
				switch (i) {
				case 0:
					dx = 2;
					break;
				case 1:
					dx = 0;
					break;
				default:
					dx = -2;
					break;
				}
				switch (j) {
				case 0:
					dy = 2;
					break;
				case 1:
					dy = 0;
					break;
				default:
					dy = -2;
					break;
				}
				if (world.canMove(agent, agent.getX(), agent.getY(), dx, dy)) {
					return "Agent moved through unwalkable tile";
				}
			}
		}
		Solid blocker1 = new CircularSolid(0, 0, 0.49);
		if (!world.moveIfCan(blocker1, 1.5, 3.5)) {
			return "Cannot move blocker1 to (1.5, 3.5)";
		}
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (i == 1 && j==1) {
					continue;
				}
				if (!world.moveIfCan(agent, i + 0.5, j + 2.5)) {
					return "Unable to move agent to (" + i + ", " + j + ")";
				}
				if (j != 1) {
					for (int x=0; x<3; x++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								x + 0.5 - agent.getX(), 0)) {
							return "Unable to move agent horizontally despite no obstruction";
						}
					}
					
				}
				if (i != 1) {
					for (int y=0; y<3; y++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								0, y + 2.5 - agent.getY())) {
							return "Unable to move agent vertically despite no obstruction";
						}
					}
					
				}
				double dx;
				double dy;
				switch (i) {
				case 0:
					dx = 2;
					break;
				case 1:
					dx = 0;
					break;
				default:
					dx = -2;
					break;
				}
				switch (j) {
				case 0:
					dy = 2;
					break;
				case 1:
					dy = 0;
					break;
				default:
					dy = -2;
					break;
				}
				if (world.canMove(agent, agent.getX(), agent.getY(), dx, dy)) {
					return "Agent moved through solid blocker1 (circular)";
				}
			}
		}
		if (!world.moveIfCan(blocker1, 3.5, 3.5)) {
			return "Cannot move blocker2 to (3.5, 3.5)";
		}
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (i == 1 && j==1) {
					continue;
				}
				if (!world.moveIfCan(agent, i + 2.5, j + 2.5)) {
					return "Unable to move agent to (" + i + ", " + j + ")";
				}
				if (j != 1) {
					for (int x=0; x<3; x++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								x + 2.5 - agent.getX(), 0)) {
							return "Unable to move agent horizontally despite no obstruction";
						}
					}
					
				}
				if (i != 1) {
					for (int y=0; y<3; y++) {
						if (!world.canMove(agent, agent.getX(), agent.getY(),
								0, y + 2.5 - agent.getY())) {
							return "Unable to move agent vertically despite no obstruction";
						}
					}
					
				}
				double dx;
				double dy;
				switch (i) {
				case 0:
					dx = 2;
					break;
				case 1:
					dx = 0;
					break;
				default:
					dx = -2;
					break;
				}
				switch (j) {
				case 0:
					dy = 2;
					break;
				case 1:
					dy = 0;
					break;
				default:
					dy = -2;
					break;
				}
				if (world.canMove(agent, agent.getX(), agent.getY(), dx, dy)) {
					return "Agent moved through solid blocker2 (rectangular)";
				}
			}
		}
		if (!world.moveIfCan(agent, 0.5, 8.5)) {
			return "Cannot move agent to (0.5,8.5)";
		}
		if (!world.canMove(agent, agent.getX(), agent.getY(), 8, -8)) {
			return "Cannot move agent diagonally across map despite no obstructions";
		}
		if (!world.moveIfCan(agent, 4.5, 4.5)) {
			return "Cannot move agent to (4.5,4.5)";
		}
		if (!world.canMove(agent, agent.getX(), agent.getY(), 4, 4)) {
			return "Cannot move agent diagonally across map despite no obstructions";
		}
		//Regression test
		tiles = new Tile[3][3];
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		Solid s0 = new SolidActor(0.5, 1);
		Solid s1 = new SolidActor(0.5, 1);
		world = new World(tiles);
		world.moveIfCan(s0, 0.5, 0.5);
		world.moveIfCan(s1, 0.5, 2.5);
		if (!world.canMove(s0, s0.getX(), s0.getY(), s1.getX() - s0.getX(), s1.getY() - s0.getY())) {
			return "Could not move directly toward mobile solid";
		}
		//Regression test
		tiles = new Tile[10][10];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Dirt(i, j);
			}
		}
		world = new World(tiles);
		CircularSolid mover = new CircularSolid(2.9, 0.5, 0.49);
		RectangularSolid blocker = new RectangularSolid(3, 3, 3, 3);
		if (!world.moveIfCan(mover, mover.getX(), mover.getY())) {
			return "Cannot place mover";
		}
		if (!world.moveIfCan(blocker, blocker.getX(), blocker.getY())) {
			return "Cannot place blocker";
		}
		if (world.canMove(mover, mover.getX(), mover.getY(), 0, 8)) {
			return "Mover moved through blocker";
		}
		return null;
	}
	public static String nodeMap() {
		Tile[][] tiles = new Tile[20][20];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		World world = new World(tiles);
		class TestSolid extends CircularSolid {
			public TestSolid(double radius) {
				super(0, 0, radius);
			}
			public boolean isMobile() {
				return true;
			}
			public boolean walks() {
				return true;
			}
		}
		Solid solid = new TestSolid(0.5);
		if (!world.moveIfCan(solid, solid.getX(), solid.getY())) {
			return "Unable to place solid on empty map";
		}
		NodeMap nodeMap = new NodeMap(world, solid);
		if (nodeMap.walks != solid.walks()) {
			return "Did not copy 'walks' correctly";
		}
		if (nodeMap.solidRadius != solid.getRadius()) {
			return "Did not copy radius correctly";
		}
		//Test that empty tiles get a central node
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				PathNode[] nodes = nodeMap.getNodes(i, j);
				if (nodes.length != 1) {
					return "Found " + nodes.length + " nodes in tile that should have one.";
				}
				if (nodes[0].x != i+0.5 || nodes[0].y != j+0.5) {
					return "Central node not actually in center";
				}
			}
		}
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = (i < 2 && j < 2 ? new Land(i, j) : new Water(i, j));
			}
		}
		world = new World(tiles);
		if (!world.moveIfCan(solid, solid.getX(), solid.getY())) {
			return "Cannot place solid on empty land in second test";
		}
		nodeMap = new NodeMap(world, solid);
		//Test that unwalkable tiles get zero nodes
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (i < 2 && j < 2) {
					PathNode[] nodes = nodeMap.getNodes(i, j);
					if (nodes.length != 1) {
						return "Found " + nodes.length + " nodes in tile that should have one.";
					}
				}
				else {
					PathNode[] nodes = nodeMap.getNodes(i, j);
					if (nodes.length > 0) {
						return "Found " + nodes.length + " nodes in tile that should have none.";
					}
				}
			}
		}
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (i % 2 == 1 && j % 2 == 1) {
					tiles[i][j] = new Stone(i, j);
				}
				else {
					tiles[i][j] = new Land(i, j);
				}
			}
		}
		world = new World(tiles);
		solid = new TestSolid(0.1);
		if (!world.moveIfCan(solid, 0.1, 0.1)) {
			return "Unable to place solid in empty tile in third test";
		}
		nodeMap = new NodeMap(world, solid);
		//Test nodes around obstructing tiles
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				PathNode[] nodes = nodeMap.getNodes(i, j);
				if (tiles[i][j] instanceof Stone) {
					if (nodes.length != 0) {
						return "Found nodes in obstructing tile";
					}
				}
				else {
					int should;
					if (i == 0 || i == tiles.length - 1) {
						if (j == 0 || j == tiles[i].length - 1) {
							should = 1;
						}
						else if (j % 2 == 0) {
							should = 2;
						}
						else {
							should = 1;
						}
					}
					else if (j == 0 || j == tiles[i].length - 1) {
						if (i % 2 == 0) {
							should = 2;
						}
						else {
							should = 1;
						}
					}
					else if (i % 2 == 0 && j % 2 == 0) {
						should = 4;
					}
					else {
						should = 2;
					}
					if (nodes.length != should) {
						return "Found " + nodes.length + " nodes in tile that should have " + should;
					}
				}
			}
		}
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		world = new World(tiles);
		Solid circle0 = new CircularSolid(0.5, 0.5, 0.1);
		if (!world.moveIfCan(circle0, circle0.getX(), circle0.getY())) {
			return "Cannot place circular solid in empty tile in fourth test";
		}
		Solid circle1 = new CircularSolid(5.01, 5.01, 0.1);
		if (!world.moveIfCan(circle1, circle1.getX(), circle1.getY())) {
			return "Cannot place circular solid at tile intersection in fourth test";
		}
		Solid rectangle0 = new RectangularSolid(1.5, 7.3, 14, 0.4);
		if (!world.moveIfCan(rectangle0, rectangle0.getX(), rectangle0.getY())) {
			return "Cannot place wide rectangular solid in fourth test";
		}
		if (!world.moveIfCan(solid, 18.5, 18.5)) {
			return "Cannot place mobile solid in fourth test";
		}
		nodeMap = new NodeMap(world, solid);
		//Test solids
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				int should;
				if (i == 0 && j == 0) {
					should = 16;
				}
				else if (i == 5 && j == 5) {
					should = 5;
				}
				else if (i == 5 && j == 4) {
					should = 4;
				}
				else if (i == 4 && j == 5){
					should = 4;
				}
				else if (i == 4 && j == 4) {
					should = 3;
				}
				else if ((i > 0 && i < 16) && j == 7) {
					should = 2;
				}
				else {
					should = 1;
				}
				PathNode[] nodes = nodeMap.getNodes(i, j);
				if (nodes.length != should) {
					return tiles[i][j] + " has " + nodes.length + " nodes but should have " + should;
				}
			}
		}
		return null;
	}
	public static String getNodeMap() {
		Tile[][] tiles = new Tile[1][1];
		tiles[0][0] = new Land(0,0);
		class Modifiable extends CircularSolid{
			public Modifiable() {
				super(0.5, 0.5, 0.4);
			}
			private boolean walks;
			public boolean walks() {
				return walks;
			}
			private double rad;
			public double getRadius() {
				return rad;
			}
			public void set(double rad, boolean walks) {
				this.rad = rad;
				this.walks = walks;
			}
		}
		Modifiable solid = new Modifiable();
		World world = new World(tiles);
		if (!world.moveIfCan(solid, solid.getX(), solid.getY())) {
			return "Unable to place solid in empty world";
		}
		NodeMap[] maps = new NodeMap[10];
		solid.set(3, true);
		maps[4] = world.getNodeMap(solid);
		if (maps[4].solidRadius != solid.getRadius() || maps[4].walks != solid.walks()) {
			return "Generated node map attributes do not match representative's";
		}
		solid.set(2, true);
		maps[2] = world.getNodeMap(solid);
		if (maps[2] == maps[4]) {
			return "Got same map as before (2)";
		}
		solid.set(4, false);
		maps[7] = world.getNodeMap(solid);
		if (maps[7] == maps[2] || maps[7] == maps[4]) {
			return "Got same map as before (7)";
		}
		solid.set(2, false);
		maps[3] = world.getNodeMap(solid);
		if (maps[3] == maps[2] || maps[3] == maps[4] || maps[3] == maps[7]) {
			return "Got same map as before (3)";
		}
		solid.set(1, true);
		maps[0] = world.getNodeMap(solid);
		if (maps[0] == maps[2] || maps[0] == maps[3] ||
				maps[0] == maps[4] || maps[0] == maps[7]) {
			return "Got same map as before (0)";
		}
		solid.set(3, false);
		maps[5] = world.getNodeMap(solid);
		if (maps[5] == maps[0] || maps[5] == maps[2] || maps[5] == maps[3] ||
				maps[5] == maps[4] || maps[5] == maps[7]) {
			return "Got same map as before (5)";
		}
		for (int i=0; i<maps.length; i++) {
			NodeMap map = maps[i];
			if (map == null) {
				continue;
			}
			solid.set(map.solidRadius, map.walks);
			if (world.getNodeMap(solid) != map) {
				return "Did not get same map (" + i + ")";
			}
		}
		return null;
	}
	public static String pathNodeHeap() {
		PathNode[] nodes = new PathNode[10];
		for (int i=0; i<nodes.length; i++) {
			nodes[i] = new PathNode(i, 0);
			nodes[i].initialize(0, 0, 0);
			nodes[i].setDistanceTo(1);
		}
		PathNodeHeap heap = new PathNodeHeap();
		//Do we get these in the correct order?
		int[] ints = new int[] {0,5,3,7,8,2,9,1,4,6};
		for (int i : ints) {
			heap.push(nodes[i]);
		}
		for (int i=0; i<nodes.length; i++) {
			PathNode popped = heap.pop();
			if (popped != nodes[i]) {
				return "Got wrong node; expected number " + i;
			}
		}
		//Does altering the nodes and resifting work?
		for (PathNode node : nodes) {
			heap.push(node);
		}
		for (int i : ints) {
			nodes[i].initialize(i, 0, 1);
			nodes[i].setDistanceTo(0);
			//Now this should be the top node
			heap.resift(nodes[i]);
			if (heap.pop() != nodes[i]) {
				return "Did not get node " + i + " after resifting to top";
			}
		}
		return null;
	}
	public static String setPath() {
		Tile[][] tiles = new Tile[10][10];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Land(i, j);
			}
		}
		SolidActor player = new Player(0.5, 1);
		World world = new World(tiles);
		if (!world.moveIfCan(player, 0.5, 0.5)) {
			return "Unable to place player despite no obstructions (1)";
		}
		world.setPath(player, 8.5, 7);
		//Should have no nodes because it is a direct path
		ArrayDeque <PathNode> path = player.getPath();
		if (!path.isEmpty()) {
			return "Node(s) in what should be a direct path";
		}
		if (player.getDestination(true) != 8.5 ||
				player.getDestination(false) != 7) {
			return "Did not set solid's destination to point specified";
		}
		Solid rectangle = new RectangularSolid(1, 1, 1, 2);
		world = new World(tiles);
		if (!world.moveIfCan(player, 0.5, 0.5)) {
			return "Unable to place player despite no obstructions (2)";
		}
		if (!world.moveIfCan(rectangle, rectangle.getX(), rectangle.getY())) {
			return "Unable to place rectangle despite no obstructions (1)";
		}
		world.setPath(player, 2.5, 2.5);
		path = player.getPath();
		//Should have one node at corner
		if (path.size() != 1) {
			return "Path has " + path.size() + " nodes but should have one.";
		}
		PathNode node = path.pop();
		if ((int)(node.x) != 2 || (int)(node.y) != 0) {
			return "Node should be near (2.5, 0.5) but is " + node;
		}
		Solid circle = new CircularSolid(0.5, 1.5, 0.49);
		world = new World(tiles);
		if (!world.moveIfCan(player, 0.5, 0.5)) {
			return "Unable to place player despite no obstructions (3)";
		}
		if (!world.moveIfCan(rectangle, rectangle.getX(), rectangle.getY())) {
			return "Unable to place rectangle despite no obstructions (2)";
		}
		if (!world.moveIfCan(circle, circle.getX(), circle.getY())) {
			return "Unable to place circle despite no obstructions (1)";
		}
		world.setPath(player, 0.5, 2.5);
		path = player.getPath();
		//Should have three nodes
		if (path.size() != 3) {
			return "Path has " + path.size() + " nodes but should have three.";
		}
		node = path.pop();
		if ((int)(node.x) != 2 || (int)(node.y) != 0) {
			return "Node should be near (2.5, 0.5) but is " + node;
		}
		node = path.pop();
		if ((int)(node.x) != 2 || (int)(node.y) != 3) {
			return "Node should be near (2.5, 3.5) but is " + node;
		}
		node = path.pop();
		if ((int)(node.x) != 0 || (int)(node.y) != 3) {
			return "Node should be near (0.5, 3.5) but is " + node;
		}
		world = new World(tiles);
		Solid wall = new RectangularSolid(2, 1, tiles.length - 2, 0.1);
		if (!world.moveIfCan(player, 0.5, 0.5)) {
			return "Unable to place player despite no obstructions (4)";
		}
		if (!world.moveIfCan(rectangle, rectangle.getX(), rectangle.getY())) {
			return "Unable to place rectangle despite no obstructions (3)";
		}
		if (!world.moveIfCan(circle, circle.getX(), circle.getY())) {
			return "Unable to place rectangle despite no obstructions (2)";
		}
		if (!world.moveIfCan(wall, wall.getX(), wall.getY())) {
			return "Unable to place wall despite no obstructions (1)";
		}
		world.setPath(player, tiles.length - 0.5, 2.5);
		path = player.getPath();
		if (path.size() != 1) {
			return "Path has " + path.size() + " nodes but should have one.";
		}
		node = path.pop();
		if ((int)(node.x) != tiles.length - 1 || (int)(node.y) != 0) {
			return "Node should be near (9.5, 0.5) but is " + node;
		}
		return null;
	}
	static class TestMerchant extends Merchant{
		public TestMerchant(String name, String[] items, int[] buyPrices, int[] sellPrices, int[] inventory, int money) {
			super(name, items, buyPrices, sellPrices, inventory, money);
		}
		@Override
		public void closeShopInterface() {}
	}
	public static String merchant() {
		String name = "Test Merchant";
		String[] items = new String[] {"BuyOnly", "SellOnly", "Both"};
		Player player = new Player(1, 1);
		player.getInventory().put(items[1], 9999);
		player.changeMoney(9999);
		int[] buyPrices = new int[] {10, Integer.MIN_VALUE, 20};
		int[] sellPrices = new int[] {Integer.MIN_VALUE, 15, 15};
		int[] inventory = new int[] {5, 0, 4};
		int money = 100;
		Merchant merchant = new TestMerchant(name, items, buyPrices, sellPrices, inventory, money);
		if (merchant.trade(player, 0, false)) {
			return "Sold to merchant an item that should be buy-only";
		}
		if (merchant.trade(player, 1, true)) {
			return "Bought from merchant an item that should by sell-only";
		}
		//Try to buy out
		for (int i=0; i<5; i++) {
			boolean trade = merchant.trade(player, 0, true);
			if (trade == false) {
				return "Unable to buy item five times";
			}
		}
		if (merchant.trade(player, 0, true)) {
			return "Able to purchase item when it should be sold out.";
		}
		//Sell
		for (int i=0; i<10; i++) {
			boolean trade = merchant.trade(player, 1, false);
			if (trade == false) {
				return "Unable to sell item ten times.";
			}
		}
		if (merchant.trade(player, 1, false)) {
			return "Able to sell item when merchant should have no money.";
		}
		if (merchant.trade(player, 2, false)) {
			return "Able to sell item when merchant should have no money.";
		}
		//Buy and sell
		for (int i=0; i<3; i++) {
			boolean trade = merchant.trade(player, 2, true);
			if (trade == false) {
				return "Unable to buy item three times";
			}
		}
		for (int i=0; i<4; i++) {
			int item = 1 + (i % 2);
			boolean trade = merchant.trade(player, item, false);
			if (trade == false) {
				return "Unable to sell item " + item;
			}
		}
		if (merchant.trade(player, 1, false)) {
			return "Able to sell item when merchant should have no money.";
		}
		if (merchant.trade(player, 2, false)) {
			return "Able to sell item when merchant should have no money.";
		}
		//Test player inventory and money handled correctly
		merchant = new TestMerchant(name, items, buyPrices, sellPrices, inventory, money);
		//Set money to zero
		player.changeMoney(-player.getMoney());
		player.getInventory().put(items[2], 4);
		//Cannot buy when broke
		if (merchant.trade(player, 2, true)) {
			return "Bought item when player had no money.";
		}
		for (int i=0; i<4; i++) {
			boolean trade = merchant.trade(player, 2, false);
			if (trade == false) {
				return "Unable to sell item four times.";
			}
		}
		if (merchant.trade(player, 2, false)) {
			return "Able to sell item when player has none.";
		}
		//Player should now have 60 money
		for (int i=0; i<3; i++) {
			boolean trade = merchant.trade(player, 2, true);
			if (trade == false) {
				return "Unable to buy item three times.";
			}
		}
		if (merchant.trade(player, 2, true)) {
			return "Able to buy item when player has no money.";
		}
		//Verify you can't sell something equipped
		items[0] = Wielder.SWORD;
		items[1] = Wielder.SHIELD;
		items[2] = "Other";
		sellPrices[0] = 1;
		sellPrices[1] = 1;
		sellPrices[2] = 1;
		money = 999;
		merchant = new TestMerchant(name, items, buyPrices, sellPrices, inventory, money);
		player.setWeapon(Wielder.SWORD);
		player.setHasShield(true);
		player.getInventory().put(Wielder.SWORD, 1);
		player.getInventory().put(Wielder.SHIELD, 1);
		if (merchant.trade(player, 0, false)) {
			return "Sold equipped sword.";
		}
		if (merchant.trade(player, 1, false)) {
			return "Sold equipped shield.";
		}
		player.setWeapon(Wielder.NONE);
		boolean trade = merchant.trade(player, 0, false);
		if (trade == false) {
			return "Unable to sell sword after unequipping.";
		}
		player.setHasShield(false);
		trade = merchant.trade(player, 1, false);
		if (trade == false) {
			return "Unable to sell shield after unequipping.";
		}
		return null;
	}
	public static String projectile() {
		Tile[][] tiles = new Tile[4][4];
		tiles[0][1] = new Stone(0, 1);
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new Dirt(i, j);
				}
			}
		}
		World world = new World(tiles);
		SolidActor source = new SolidActor(0.5, 2);
		SolidActor blocked = new SolidActor(0.5, 2);
		SolidActor hittable = new SolidActor(0.5, 2);
		SolidActor tooFar = new SolidActor(0.5, 2);
		world.moveIfCan(source, 0.5, 0.5);
		world.moveIfCan(blocked, 0.5, 3.5);
		world.moveIfCan(hittable, 3.5, 0.5);
		world.moveIfCan(tooFar, 3.5, 3.5);
		//Will the arrow hit a target?
		Arrow arrow = new Arrow(0.5, 0.5, 100, 1, 0, source, 1);
		for (int i=0; i<10 && !arrow.isDead(); i++) {
			arrow.act();
		}
		if (!arrow.isDead()) {
			return "First arrow did not disappear.";
		}
		if (hittable.getHealth() != 1) {
			return "hittable has " + hittable.getHealth() + " health when it should be 1.";
		}
		arrow = new Arrow(0.5, 0.5, 100, 1, 0, source, 1);
		for (int i=0; i<10 && !arrow.isDead(); i++) {
			arrow.act();
		}
		if (!arrow.isDead()) {
			return "Second arrow did not disappear.";
		}
		if (hittable.getHealth() != 0) {
			return "hittable has " + hittable.getHealth() + " health when it should be 0.";
		}
		arrow = new Arrow(0.5, 0.5, 100, 0, 1, source, 1);
		for (int i=0; i<10 && !arrow.isDead(); i++) {
			arrow.act();
		}
		if (!arrow.isDead()) {
			return "Third arrow did not disappear.";
		}
		if (blocked.getHealth() != 2) {
			return "blocked has " + blocked.getHealth() + " health when it should be 2.";
		}
		arrow = new Arrow(0.5, 0.5, 3, 0.5, 0.5, source, 1);
		for (int i=0; i<10 && !arrow.isDead(); i++) {
			arrow.act();
		}
		if (!arrow.isDead()) {
			return "Fourth arrow did not disappear.";
		}
		if (tooFar.getHealth() != 2) {
			return "tooFar has " + tooFar.getHealth() + " health when it should be 2.";
		}
		arrow = new Arrow(0.5, 0.5, 10, -1, -1, source, 1);
		for (int i=0; i<10 && !arrow.isDead(); i++) {
			arrow.act();
		}
		if (!arrow.isDead()) {
			return "Fifth arrow did not disappear.";
		}
		if (blocked.getHealth() != 2) {
			return "blocked has " + blocked.getHealth() + " health on final check when it should be 2.";
		}
		if (tooFar.getHealth() != 2) {
			return "tooFar has " + tooFar.getHealth() + " health on final check when it should be 2.";
		}
		return null;
	}
	public static String triggeredInteraction() {
		Tile[][] tiles = new Tile[10][10];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Dirt(i, j);
			}
		}
		class TestInteraction extends TriggeredInteraction{
			private int shape;
			private double width;
			private double height;
			private double radius;
			private int[] counter;
			public TestInteraction(int shape, int[] counter) {
				this.shape = shape;
				this.counter = counter;
				switch (shape){
				case Solid.CIRCLE:
					radius = 0.5;
					width = 0;
					height = 0;
					break;
				case Solid.RECTANGLE:
					radius = 0;
					width = 1;
					height = 1;
					break;
				default:
					radius = 0;
					width = 0;
					height = 0;
					break;
				}
			}
			@Override
			public int getShape() {
				return shape;
			}
			@Override
			public double getWidth() {
				return width;
			}
			@Override
			public double getHeight() {
				return height;
			}
			@Override
			public double getRadius() {
				return radius;
			}
			@Override
			public void interact() {
				super.interact();
				counter[0]++;
			}
		}
		Player player = new Player(.5, 1);
		World world = new World(tiles);
		world.moveIfCan(player, 5, 5);
		int[] counter = new int[] {0};
		//Can we detect a circle?
		TriggeredInteraction i = new TestInteraction(Solid.CIRCLE, counter);
		world.place(i, 5.9, 5);
		player.checkForTriggeredInteractions();
		if (counter[0] != 1) {
			return "Did not detect nearby circle.";
		}
		player.checkForTriggeredInteractions();
		if (counter[0] > 1) {
			return "Same circle triggered twice.";
		}
		//Can we detect a square?
		i = new TestInteraction(Solid.RECTANGLE, counter);
		world.place(i, 4.5, 4.5);
		player.checkForTriggeredInteractions();
		if (counter[0] != 2) {
			return "Did not detect nearby square.";
		}
		player.checkForTriggeredInteractions();
		if (counter[0] > 2) {
			return "Same square triggered twice.";
		}
		//Can we detect a point?
		i = new TestInteraction(Solid.POINT, counter);
		world.place(i, 5, 5.45);
		player.checkForTriggeredInteractions();
		if (counter[0] != 3) {
			return "Did not detect nearby point.";
		}
		player.checkForTriggeredInteractions();
		if (counter[0] > 3) {
			return "Same point triggered twice.";
		}
		//Check that all tiles have had their interactions removed
		for (Tile[] column : tiles) {
			for (Tile t : column) {
				if (!t.getTriggeredInteractions().isEmpty()) {
					return "Triggered interactions not removed after triggering.";
				}
			}
		}
		//Can we conclude that a circle is too far?
		i = new TestInteraction(Solid.CIRCLE, counter);
		world.place(i, 3.9, 5);
		player.checkForTriggeredInteractions();
		if (counter[0] != 3) {
			return "Triggered circle that should be too far away.";
		}
		i = new TestInteraction(Solid.RECTANGLE, counter);
		world.place(i, 4, 6);
		player.checkForTriggeredInteractions();
		if (counter[0] != 3) {
			return "Triggered square that should be too far away.";
		}
		i = new TestInteraction(Solid.POINT, counter);
		world.place(i, 5.5, 5.5);
		player.checkForTriggeredInteractions();
		if (counter[0] != 3) {
			return "Triggered point that should be too far away.";
		}
		return null;
	}
	public static String shieldBug() {
		//Regression test
		Tile[][] tiles = new Tile[3][1];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Dirt(i, j);
			}
		}
		Player player = new Player(0.49, 100) {
			@Override
			protected void blockAttack(Solid attacker) {
				receiveDamage(0);
			}
		};
		Wielder attacker = new Wielder(0.49, 100, Wielder.RED) {
			public int getAttackDamage() {
				return 100;
			}
			public double getAttackRange() {
				return 1.39;
			}
		};
		player.setHasShield(true);
		if (player.getCombatMode()) {
			return "Combat mode is on.";
		}
		attacker.setWeapon(Wielder.SWORD);
		attacker.setTarget(player);
		World world = new World(tiles);
		if (!world.moveIfCan(player, 0.5, 0.5)) {
			return "Could not place player.";
		}
		if (!world.moveIfCan(attacker, 1.5, 0.5)) {
			return "Could not place attacker.";
		}
		player.face(attacker);
		attacker.face(player);
		player.receiveAttack(attacker);
		if (player.getHealth() == 0) {
			return null;
		}
		else {
			return "Player blocked attack despite not holding shield.";
		}
	}
	//This just tests that the generated building has no unreachable rooms
	public static String compoundBuilding() {
		for (int t=0; t<10; t++) {
			WorldGenerator gen = new WorldGenerator(73, 73);
			gen.createCompoundBuilding(0, 0, 73, 73, new int[0][0]);
			Player player = gen.get();
			World world = player.getWorld();
			//Find a tiled floor tile at which to start
			int x0 = -1;
			int y0 = -1;
			boolean[][] tiles = new boolean[73][73];
			int count = 0;
			for (int i=0; i<73; i++) {
				for (int j=0; j<73; j++) {
					Tile tile = world.get(i, j);
					if (tile instanceof TiledFloor) {
						if (x0 < 0) {
							x0 = i;
							y0 = j;
						}
						else {
							count++;
							tiles[i][j] = true;
						}
						
					}
				}
			}
			ArrayDeque <Tile> q = new ArrayDeque <> ();
			q.add(world.get(x0, y0));
			while (!q.isEmpty()) {
				Tile next = q.poll();
				int x = next.getX();
				int y = next.getY();
				//Which tiled floor tiles connect to this?
				for (int i=0; i<4; i++) {
					int adjx = x;
					int adjy = y;
					switch (i) {
					case 0:
						adjx++;
						break;
					case 1:
						adjx--;
						break;
					case 2:
						adjy++;
						break;
					default:
						adjy--;
						break;
					}
					Tile adj = world.get(adjx, adjy);
					if (adj instanceof TiledFloor && tiles[adjx][adjy]) {
						//process this one
						tiles[adjx][adjy] = false;
						count--;
						q.add(adj);
					}
				}
			}
			if (count > 0) {
				return "Missed " + count + " tiles.";
			}
		}
		return null;
	}
	public static String imageCaching() {
		BufferedImage img0 = new BufferedImage(1, 1, BufferedImage.TYPE_INT_BGR);
		BufferedImage img1 = new BufferedImage(1, 1, BufferedImage.TYPE_INT_BGR);
		Tile[][] tiles = new Tile[1][1];
		tiles[0][0] = new Dirt(0, 0);
		World world = new World(tiles);
		Image cached = world.getCachedTileImage(0, 10, 10);
		if (cached != null) {
			return "Returned " + cached + " when it should return null.";
		}
		world.setCachedTileImage(0, img0, 10, 10);
		cached = world.getCachedTileImage(0, 10, 10);
		if (cached != img0) {
			return "Returned " + cached + " when it should return img0.";
		}
		//We now have a cache. Check the other slots
		for (int w=8; w<=12; w++) {
			for (int h=8; h<=12; h++) {
				cached = world.getCachedTileImage(0, w, h);
				if (w == 10 && h == 10) {
					if (cached != img0) {
						return "Returned " + cached + " for (w, h) of (" + w + ", " + h + ")";
					}
				}
				else if (cached != null) {
					return "Returned " + cached + " for (w, h) of (" + w + ", " + h + ")";
				}
				world.setCachedTileImage(0, img1, w, h);
				cached = world.getCachedTileImage(0, w, h);
				if (cached != img1) {
					return "Did not save img1 to (w, h) of (" + w + ", " + h + ")";
				}
			}
		}
		//Asking for totally different dimensions should return null
		cached = world.getCachedTileImage(0, 20, 20);
		if (cached != null) {
			return "Returned " + cached + " instead of null for dimensions of (20, 20)";
		}
		//Placing something there should reset the cache
		world.setCachedTileImage(0, img0, 20, 20);
		for (int w=18; w<=22; w++) {
			for (int h=18; h<=22; h++) {
				cached = world.getCachedTileImage(0, w, h);
				if (w == 20 && h == 20) {
					if (cached != img0) {
						return "Returned " + cached + " for (w, h) of (" + w + ", " + h + ")";
					}
				}
				else {
					if (cached != null) {
						return "Returned " + cached + " for (w, h) of (" + w + ", " + h + ")";
					}
				}
			}
		}
		//Using a different tileTypeNumber should still return null
		cached = world.getCachedTileImage(1, 20, 20);
		if (cached != null) {
			return "Returned " + cached + " instead of null for new tile type number.";
		}
		return null;
	}
}
