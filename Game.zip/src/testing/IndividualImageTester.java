package testing;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

import graphics.ImageGenerator;

public class IndividualImageTester {
	public static void main(String[] args) {
		showImage(ImageGenerator.getPerson(Color.BLUE),
				ImageGenerator.getPersonSideways(Color.BLUE),
				ImageGenerator.getHeadlessPersonWithShield(Color.BLUE, Color.BLACK),
				ImageGenerator.getShieldAndArm(Color.BLUE, Color.BLACK));
		animateImage(3, ImageGenerator.getPersonWithSword(Color.BLUE));
		Image[] imgs = ImageGenerator.getPersonWithSwordAndShieldNew(Color.BLUE, Color.BLACK);
		showImage(imgs[0]);
		animateImage(3, imgs);
	}
	public static void showImage(Image... imgs) {
		JFrame frame = new JFrame("Images");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		for (Image img : imgs) {
			JLabel label = new JLabel(new ImageIcon(img));
			frame.add(label);
		}
		frame.pack();
		frame.setVisible(true);
	}
	public static void animateImage(int step, Image... imgs) {
		JFrame frame = new JFrame("Images");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon = new ImageIcon(imgs[0]);
		JLabel label = new JLabel(icon);
		frame.add(label);
		frame.pack();
		frame.setVisible(true);
		AnimationHandler handler = new AnimationHandler(icon, label, imgs, step);
		Timer timer = new Timer(40, handler);
		timer.start();
	}
	static class AnimationHandler implements ActionListener{
		private ImageIcon icon;
		private JLabel label;
		private Image[] imgs;
		int i = 0;
		int step;
		public AnimationHandler(ImageIcon icon, JLabel label, Image[] imgs, int step) {
			this.imgs = imgs;
			this.icon = icon;
			this.label = label;
			this.step = step;
		}
		public void actionPerformed(ActionEvent e) {
			icon.setImage(imgs[i]);
			label.repaint();
			i += step;
			if (i >= imgs.length) {
				i = imgs.length - 1;
				step *= -1;
			}
			else if (i < 0) {
				i = 0;
				step *= -1;
			}
		}
	}
}
