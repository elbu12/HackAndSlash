package testing;

import java.awt.Color;
import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
import main.Game;
import solid.Player;
import solid.Solid;
import solid.Wielder;
import tile.Tile;
import tile.World;

public class ShieldBlockTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[100][100];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new BigImageTester.EmptyTile(i, j);
				}
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.5, 100) {
				
			
		};
		player.getInventory().put(Wielder.SWORD, 1);
		player.getInventory().put(Wielder.SHIELD, 1);
		world.moveIfCan(player, 0.5, 0.5);
		BufferedImage[] imgs = ImageGenerator.getPersonWithSwordAndShield(Color.RED, Color.BLACK);
		for (int i=0; i<65; i++) {
			ShieldGuy guy = new ShieldGuy(i, imgs[i]);
			world.moveIfCan(guy, ((3 * i) % 51) + 1.5, ((9 * i) / 51) + 1.5);
		}
		Game game = new Game(player);
	}
	static class ShieldGuy extends Wielder{
		public ShieldGuy(int actionStep, BufferedImage img) {
			super(0.5, 1, Wielder.RED);
			setActionStep(actionStep);
			setHasShield(true);
			setWeapon(SWORD);
		}
		protected void blockAttack(Solid attacker) {
			System.out.println("blocked");
		}
		protected void receiveDamage(int damage) {
			System.out.println("hit");
		}
	}
}
