package testing;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
import main.Game;
import solid.Player;
import solid.RectangularSolid;
import solid.Solid;
import tile.Tile;
import tile.World;

public class GameFrameTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[30][30];
		for (int i=0; i<30; i++) {
			if (Math.abs(i - 10) < 2) {
				continue;
			}
			tiles[i][10] = new BigImageTester.ObstructionTile(i, 10);
		}
		for (int i=0; i<30; i++) {
			for (int j=0; j<30; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new BigImageTester.EmptyTile(i, j);
				}
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.5, 100) {
			double[][] swordXY = null;
			private BufferedImage[] images = null;
			private int actionStep = 0;
			private int actionDirection = 0;
			private int hitNumber = 1;
			public BufferedImage getImage() {
				if (images == null) {
					images = ImageGenerator.getPersonWithSwordAndShield(Color.BLUE, Color.BLACK);
				}
				return images[actionStep];
			}
			public double getImageScaleX() {
				return 1.24;
			}
			public double getImageScaleY() {
				return 3.46;
			}
			public void act() {
				super.act();
				if (keys[KeyEvent.VK_C] != Game.UNPRESSED && actionStep == 0) {
					//Ready to do something
					actionDirection = 8;
				}
				if (actionStep != 0 || actionDirection > 0) {
					if (actionStep == 64) {
						actionDirection = -8;
					}
					actionStep += actionDirection;
				}
				if (actionStep != 0) {
					if (swordXY == null) {
						swordXY = new double[65][2];
						swordXY[0][0] = 0.3;
						swordXY[0][1] = 0.88;
						swordXY[1][0] = 0.31;
						swordXY[1][1] = 0.88;
						swordXY[2][0] = 0.31;
						swordXY[2][1] = 0.89;
						swordXY[3][0] = 0.31;
						swordXY[3][1] = 0.89;
						swordXY[4][0] = 0.32;
						swordXY[4][1] = 0.91;
						swordXY[5][0] = 0.32;
						swordXY[5][1] = 0.91;
						swordXY[6][0] = 0.33;
						swordXY[6][1] = 0.91;
						swordXY[7][0] = 0.33;
						swordXY[7][1] = 0.92;
						swordXY[8][0] = 0.33;
						swordXY[8][1] = 0.93;
						swordXY[9][0] = 0.34;
						swordXY[9][1] = 0.94;
						swordXY[10][0] = 0.34;
						swordXY[10][1] = 0.94;
						swordXY[11][0] = 0.34;
						swordXY[11][1] = 0.95;
						swordXY[12][0] = 0.35;
						swordXY[12][1] = 0.96;
						swordXY[13][0] = 0.35;
						swordXY[13][1] = 0.97;
						swordXY[14][0] = 0.36;
						swordXY[14][1] = 0.97;
						swordXY[15][0] = 0.36;
						swordXY[15][1] = 0.98;
						swordXY[16][0] = 0.36;
						swordXY[16][1] = 0.99;
						swordXY[17][0] = 0.37;
						swordXY[17][1] = 1.0;
						swordXY[18][0] = 0.37;
						swordXY[18][1] = 1.0;
						swordXY[19][0] = 0.37;
						swordXY[19][1] = 1.01;
						swordXY[20][0] = 0.38;
						swordXY[20][1] = 1.02;
						swordXY[21][0] = 0.38;
						swordXY[21][1] = 1.03;
						swordXY[22][0] = 0.38;
						swordXY[22][1] = 1.03;
						swordXY[23][0] = 0.38;
						swordXY[23][1] = 1.04;
						swordXY[24][0] = 0.39;
						swordXY[24][1] = 1.05;
						swordXY[25][0] = 0.39;
						swordXY[25][1] = 1.06;
						swordXY[26][0] = 0.39;
						swordXY[26][1] = 1.06;
						swordXY[27][0] = 0.4;
						swordXY[27][1] = 1.07;
						swordXY[28][0] = 0.4;
						swordXY[28][1] = 1.09;
						swordXY[29][0] = 0.4;
						swordXY[29][1] = 1.09;
						swordXY[30][0] = 0.4;
						swordXY[30][1] = 1.1;
						swordXY[31][0] = 0.41;
						swordXY[31][1] = 1.1;
						swordXY[32][0] = 0.4;
						swordXY[32][1] = 1.12;
						swordXY[33][0] = 0.4;
						swordXY[33][1] = 1.12;
						swordXY[34][0] = 0.4;
						swordXY[34][1] = 1.13;
						swordXY[35][0] = 0.4;
						swordXY[35][1] = 1.13;
						swordXY[36][0] = 0.41;
						swordXY[36][1] = 1.15;
						swordXY[37][0] = 0.41;
						swordXY[37][1] = 1.16;
						swordXY[38][0] = 0.41;
						swordXY[38][1] = 1.16;
						swordXY[39][0] = 0.41;
						swordXY[39][1] = 1.17;
						swordXY[40][0] = 0.41;
						swordXY[40][1] = 1.18;
						swordXY[41][0] = 0.42;
						swordXY[41][1] = 1.19;
						swordXY[42][0] = 0.42;
						swordXY[42][1] = 1.19;
						swordXY[43][0] = 0.42;
						swordXY[43][1] = 1.2;
						swordXY[44][0] = 0.42;
						swordXY[44][1] = 1.22;
						swordXY[45][0] = 0.42;
						swordXY[45][1] = 1.22;
						swordXY[46][0] = 0.42;
						swordXY[46][1] = 1.23;
						swordXY[47][0] = 0.42;
						swordXY[47][1] = 1.23;
						swordXY[48][0] = 0.43;
						swordXY[48][1] = 1.25;
						swordXY[49][0] = 0.43;
						swordXY[49][1] = 1.26;
						swordXY[50][0] = 0.43;
						swordXY[50][1] = 1.26;
						swordXY[51][0] = 0.43;
						swordXY[51][1] = 1.27;
						swordXY[52][0] = 0.43;
						swordXY[52][1] = 1.28;
						swordXY[53][0] = 0.43;
						swordXY[53][1] = 1.29;
						swordXY[54][0] = 0.43;
						swordXY[54][1] = 1.3;
						swordXY[55][0] = 0.43;
						swordXY[55][1] = 1.3;
						swordXY[56][0] = 0.43;
						swordXY[56][1] = 1.32;
						swordXY[57][0] = 0.43;
						swordXY[57][1] = 1.32;
						swordXY[58][0] = 0.43;
						swordXY[58][1] = 1.33;
						swordXY[59][0] = 0.43;
						swordXY[59][1] = 1.33;
						swordXY[60][0] = 0.43;
						swordXY[60][1] = 1.35;
						swordXY[61][0] = 0.43;
						swordXY[61][1] = 1.36;
						swordXY[62][0] = 0.43;
						swordXY[62][1] = 1.36;
						swordXY[63][0] = 0.43;
						swordXY[63][1] = 1.37;
						swordXY[64][0] = 0.43;
						swordXY[64][1] = 1.38;
					}
					double actualSwordX = swordXY[actionStep][0];
					double actualSwordY = swordXY[actionStep][1];
					double a = getDirection();
					Solid hit = getFirstSolidHit(getX() + (actualSwordX*Math.cos(a)),
							getY() - (actualSwordX*Math.sin(a)),
							actualSwordY * Math.sin(a),
							actualSwordY * Math.cos(a));
					if (hit != null) {
						System.out.println("hit #" + hitNumber++);
						actionDirection = -8;
					}
				}
			}
		};
		Solid hittable = new RectangularSolid(16, 16, 1, 2) {
			BufferedImage img = null;
			public BufferedImage getImage() {
				if (img == null) {
					img = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
					Graphics2D g = img.createGraphics();
					g.setColor(Color.RED);
					g.fillRect(0, 0, 1, 1);
					g.dispose();
				}
				return img;
			}
		};
		world.moveIfCan(player, 14.5, 14.5);
		world.moveIfCan(hittable, hittable.getX(), hittable.getY());
		Game game = new Game(player);
	}
}
