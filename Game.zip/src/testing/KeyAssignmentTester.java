package testing;

import main.Game;
import solid.Player;
import tile.Dirt;
import tile.Tile;
import tile.World;

public class KeyAssignmentTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[4][4];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Dirt(i, j);
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.49, 1);
		world.moveIfCan(player, 2, 2);
		Game game = new Game(player);
		game.createKeyAssignmentFrame();
	}
}
