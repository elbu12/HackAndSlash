package testing;

import java.awt.Color;
import java.awt.image.BufferedImage;

import commerce.Merchant;
import graphics.ImageGenerator;
import loot.Gold;
import loot.TriggeredInteraction;
import main.DialogOption;
import main.Game;
import solid.CircularSolid;
import solid.Player;
import solid.Solid;
import solid.SolidActor;
import solid.Wielder;
import tile.Dirt;
import tile.Stone;
import tile.Tile;
import tile.World;

public class LootTester {
	public static void main(String[] args) {
		final boolean justArcher = false;
		
		Tile[][] tiles = new Tile[60][60];
		for (int i=0; i<tiles.length; i++) {
			if (Math.abs(i - (tiles.length / 2)) > 1) {
				tiles[i][40] = new Stone(i, 40); 
			}
		}
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new Dirt(i, j);
				}
			}
		}
		World world = new World(tiles);
	
		Player player = new Player(0.99, 100) {
			@Override
			protected void blockAttack(Solid attacker) {
				receiveDamage(attacker.getAttackDamage() / 100);
			}
			@Override
			public int getAttackDamage() {
				return 100;
			}
		};
		if (justArcher) {
			player.changeMoney(300);
		}
		world.moveIfCan(player, 0.5, 0.5);
		TriggeredInteraction loot0 = new Gold(100);
		world.place(loot0, 2, 0.5);
		CircularSolid merchant = new CircularSolid(6, 1, 0.99) {
			BufferedImage img = ImageGenerator.getPerson(Color.GREEN);
			Merchant shop = new Tester.TestMerchant("Test merchant",
					new String[] {Wielder.SWORD, Wielder.SHIELD, Wielder.BOW, Wielder.ARROW},
					new int[] {100, 100, 100, 4},
					new int[] {60, 60, 60, 2},
					new int[] {2, 2, 2, 999},
					100);
			public double getDirection() {
				return Math.PI * 1.5;
			}
			DialogOption sayHello = new DialogOption("Say 'hello'") {
				@Override
				public void choose() {
					getGame().say("'Would you like to browse my merchandise?'",
							shopOption, getGame().getOption("No"));
				}
			};
			DialogOption shopOption = new DialogOption("Yes") {
				@Override
				public void choose() {
					shop.createShopInterface(getGame());
				}
			};
			@Override
			public void interact() {
				getGame().say("The man says 'hello.'",
						sayHello,
						 getGame().getOption("Ignore him"));
			}
			public BufferedImage getImage() {
				return img;
			}
		};
		world.moveIfCan(merchant, merchant.getX(), merchant.getY());
		class LootSpider extends SolidActor{
			BufferedImage img;
			public LootSpider(Solid target) {
				super(0.9, 100);
				img = ImageGenerator.getImageFromFile("img/spider.png");
				setBehavior(STAND, ATTACK_IMMEDIATELY);
				setMovementSpeed(0.1);
				setTarget(target);
			}
			public BufferedImage getImage() {
				return img;
			}
			public int getAttackDamage() {
				return 100;
			}
			public double getAttackRange() {
				return 0.02;
			}
			@Override
			public void beginAttack() {
				attack(getTarget());
			}
			public void die() {
				super.die();
				Gold gold = new Gold(20 + (int)(Math.random() * 10));
				getWorld().place(gold, getX(), getY());
			}
		}
		for (int i=0; i<15; i++) {
			double x = Math.random() * tiles.length;
			double y = 20 + (Math.random() * 20);
			if (!justArcher) {
				world.moveIfCan(new LootSpider(player), x, y);
			}
		}
		class Tree extends CircularSolid{
			private BufferedImage img = null;
			public Tree(double radius) {
				super(0, 0, radius);
				img = ImageGenerator.getTree((int)(100.0 * radius));
			}
			public BufferedImage getImage() {
				return img;
			}
		}
		for (int i=0; i < 8; i++) {
			double x = Math.random() * tiles.length;
			double y = 10 + (Math.random() * 30);
			world.moveIfCan(new Tree(1.6 + (Math.random() * 1.6)), x, y);
		}
		class LootSwordsman extends Wielder{
			public LootSwordsman(Solid target) {
				super(0.99, 100, Wielder.RED);
				setWeapon(SWORD);
				setBehavior(STAND, ATTACK_IMMEDIATELY);
				setMovementSpeed(0.1);
				setTarget(target);
			}
			public int getAttackDamage() {
				return 100;
			}
			public double getAttackRange() {
				return 1.39;
			}
			public void die() {
				super.die();
				Gold gold = new Gold(30 + (int)(Math.random() * 20));
				getWorld().place(gold, getX(), getY());
			}
		}
		for (int i=0; i<10; i++) {
			double x = Math.random() * tiles.length;
			double y = 42 + (Math.random() * 18);
			if (!justArcher) {
				world.moveIfCan(new LootSwordsman(player), x, y);
			}
		}
		class Archer extends Wielder{
			BufferedImage img = ImageGenerator.getPersonSidewaysWithBow(Color.RED);
			public Archer(Solid target) {
				super(0.99, 100, Wielder.RED);
				setWeapon(BOW);
				setBehavior(STAND, ATTACK_IMMEDIATELY);
				setMovementSpeed(0.05);
				setTarget(target);
			}
			public int getAttackDamage() {
				return 50;
			}
			public double getAttackRange() {
				return 6;
			}
			public BufferedImage getImage() {
				return img;
			}
			protected boolean canBeginAttack() {
				Solid hit = getFirstSolidHit(getTarget().getX() - getX(), getTarget().getY() - getY());
				if (hit != null && hit != getTarget()) {
					return false;
				}
				return super.canBeginAttack();
			}
			protected void beginAttack() {
				face(getTarget());
				super.beginAttack();
			}
		}
		if (!world.moveIfCan(new Archer(player), 59.9, 59.9)) {
			System.out.println("Could not place archer");
		}
		new Game(player);
	}
	
}
