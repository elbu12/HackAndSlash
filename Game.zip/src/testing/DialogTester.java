package testing;

import java.awt.Color;
import java.awt.image.BufferedImage;

import commerce.Merchant;
import graphics.ImageGenerator;
import main.DialogOption;
import main.Game;
import solid.CircularSolid;
import solid.Player;
import solid.Solid;
import solid.Wielder;
import tile.Dirt;
import tile.Tile;
import tile.World;

public class DialogTester {
	public static void main(String[] args){
		Tile[][] tiles = new Tile[6][6];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Dirt(i, j);
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.5, 1);
		player.changeMoney(150);
		Solid talker = new CircularSolid(3, 3, 0.5) {
			Merchant merchant = new Merchant("Merchant", new String[] {Wielder.SWORD, Wielder.SHIELD},
					new int[] {50, 50}, new int[] {40, 40}, new int[] {1, 1}, 100) {
				@Override
				public void closeShopInterface() {
					sayHello.choose();
				}};
			BufferedImage img = null;
			public BufferedImage getImage() {
				if (img == null) {
					img = ImageGenerator.getPerson(Color.RED);
				}
				return img;
			}
			DialogOption sayHello = new DialogOption("Say 'hello'") {
				@Override
				public void choose() {
					getGame().say("'Would you like to browse my merchandise?'",
							shop, getGame().getOption("No"));
				}
			};
			DialogOption shop = new DialogOption("Yes") {
				@Override
				public void choose() {
					merchant.createShopInterface(getGame());
				}
			};
			@Override
			public void interact() {
				getGame().say("The man says 'hello.'",
						sayHello,
						 getGame().getOption("Ignore him"));
			}
		};
		world.moveIfCan(talker, talker.getX(), talker.getY());
		world.moveIfCan(player, 0, 0);
		
		new Game(player);
		
		
	}
}
