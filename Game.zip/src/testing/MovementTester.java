package testing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
import main.Game;
import solid.CircularSolid;
import solid.Player;
import solid.RectangularSolid;
import solid.Solid;
import solid.SolidActor;
import tile.Stone;
import tile.Tile;
import tile.World;

public class MovementTester {
	public static void main(String[] args) {
		BufferedImage[] imgs = new BufferedImage[] {
				new BufferedImage(1,1,BufferedImage.TYPE_INT_RGB),
				new BufferedImage(1,1,BufferedImage.TYPE_INT_RGB),
				new BufferedImage(1,1,BufferedImage.TYPE_INT_RGB)
		};
		Color[] colors = new Color[] {
				Color.DARK_GRAY,
				Color.GRAY,
				Color.LIGHT_GRAY
		};
		for (int i=0; i<imgs.length; i++) {
			Graphics g = imgs[i].getGraphics();
			g.setColor(colors[i]);
			g.fillRect(0, 0, imgs[i].getWidth(), imgs[i].getHeight());
			g.dispose();
		}
		Tile[][] tiles = new Tile[24][24];
		class TestStone extends Stone{
			BufferedImage img;
			public TestStone(int x, int y, BufferedImage img) {
				super(x, y);
				this.img = img;
			}
			public BufferedImage getImage() {
				return img;
			}
		}
		int[] stones = new int[] {10,10, 13,10, 14,10, 14,9, 14,11, 15,10, 16,10,
				17,10, 17,7, 17,0, 14,12, 16,13, 14,13, 15,13};
		for (int i=0; i<stones.length; i+=2) {
			tiles[stones[i]][stones[i+1]] = new TestStone(stones[i], stones[i+1], imgs[1]);
		}
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new BigImageTester.EmptyTile(i, j);
				}
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.49, 100) {
			private BufferedImage[] images = null;
			private int actionStep = 0;
			private int actionDirection = 0;
			public BufferedImage getImage() {
				if (images == null) {
					images = ImageGenerator.getPersonWithSword(Color.BLUE);
				}
				return images[actionStep];
			}
			public double getImageScaleX() {
				return 1;
			}
			public double getImageScaleY() {
				return 2.5 + (actionStep * 0.02);
			}
			public double getAttackSourceX() {
				return getX();
			}
			public double getAttackSourceY() {
				return getY();
			}
			public double getAttackVectorX() {
				if (actionStep == 0) {
					return 0;
				}
				double dx = getDirectionX();
				return ((1.25 + (0.01 * actionStep)) * dx);
			}
			public double getAttackVectorY() {
				if (actionStep == 0) {
					return 0;
				}
				double dy = getDirectionY();
				return ((1.25 + (0.01 * actionStep)) * dy);
			}
			public void act() {
				super.act();
				if (keys[KeyEvent.VK_C] != Game.UNPRESSED && actionStep == 0) {
					//Ready to do something
					actionDirection = 8;
				}
				if (actionStep != 0 || actionDirection > 0) {
					if (actionStep == 64) {
						actionDirection = -8;
					}
					actionStep += actionDirection;
				}
				if (actionStep != 0) {
					Solid hit = getFirstSolidHit(getAttackSourceX(), getAttackSourceY(),
							getAttackVectorX(), getAttackVectorY());
					if (hit != null) {
						attack(hit);
						actionDirection = -8;
					}
				}
			}
		};
		world.moveIfCan(player, 0.5, 0.5);
		//Create obstacles
		class OpaqueRectangle extends RectangularSolid{
			int imageNum = 0;
			BufferedImage[] imgs;
			public OpaqueRectangle(double x, double y, double width, double height, BufferedImage[] imgs) {
				super(x, y, width, height);
				this.imgs = imgs;
			}
			public BufferedImage getImage() {
				return imgs[imageNum];
			}
			public void receiveAttack(Solid attacker) {
				imageNum++;
				imageNum %= 3;
				super.receiveAttack(attacker);
			}
		}
		class OpaqueCircle extends CircularSolid{
			BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
			public OpaqueCircle(double x, double y, double radius) {
				super(x, y, radius);
				Graphics g = img.getGraphics();
				g.setColor(Color.DARK_GRAY);
				g.fillOval(0, 0, img.getWidth(), img.getHeight());
				g.dispose();
			}
			public BufferedImage getImage() {
				return img;
			}
		}
		double[] rects = new double[] {2,0,1,2, 2,3.5,3,1, 0,6,1,1, 3,4.5,1,2.5,
				6,6,4,4, 1.5,9,4.5,1, 7, 1.5, 5, 2, 11.5,3.5,0.5,5, 12,6,6,1};
		for (int i=0; i<rects.length; i+=4) {
			OpaqueRectangle rect = new OpaqueRectangle(rects[i], rects[i+1], rects[i+2], rects[i+3], imgs);
			world.moveIfCan(rect, rect.getX(), rect.getY());
		}
		Solid circle = new OpaqueCircle(15, 3, 1.5);
		world.moveIfCan(circle, circle.getX(), circle.getY());
		SolidActor follower = new SolidActor(.49, 1) {
			BufferedImage img = null;
			public BufferedImage getImage() {
				if (img == null) {
					img = ImageGenerator.getPerson(Color.RED);
				}
				return img;
			}
			public void act() {
				super.act();
			}
			@Override
			public void receiveAttack(Solid attacker) {
				clearPath();
				if (!getWorld().moveIfCan(this, 22, 22)) {
					getWorld().moveIfCan(this, 22, 2);
				}
			}
		};
		follower.setMovementSpeed(0.04);
		follower.setBehavior(SolidActor.FOLLOW, SolidActor.FOLLOW);
		follower.setTarget(player);
		world.moveIfCan(follower, 22, 22);
		Game game = new Game(player);
	}
}

