package testing;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FramePanelSizeTesting {
	@SuppressWarnings({ "serial" })
	public static void main(String[] args) {
		JFrame frame = new JFrame("testing");
		//KeyL frameL = new KeyL("Frame");
		//frame.addKeyListener(frameL);
		KeyL panelL = new KeyL("Panel");
		frame.setLayout(new GridBagLayout());
		var gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		JPanel top = new JPanel();
		var flow = new FlowLayout();
		flow.setHgap(20);
		top.setLayout(flow);
		JLabel healthLabel = new JLabel("Health: 100");
		JLabel weaponLabel = new JLabel("Weapon: sword");
		JLabel armorLabel = new JLabel("Armor: none");
		top.add(healthLabel);
		top.add(weaponLabel);
		top.add(armorLabel);
		frame.setSize(400, 300);
		BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();
		boolean black = true;
		for (int i=0; i<5; i++) {
			for (int j=0; j<5; j++) {
				g.setColor(black ? Color.black : Color.WHITE);
				g.fillRect(20*i, 20*j, 20, 20);
				black = !black;
			}
		}
		
		JPanel panel = new JPanel() {
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				System.out.println(getWidth()+", "+getHeight());
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, getWidth(), getHeight());
			}
		};
		panel.addKeyListener(panelL);
		gbc.weightx = 100;
		gbc.fill = GridBagConstraints.BOTH;
		frame.add(top, gbc);
		gbc.weighty = 100;
		gbc.gridy++;
		frame.add(panel, gbc);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	static class KeyL implements KeyListener{
		String name;
		public KeyL(String name) {
			this.name = name;
		}
		@Override
		public void keyTyped(KeyEvent e) {}

		@Override
		public void keyPressed(KeyEvent e) {
			System.out.println(name + " detected key stroke");
		}

		@Override
		public void keyReleased(KeyEvent e) {
			
		}
		
	}
}
