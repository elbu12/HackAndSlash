package testing;

import java.awt.Color;
import java.awt.image.BufferedImage;

import commerce.Merchant;
import graphics.ImageGenerator;
import main.Game;
import solid.Player;
import tile.Dirt;
import tile.Tile;
import tile.World;

public class MerchantTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[1][1];
		tiles[0][0] = new Dirt(0, 0);
		Player player = new Player(0.5, 1) {
			BufferedImage img = ImageGenerator.getPerson(Color.blue);
			public BufferedImage getImage() {
				return img;
			}
		};
		World world = new World(tiles);
		world.moveIfCan(player, 0.5, 0.5);
		String name = "Test Merchant";
		String[] items = new String[] {"BuyOnly", "SellOnly", "Both"};
		player.getInventory().put(items[1], 20);
		player.getInventory().put(items[2], 1);
		int[] buyPrices = new int[] {10, Integer.MIN_VALUE, 20};
		int[] sellPrices = new int[] {Integer.MIN_VALUE, 15, 15};
		int[] inventory = new int[] {5, 0, 4};
		int money = 100;
		Merchant merchant = new Tester.TestMerchant(name, items, buyPrices, sellPrices, inventory, money);
		Game game = new Game(player);
		merchant.createShopInterface(game);
	}
}
