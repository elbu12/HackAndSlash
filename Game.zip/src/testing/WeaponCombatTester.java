package testing;

import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
import main.Game;
import solid.Player;
import solid.Solid;
import solid.SolidActor;
import solid.Wielder;
import tile.Dirt;
import tile.Tile;
import tile.World;

public class WeaponCombatTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[40][40];
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				tiles[i][j] = new Dirt(i, j);
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.49, 100) {
			@Override
			protected void blockAttack(Solid attacker) {
				receiveDamage(attacker.getAttackDamage() / 100);
			}
			@Override
			public int getAttackDamage() {
				return 100;
			}
		};
		world.moveIfCan(player, 0, 0);
		player.getInventory().put(Wielder.SWORD, 1);
		player.getInventory().put(Wielder.SHIELD, 1);
		player.getInventory().put(Wielder.BOW, 1);
		player.getInventory().put(Wielder.ARROW, 999);
		class Spider extends SolidActor{
			BufferedImage img;
			public Spider(Solid target) {
				super(0.45, 100);
				img = ImageGenerator.getImageFromFile("img/spider.png");
				setBehavior(STAND, ATTACK_IMMEDIATELY);
				setMovementSpeed(0.05);
				setTarget(target);
			}
			public BufferedImage getImage() {
				return img;
			}
			public int getAttackDamage() {
				return 100;
			}
			public double getAttackRange() {
				return 0.02;
			}
			@Override
			public void beginAttack() {
				attack(getTarget());
			}
		}
		class Swordsman extends Wielder{
			public Swordsman(Solid target) {
				super(0.49, 100, Wielder.RED);
				setWeapon(SWORD);
				setBehavior(STAND, ATTACK_IMMEDIATELY);
				setMovementSpeed(0.05);
				setTarget(target);
			}
			public int getAttackDamage() {
				return 100;
			}
			public double getAttackRange() {
				return 1.39;
			}
		}
		for (int i=0; i<100; i++) {
			double x = Math.random()*tiles.length;
			double y = Math.random()*tiles[(int)(x)].length;
			if (x < 8 && y < 8) {
				continue;
			}
			int t = (int)(Math.random() * 2);
			Solid enemy;
			switch (t) {
			case 0:
				enemy = new Spider(player);
				break;
			default:
				enemy = new Swordsman(player);
				break;
			}
			world.moveIfCan(enemy, x, y);
		}
		new Game(player);
	}
}
