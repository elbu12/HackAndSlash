package testing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import solid.CircularSolid;
import solid.RectangularSolid;
import tile.Land;
import tile.Stone;
import tile.Tile;
import tile.Water;
import tile.World;

/**
 * This class is specifically for testing the getBigImage method.
 * It is not automated because the user is expected to verify
 * the image.
 */
public class BigImageTester {
	@SuppressWarnings("serial")
	public static void main(String[] args) {
		JFrame frame = new JFrame("Tester");
		JPanel panel = new JPanel() {
			boolean initialized = false;
			Tile[][] tiles;
			World world;
			Me me;
			KeyHandler keyHandler;
			class KeyHandler implements KeyListener, ActionListener{
				public boolean up = false;
				public boolean down = false;
				public boolean right = false;
				public boolean left = false;
				public boolean rotate = false;
				public boolean bigRotate = false;
				public double screenAngle = 0;

				public KeyHandler() {}

				@Override
				public void keyTyped(KeyEvent e) {}

				@Override
				public void keyPressed(KeyEvent e) {
					switch (e.getKeyCode()) {
					case KeyEvent.VK_UP:
						up = true;
						break;
					case KeyEvent.VK_DOWN:
						down = true;
						break;
					case KeyEvent.VK_LEFT:
						left = true;
						break;
					case KeyEvent.VK_RIGHT:
						right = true;
						break;
					case KeyEvent.VK_R:
						rotate = true;
						break;
					case KeyEvent.VK_T:
						bigRotate = true;
						break;
					}
				}

				@Override
				public void keyReleased(KeyEvent e) {
					switch (e.getKeyCode()) {
					case KeyEvent.VK_UP:
						up = false;
						break;
					case KeyEvent.VK_DOWN:
						down = false;
						break;
					case KeyEvent.VK_LEFT:
						left = false;
						break;
					case KeyEvent.VK_RIGHT:
						right = false;
						break;
					case KeyEvent.VK_R:
						rotate = false;
						break;
					case KeyEvent.VK_T:
						bigRotate = false;
						break;
					}
				}

				@Override
				public void actionPerformed(ActionEvent e) {
					double dx = 0;
					double dy = 0;
					if (up && !down) {
						dy = 0.1;
					}
					else if (down && !up) {
						dy = -0.1;
					}
					if (right && !left) {
						dx = 0.1;
					}
					else if (left && !right) {
						dx = -0.1;
					}
					if (dx != 0 || dy != 0) {
						world.moveAsMuchAsPossible(me, me.getX() + dx, me.getY() + dy);
					}
					if (rotate) {
						me.setDirection(me.getDirection() + (Math.PI*0.04));
						if (me.getDirection() > 2*Math.PI) {
							me.setDirection(me.getDirection() - (Math.PI*2));
						}
					}
					if (bigRotate) {
						screenAngle += (Math.PI*0.0625);
						if (screenAngle >= Math.PI * 2) {
							screenAngle -= Math.PI * 2;
						}
					}
					repaint();
				}
			}
			public void paintComponent(Graphics g) {
				if (initialized == false) {
					initialized = true;
					tiles = new Tile[10][10];
					tiles[1][1] = new ObstructionTile(1, 1);
					tiles[8][1] = new UnwalkableTile(8, 1);
					for (int i=0; i<10; i++) {
						for (int j=0; j<10; j++) {
							if (tiles[i][j] == null) {
								tiles[i][j] = new EmptyTile(i, j);
							}
						}
					}
					BoxSolid box = new BoxSolid(1, 8, 1, 1);
					DiskSolid disk = new DiskSolid(8.5, 8.5, 0.5);
					me = new Me(5, 5, 0.5);
					world = new World(tiles);
					if (!world.moveIfCan(box, box.getX(), box.getY())) {
						System.out.println("could not place box");
						System.exit(-1);
					}
					if (!world.moveIfCan(disk, disk.getX(), disk.getY())) {
						System.out.println("could not place disk");
						System.exit(-1);
					}
					if (!world.moveIfCan(me, me.getX(), me.getY())) {
						System.out.println("could not place me");
						System.exit(-1);
					}
					keyHandler = new KeyHandler();
					frame.addKeyListener(keyHandler);
					Timer timer = new Timer(33, keyHandler);
					timer.start();
				}
				Graphics2D g2d = (Graphics2D)(g);
				BufferedImage img = world.getImage(5, 5, frame.getWidth(), frame.getHeight()-22, keyHandler.screenAngle);
				g2d.drawImage(img, 0, 0, null);
			}
		};
		frame.add(panel);
		frame.setSize(600,622);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	static class EmptyTile extends Land{
		static BufferedImage img = null;
		public EmptyTile(int x, int y) {
			super(x, y);
		}
		public boolean isObstruction() {
			return false;
		}
		public boolean isWalkable() {
			return true;
		}
		public BufferedImage getImage() {
			if (img == null) {
				img = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
				Graphics g = img.getGraphics();
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, 1, 1);
			}
			return img;
		}
	}
	static class ObstructionTile extends Stone{
		static BufferedImage img = null;
		public ObstructionTile(int x, int y) {
			super(x, y);
		}
		public boolean isObstruction() {
			return true;
		}
		public BufferedImage getImage() {
			if (img == null) {
				img = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
				Graphics g = img.getGraphics();
				g.setColor(Color.GRAY);
				g.fillRect(0, 0, 1, 1);
			}
			return img;
		}
	}
	static class UnwalkableTile extends Water{
		static BufferedImage img = null;
		public UnwalkableTile(int x, int y) {
			super(x, y);
		}
		public boolean isObstruction() {
			return false;
		}
		public boolean isWalkable() {
			return false;
		}
		public BufferedImage getImage() {
			if (img == null) {
				img = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
				Graphics g = img.getGraphics();
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, 1, 1);
			}
			return img;
		}
	}
	static class BoxSolid extends RectangularSolid{
		static BufferedImage img = null;
		public BoxSolid(double x, double y, double width, double height) {
			super(x, y, width, height);
		}
		public BufferedImage getImage() {
			if (img == null) {
				img = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
				Graphics g = img.getGraphics();
				g.setColor(Color.BLUE);
				g.fillRect(0, 0, 1, 1);
			}
			return img;
		}
	}
	static class DiskSolid extends CircularSolid{
		static BufferedImage img = null;
		public DiskSolid(double x, double y, double radius) {
			super(x, y, radius);
		}
		public BufferedImage getImage() {
			if (img == null) {
				img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
				Graphics g = img.getGraphics();
				g.setColor(Color.BLUE);
				g.fillOval(0, 0, 100, 100);
			}
			return img;
		}
	}
	static class Me extends CircularSolid{
		static BufferedImage img = null;
		private double direction;
		public Me(double x, double y, double radius) {
			super(x, y, radius);
			direction = 0;
		}
		public BufferedImage getImage() {
			if (img == null) {
				img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
				Graphics g = img.getGraphics();
				g.setColor(Color.RED);
				g.fillOval(0, 0, 100, 100);
				g.setColor(Color.WHITE);
				g.fillOval(40, 80, 20, 20);
			}
			return img;
		}
		public double getDirection() {
			return direction;
		}
		public void setDirection(double direction) {
			this.direction = direction;
		}
	}
}
