package testing;

import java.awt.image.BufferedImage;

import graphics.ImageGenerator;
import main.Game;
import solid.CircularSolid;
import solid.Player;
import solid.Solid;
import solid.SolidActor;
import solid.Wielder;
import tile.Dirt;
import tile.Stone;
import tile.Tile;
import tile.World;

public class PrimitiveCombatTester {
	public static void main(String[] args) {
		Tile[][] tiles = new Tile[100][100];
		for (int i=0; i<tiles.length; i++) {
			tiles[i][0] = new Stone(i, 0);
			int end = tiles[i].length - 1;
			tiles[i][end] = new Stone(i, end);
		}
		for (int i=0; i<tiles[0].length; i++) {
			tiles[0][i] = new Stone(0, i);
			int end = tiles.length - 1;
			tiles[end][i] = new Stone(end, i);
		}
		for (int i=0; i<tiles.length; i++) {
			for (int j=0; j<tiles[i].length; j++) {
				if (tiles[i][j] == null) {
					tiles[i][j] = new Dirt(i, j);
				}
			}
		}
		World world = new World(tiles);
		Player player = new Player(0.49, 1){
			public void act() {
				super.act();
				if (getActionStep() != 0) {
					//Do we hit anything?
					Solid hit = getFirstSolidHit(getAttackSourceX(),
							getAttackSourceY(), getAttackVectorX(), getAttackVectorY());
					if (hit != null) {
						attack(hit);
					}
				}
			}
			public int getAttackDamage() {
				return 100;
			}
		};
		player.getInventory().put(Wielder.SWORD, 1);
		player.getInventory().put(Wielder.BOW, 1);
		player.getInventory().put(Wielder.ARROW, 100);
		player.getInventory().put(Wielder.SHIELD, 1);
		world.moveIfCan(player, 2, 2);
		class Spider extends SolidActor{
			BufferedImage img = ImageGenerator.getImageFromFile("img/spider.png");
			public Spider(Solid target) {
				super(0.49, 1);
				setBehavior(STAND, ATTACK_IMMEDIATELY);
				setMovementSpeed(0.05);
				setTarget(target);
			}
			public BufferedImage getImage() {
				return img;
			}
			public int getAttackDamage() {
				return 100;
			}
			public double getAttackRange() {
				return 0.02;
			}
			@Override
			public void beginAttack() {
				attack(getTarget());
			}
		}
		for (int i=0; i<200; i++) {
			world.moveIfCan(new Spider(player), Math.random()*tiles.length, Math.random()*tiles[0].length);
		}
		class Tree extends CircularSolid{
			private BufferedImage img = null;
			public Tree(double radius) {
				super(0, 0, radius);
				img = ImageGenerator.getTree((int)(100.0 * radius));
			}
			public BufferedImage getImage() {
				return img;
			}
		}
		for (int i=0; i<200; i++) {
			world.moveIfCan(new Tree(0.5 + Math.random()), Math.random()*tiles.length, Math.random()*tiles[0].length);
		}
		new Game(player);
	}
}
